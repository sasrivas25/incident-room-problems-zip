#!/usr/bin/env bash
# Definition-of-done matrix: every language x {main, solution} x {with hidden, without hidden}.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
REPO="$HERE/../tenant-cache-leak-incident"
source /Users/ssrivastav2/Documents/Repo/_gronex-tools/env.sh
cd "$REPO"
summary() {
  local lang="$1" log="$2"
  case "$lang" in
    PYTHON) grep -oE '[0-9]+ passed|[0-9]+ failed' "$log" | tr '\n' ' ' ;;
    JAVA) grep -oE 'Tests run: [0-9]+, Failures: [0-9]+, Errors: [0-9]+' "$log" | tail -1 ;;
    NODEJS) grep -E '^ℹ (pass|fail) ' "$log" | tr '\n' ' ' ;;
    CPP) grep -oE '[0-9]+% tests passed[^$]*' "$log" | tail -1 ;;
  esac
}
echo "| Branch | Hidden overlay | Language | Exit | Summary | Verdict line |"
echo "| --- | --- | --- | --- | --- | --- |"
for branch in main solution; do
  for overlay in without with; do
    git checkout -q "$branch"
    git clean -qfdx -e hidden
    for lang in PYTHON JAVA NODEJS CPP; do
      if [ "$overlay" = with ]; then cp -R "hidden/$lang/." "$lang/"; fi
      log="${TMPDIR:-/tmp/claude-501}/dod-$branch-$overlay-$lang.log"
      (cd "$lang" && ./verify.sh > "$log" 2>&1); code=$?
      verdict=$(grep -E '^(✅|❌)' "$log" | head -1)
      echo "| $branch | $overlay | $lang | $code | $(summary "$lang" "$log") | $verdict |"
    done
    git clean -qfdx -e hidden
  done
done
git checkout -q main
git status --short | head -3
