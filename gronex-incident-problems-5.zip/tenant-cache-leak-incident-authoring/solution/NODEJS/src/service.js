'use strict';

const { buildProfileKey } = require('./cache_keys');
const { CacheUnavailableError } = require('./cache_store');
const { NEGATIVE_SENTINEL, decodeProfile, encodeProfile, isNegative } = require('./codec');

class ProfileService {
  constructor(config, cache, origin, clock, metrics) {
    this._config = config;
    this._cache = cache;
    this._origin = origin;
    this._clock = clock;
    this._metrics = metrics;
  }

  getProfile(tenantId, userId) {
    const key = buildProfileKey(this._config, tenantId, userId);
    const cached = this._readCached(key, tenantId, userId);
    if (cached != null) {
      return isNegative(cached) ? null : cached;
    }
    this._metrics.increment('cache.miss');
    const profile = this._loadFromOrigin(tenantId, userId);
    if (profile == null) {
      if (this._config.negativeCachingEnabled) {
        this._cacheSet(key, NEGATIVE_SENTINEL, this._config.negativeTtlS);
      }
      return null;
    }
    this._cacheSet(key, encodeProfile(profile), this._config.profileTtlS);
    return profile;
  }

  updateProfile(profile) {
    this._origin.save(profile);
    this._cacheDelete(buildProfileKey(this._config, profile.tenantId, profile.userId));
  }

  createProfile(profile) {
    this._origin.save(profile);
    this._cacheDelete(buildProfileKey(this._config, profile.tenantId, profile.userId));
  }

  _readCached(key, tenantId, userId) {
    const raw = this._cacheGet(key);
    if (raw == null) {
      return null;
    }
    if (isNegative(raw)) {
      if (!this._config.negativeCachingEnabled) {
        return null;
      }
      this._metrics.increment('cache.negative_hit');
      return raw;
    }
    const profile = decodeProfile(raw);
    if (profile === null) {
      this._metrics.increment('cache.decode_error');
      this._cacheDelete(key);
      return null;
    }
    if (profile.tenantId !== tenantId || profile.userId !== userId) {
      this._metrics.increment('cache.tenant_mismatch');
      this._cacheDelete(key);
      return null;
    }
    this._metrics.increment('cache.hit');
    return profile;
  }

  _loadFromOrigin(tenantId, userId) {
    this._metrics.increment('origin.load');
    return this._origin.load(tenantId, userId);
  }

  _cacheGet(key) {
    try {
      return this._cache.get(key);
    } catch (err) {
      if (err instanceof CacheUnavailableError) {
        this._metrics.increment('cache.error');
        return null;
      }
      throw err;
    }
  }

  _cacheSet(key, value, ttlS) {
    try {
      this._cache.set(key, value, ttlS);
    } catch (err) {
      if (err instanceof CacheUnavailableError) {
        this._metrics.increment('cache.error');
        return;
      }
      throw err;
    }
  }

  _cacheDelete(key) {
    try {
      this._cache.delete(key);
    } catch (err) {
      if (err instanceof CacheUnavailableError) {
        this._metrics.increment('cache.error');
        return;
      }
      throw err;
    }
  }
}

module.exports = { ProfileService };
