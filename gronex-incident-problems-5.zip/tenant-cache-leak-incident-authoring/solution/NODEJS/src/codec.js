'use strict';

const { makeProfile } = require('./models');

const NEGATIVE_SENTINEL = '__NOT_FOUND__';
const PAYLOAD_VERSION = 'v3';
const FIELD_COUNT = 5;
const DIGITS = /^[0-9]+$/;

function encodeProfile(profile) {
  const fields = [profile.tenantId, profile.userId, profile.displayName, profile.email, String(profile.version)];
  return PAYLOAD_VERSION + fields.map(lengthPrefixed).join('');
}

function decodeProfile(raw) {
  if (typeof raw !== 'string' || !raw.startsWith(PAYLOAD_VERSION)) {
    return null;
  }
  const fields = readFields(raw.slice(PAYLOAD_VERSION.length));
  if (fields === null || fields.length !== FIELD_COUNT) {
    return null;
  }
  const [tenantId, userId, displayName, email, version] = fields;
  if (!DIGITS.test(version)) {
    return null;
  }
  return makeProfile(tenantId, userId, displayName, email, Number.parseInt(version, 10));
}

function isNegative(raw) {
  return raw === NEGATIVE_SENTINEL;
}

function lengthPrefixed(value) {
  return `${value.length}:${value}`;
}

function readFields(body) {
  const fields = [];
  let position = 0;
  while (position < body.length) {
    const separator = body.indexOf(':', position);
    if (separator < 0 || !DIGITS.test(body.slice(position, separator))) {
      return null;
    }
    const length = Number.parseInt(body.slice(position, separator), 10);
    const start = separator + 1;
    const end = start + length;
    if (end > body.length) {
      return null;
    }
    fields.push(body.slice(start, end));
    position = end;
  }
  return fields;
}

module.exports = { NEGATIVE_SENTINEL, PAYLOAD_VERSION, FIELD_COUNT, encodeProfile, decodeProfile, isNegative };
