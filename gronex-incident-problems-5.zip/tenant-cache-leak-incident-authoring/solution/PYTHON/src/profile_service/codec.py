from typing import List, Optional

from .models import Profile

NEGATIVE_SENTINEL = "__NOT_FOUND__"
PAYLOAD_VERSION = "v3"
FIELD_COUNT = 5


def encode_profile(profile: Profile) -> str:
    fields = [profile.tenant_id, profile.user_id, profile.display_name, profile.email, str(profile.version)]
    return PAYLOAD_VERSION + "".join(_length_prefixed(field) for field in fields)


def decode_profile(raw: str) -> Optional[Profile]:
    if not raw.startswith(PAYLOAD_VERSION):
        return None
    fields = _read_fields(raw[len(PAYLOAD_VERSION):])
    if fields is None or len(fields) != FIELD_COUNT:
        return None
    tenant_id, user_id, display_name, email, version = fields
    if not version.isdigit():
        return None
    return Profile(tenant_id, user_id, display_name, email, int(version))


def is_negative(raw: str) -> bool:
    return raw == NEGATIVE_SENTINEL


def _length_prefixed(value: str) -> str:
    return f"{len(value)}:{value}"


def _read_fields(body: str) -> Optional[List[str]]:
    fields: List[str] = []
    position = 0
    while position < len(body):
        separator = body.find(":", position)
        if separator < 0 or not body[position:separator].isdigit():
            return None
        length = int(body[position:separator])
        start = separator + 1
        end = start + length
        if end > len(body):
            return None
        fields.append(body[start:end])
        position = end
    return fields
