#include "codec.hpp"

#include <cctype>
#include <vector>

const std::string NEGATIVE_SENTINEL = "__NOT_FOUND__";
const std::string PAYLOAD_VERSION = "v3";
const std::size_t FIELD_COUNT = 5;

namespace {

bool is_digits(const std::string& value) {
    if (value.empty()) {
        return false;
    }
    for (unsigned char c : value) {
        if (!std::isdigit(c)) {
            return false;
        }
    }
    return true;
}

std::string length_prefixed(const std::string& value) {
    return std::to_string(value.size()) + ":" + value;
}

std::optional<std::vector<std::string>> read_fields(const std::string& body) {
    std::vector<std::string> fields;
    std::size_t position = 0;
    while (position < body.size()) {
        const std::size_t separator = body.find(':', position);
        if (separator == std::string::npos || !is_digits(body.substr(position, separator - position))) {
            return std::nullopt;
        }
        const std::size_t length = static_cast<std::size_t>(std::stoul(body.substr(position, separator - position)));
        const std::size_t start = separator + 1;
        const std::size_t end = start + length;
        if (end > body.size()) {
            return std::nullopt;
        }
        fields.push_back(body.substr(start, length));
        position = end;
    }
    return fields;
}

}

std::string encode_profile(const Profile& profile) {
    const std::vector<std::string> fields = {profile.tenant_id, profile.user_id, profile.display_name, profile.email,
                                             std::to_string(profile.version)};
    std::string out = PAYLOAD_VERSION;
    for (const auto& field : fields) {
        out += length_prefixed(field);
    }
    return out;
}

std::optional<Profile> decode_profile(const std::string& raw) {
    if (raw.compare(0, PAYLOAD_VERSION.size(), PAYLOAD_VERSION) != 0) {
        return std::nullopt;
    }
    const auto fields = read_fields(raw.substr(PAYLOAD_VERSION.size()));
    if (!fields.has_value() || fields->size() != FIELD_COUNT) {
        return std::nullopt;
    }
    const std::string& version = (*fields)[4];
    if (!is_digits(version)) {
        return std::nullopt;
    }
    return Profile{(*fields)[0], (*fields)[1], (*fields)[2], (*fields)[3], std::stoi(version)};
}

bool is_negative(const std::string& raw) {
    return raw == NEGATIVE_SENTINEL;
}
