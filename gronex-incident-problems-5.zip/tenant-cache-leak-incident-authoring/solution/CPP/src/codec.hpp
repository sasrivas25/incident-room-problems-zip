#pragma once

#include <optional>
#include <string>

#include "models.hpp"

extern const std::string NEGATIVE_SENTINEL;
extern const std::string PAYLOAD_VERSION;
extern const std::size_t FIELD_COUNT;

std::string encode_profile(const Profile& profile);

std::optional<Profile> decode_profile(const std::string& raw);

bool is_negative(const std::string& raw);
