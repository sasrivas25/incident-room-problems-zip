package com.gronex.profiles;

import static com.gronex.profiles.CacheKeys.buildProfileKey;
import static com.gronex.profiles.Codec.NEGATIVE_SENTINEL;
import static com.gronex.profiles.Codec.decodeProfile;
import static com.gronex.profiles.Codec.encodeProfile;
import static com.gronex.profiles.Codec.isNegative;

public class ProfileService {
    private final ServiceConfig config;
    private final CacheStore cache;
    private final ProfileOrigin origin;
    private final Clock clock;
    private final Metrics metrics;

    public ProfileService(ServiceConfig config, CacheStore cache, ProfileOrigin origin, Clock clock, Metrics metrics) {
        this.config = config;
        this.cache = cache;
        this.origin = origin;
        this.clock = clock;
        this.metrics = metrics;
    }

    public Profile getProfile(String tenantId, String userId) {
        String key = buildProfileKey(config, tenantId, userId);
        CacheLookup cached = readCached(key, tenantId, userId);
        if (cached.found()) {
            return cached.profile();
        }
        metrics.increment("cache.miss");
        Profile profile = loadFromOrigin(tenantId, userId);
        if (profile == null) {
            if (config.negativeCachingEnabled()) {
                cacheSet(key, NEGATIVE_SENTINEL, config.negativeTtlS());
            }
            return null;
        }
        cacheSet(key, encodeProfile(profile), config.profileTtlS());
        return profile;
    }

    public void updateProfile(Profile profile) {
        origin.save(profile);
        cacheDelete(buildProfileKey(config, profile.tenantId(), profile.userId()));
    }

    public void createProfile(Profile profile) {
        origin.save(profile);
        cacheDelete(buildProfileKey(config, profile.tenantId(), profile.userId()));
    }

    private CacheLookup readCached(String key, String tenantId, String userId) {
        String raw = cacheGet(key);
        if (raw == null) {
            return CacheLookup.ABSENT;
        }
        if (isNegative(raw)) {
            if (!config.negativeCachingEnabled()) {
                return CacheLookup.ABSENT;
            }
            metrics.increment("cache.negative_hit");
            return CacheLookup.NEGATIVE;
        }
        Profile profile = decodeProfile(raw);
        if (profile == null) {
            metrics.increment("cache.decode_error");
            cacheDelete(key);
            return CacheLookup.ABSENT;
        }
        if (!profile.tenantId().equals(tenantId) || !profile.userId().equals(userId)) {
            metrics.increment("cache.tenant_mismatch");
            cacheDelete(key);
            return CacheLookup.ABSENT;
        }
        metrics.increment("cache.hit");
        return CacheLookup.hit(profile);
    }

    private Profile loadFromOrigin(String tenantId, String userId) {
        metrics.increment("origin.load");
        return origin.load(tenantId, userId);
    }

    private String cacheGet(String key) {
        try {
            return cache.get(key);
        } catch (CacheUnavailableError e) {
            metrics.increment("cache.error");
            return null;
        }
    }

    private void cacheSet(String key, String value, int ttlS) {
        try {
            cache.set(key, value, ttlS);
        } catch (CacheUnavailableError e) {
            metrics.increment("cache.error");
        }
    }

    private void cacheDelete(String key) {
        try {
            cache.delete(key);
        } catch (CacheUnavailableError e) {
            metrics.increment("cache.error");
        }
    }

    private record CacheLookup(boolean found, Profile profile) {
        private static final CacheLookup ABSENT = new CacheLookup(false, null);
        private static final CacheLookup NEGATIVE = new CacheLookup(true, null);

        private static CacheLookup hit(Profile profile) {
            return new CacheLookup(true, profile);
        }
    }
}
