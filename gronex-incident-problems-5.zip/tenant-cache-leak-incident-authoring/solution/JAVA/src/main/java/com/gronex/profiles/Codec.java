package com.gronex.profiles;

import java.util.ArrayList;
import java.util.List;

public final class Codec {
    public static final String NEGATIVE_SENTINEL = "__NOT_FOUND__";
    public static final String PAYLOAD_VERSION = "v3";
    public static final int FIELD_COUNT = 5;

    private Codec() {
    }

    public static String encodeProfile(Profile profile) {
        List<String> fields = List.of(profile.tenantId(), profile.userId(), profile.displayName(), profile.email(), String.valueOf(profile.version()));
        StringBuilder out = new StringBuilder(PAYLOAD_VERSION);
        for (String field : fields) {
            out.append(lengthPrefixed(field));
        }
        return out.toString();
    }

    public static Profile decodeProfile(String raw) {
        if (raw == null || !raw.startsWith(PAYLOAD_VERSION)) {
            return null;
        }
        List<String> fields = readFields(raw.substring(PAYLOAD_VERSION.length()));
        if (fields == null || fields.size() != FIELD_COUNT) {
            return null;
        }
        String version = fields.get(4);
        if (!isDigits(version)) {
            return null;
        }
        return new Profile(fields.get(0), fields.get(1), fields.get(2), fields.get(3), Integer.parseInt(version));
    }

    public static boolean isNegative(String raw) {
        return NEGATIVE_SENTINEL.equals(raw);
    }

    private static String lengthPrefixed(String value) {
        return value.length() + ":" + value;
    }

    private static List<String> readFields(String body) {
        List<String> fields = new ArrayList<>();
        int position = 0;
        while (position < body.length()) {
            int separator = body.indexOf(':', position);
            if (separator < 0 || !isDigits(body.substring(position, separator))) {
                return null;
            }
            int length = Integer.parseInt(body.substring(position, separator));
            int start = separator + 1;
            int end = start + length;
            if (end > body.length()) {
                return null;
            }
            fields.add(body.substring(start, end));
            position = end;
        }
        return fields;
    }

    private static boolean isDigits(String value) {
        if (value.isEmpty()) {
            return false;
        }
        for (int i = 0; i < value.length(); i++) {
            if (!Character.isDigit(value.charAt(i))) {
                return false;
            }
        }
        return true;
    }
}
