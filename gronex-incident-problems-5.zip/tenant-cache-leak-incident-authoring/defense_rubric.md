# Defend rubric: Cross-Tenant Profile Leak

## What a strong answer says

1. **Three faults, fixed in the right order.** The key builder is injective again (delimited, length-prefixed or escaped segments, and it includes `key_version` so rotation works). The cached payload carries the owner's tenant and user ids and the read path rejects, evicts and reloads any entry whose owner does not match the request, counting `cache.tenant_mismatch`. Negative caching uses `negative_ttl_s`, honours `negative_caching_enabled` on both the write and the read side, and `create_profile` invalidates the sentinel.
2. **Why it is safe to deploy mid-incident.** New keys live in a different namespace from the poisoned `p...` keys, so the fix never reads a poisoned entry. Poisoned entries age out under their own TTL (600 s) without a flush. Origin load during warm-up is bounded by the miss rate of a cold namespace and stays far below the 200 qps ceiling in the runbook; the dashboard shows the cache-3 refill peaked at about 160 qps for a third of the keyspace, so a full-namespace warm-up should be checked against that number. Validation on read is defence in depth that would have caught the leak even with the broken key.
3. **The trade-off, named explicitly.** Fastest exposure stop is rollback to r1, which gives up the memory saving. The code fix keeps a compact-ish payload but spends bytes on the owner ids and CPU on validation. A flush would have stopped exposure a few seconds sooner at the cost of an origin stampede the runbook documents as a past outage. The strong answer picks "deploy the fix, do not flush, let the poisoned keys expire" or "roll back first, then deploy the fix" and says why.
4. **Residual risk.** Entries written by r2 pods during the fix rollout, the 600 s exposure tail, and any other service using the same key builder.

## Trade-offs the answer should name

- Stop the exposure now (rollback or flush) versus restore the memory win (fix forward).
- Validate every hit (CPU, latency) versus trust the key (cheaper, one bug away from another leak).
- Namespace rotation (bounded origin load, keeps serving) versus flush (immediate, stampede).
- Negative caching on (protects origin from enumeration and typos) versus off during the incident (15 qps more origin load, no cached 404s).

## Risks a good engineer flags

- Exposure window: every tenant pair that collided between 09:14 and the fix; needs an audit query over access logs by key, and a privacy notification per the runbook.
- Rolling deploy of the fix: old pods still write `p...` keys for a few minutes; the new namespace is unaffected, but the old namespace keeps leaking until the last pod is replaced.
- Warm-up load on the origin when the namespace changes; watch `origin_qps` against the 180 alert.
- The `|` separator bug is gone with the new payload, but any other service that decodes r2 payloads breaks when the format changes.
- Hit ratio will drop to the real baseline; someone will ask why the "improvement" disappeared.

## Follow-up questions for finalists

1. **Why is a delimiter alone not enough?** Good answer: ids may contain the delimiter (runbook alphabet includes `:`), so use length prefixes or escaping, and add `key_version` so the namespace can be rotated.
2. **You validate owner ids on every hit. What does that cost and when would you remove it?** Good answer: a decode and two string compares per hit, measurable in p50; keep it, it is the only control that works when the key is wrong, and log `cache.tenant_mismatch` as a security signal.
3. **Poisoned `p...` entries are still in the cache after your deploy. What happens to them?** Good answer: nothing reads them because the namespace changed; they expire within 600 s; no flush needed. If asked to shorten the tail, rotate nothing, since they are already unreachable.
4. **Why did the rollout controller call this deploy a success?** Good answer: its checks were error rate, p99 and memory trend, all of which improved; correctness signals (404 ratio, distinct keys versus population, a canary comparing cached versus origin responses) were missing.
5. **The 404 ratio was the alert that fired. Why not fix negative caching first?** Good answer: the 404s are a consequence of the collision; shortening the sentinel TTL hides them within 30 s but the leak continues; fix the key, then the TTL and the switch.
6. **How would you prove which tenants were exposed?** Good answer: replay access logs, group by key, flag keys with more than one distinct tenant in requests between 09:14:02 and the fix; the three pairs in app.log are examples, the full list needs the complete log.
7. **The runbook says rotating `key_version` invalidates everything. Would it have worked during this incident?** Good answer: no, r2's builder ignored `key_version`; the runbook was stale because the change removed the namespaced builder; fix the code and add a test that the key contains the version.
8. **Would you keep negative caching at all?** Good answer: yes with a tenant-scoped key, a 30 s TTL and invalidation on create; without it, enumeration or mistyped ids hit the origin directly.
