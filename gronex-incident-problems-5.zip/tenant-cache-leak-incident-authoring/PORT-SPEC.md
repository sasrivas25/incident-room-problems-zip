# Port spec: tenant-cache-leak-incident (Gronex Incident Room problem)

You are porting ONE language of a four-language incident problem. The Python tree is the executable specification. Translate it; do not redesign it.

Repo root: `/Users/ssrivastav2/Documents/Repo/tenant-cache-leak-incident/`

## Inputs (read all of them first)
- Broken (main-branch) Python source: `PYTHON/src/profile_service/*.py`
- Fixed (solution-branch) Python source: `/Users/ssrivastav2/Documents/Repo/tenant-cache-leak-incident-authoring/solution/PYTHON/src/profile_service/*.py`
- Visible tests + fakes + harness: `PYTHON/tests/{conftest.py,fakes.py,harness.py,test_profile_service.py}`
- Hidden tests: `hidden/PYTHON/tests/test_hidden.py`

## Deliverables for your language `<LANG>` (JAVA, NODEJS or CPP)
1. `<LANG>/` project at the repo root with the BROKEN source (faithful port of `PYTHON/src`, same faults, same behaviour, same metric names, same constants, same separator `|`, same sentinel `__NOT_FOUND__`).
2. `/Users/ssrivastav2/Documents/Repo/tenant-cache-leak-incident-authoring/solution/<LANG>/src/...` : the FIXED source files only (same file names as your broken `src/`), a faithful port of the Python solution. Every file in your broken `src/` must have a counterpart here, even if identical (copy it), because the solution branch is produced by copying this directory over `<LANG>/src/`.
3. Visible tests under `<LANG>/tests...` with EXACTLY the same 18 test names as `PYTHON/tests/test_profile_service.py` (snake_case strings/identifiers, identical spelling) and the same assertions.
4. Hidden tests with EXACTLY the same 12 test names as `hidden/PYTHON/tests/test_hidden.py`, at the path given below. They must compile/run when overlaid and the build must still work when they are absent.
5. `<LANG>/verify.sh` (chmod +x) following the contract below.
6. `<LANG>/README.md` : copy `PYTHON/README.md` if it exists and adapt only the "Project layout" and "How to run" sections for your language. If it does not exist yet, write a short placeholder; I will replace it.

Do NOT create logs/, metrics/, docs/ or problem.json; I generate those.

## Expected results (must match exactly)
- Broken source, visible tests only: 8 pass, 10 fail.
- Broken source + hidden overlay: 11 pass, 19 fail (30 total).
- Fixed source + hidden overlay: 30 pass, 0 fail.
The passing set on broken code must be the same tests as in Python. Run Python yourself to see which ones:
`PYTHON=/Users/ssrivastav2/Documents/Repo/_gronex-tools/venv/bin/python; cd PYTHON && $PYTHON -m pytest tests -v`.
If your counts differ, your port is wrong. Do not change assertions to match your output.

## Hard rules
- No comments of any kind in files under `src/`, `tests/`, `tests_hidden/` or `hidden/`. (Build files, verify.sh and README may have comments.)
- Standard library only. No external dependencies (Java: JUnit 5 only, already cached locally; Node: `node:test` + `node:assert`; C++: no gtest, use the tiny registry header described below).
- Deterministic: no wall clock, no sleep, no randomness, no network, no threads. The FakeClock is the only time source.
- Same file-per-concept structure as Python: models, clock, config, identifiers, cache_keys, codec, cache_store, origin, metrics, service, api. Use idiomatic names (e.g. `CacheKeys.java`, `cache_keys.js`, `cache_keys.hpp/.cpp`).
- The two stack-trace points must exist as real lines of code in your broken source, because the incident logs quote them. After you finish, report the exact file path and 1-based line number (in your BROKEN source) of each of these four statements:
  T1. in `codec`: the line that throws/raises because the compact payload has the wrong field count (Python `codec.py` raise ValueError).
  T2. in `service`: the line in get_profile that calls decode on the cached raw value (Python `service.py:29`).
  T3. in `api`: the line that calls `service.get_profile` inside the try (Python `api.py:21`).
  T4. in `service`: the line inside the cache-get helper that calls `cache.get(key)` (Python `service.py:51`).
  Also report the exact exception type and message text your broken codec throws for a 4-field payload (Python: `ValueError: compact payload: expected 3 fields, got 4`). Use a type that is natural for the language (Java: `IllegalStateException`, Node: `Error`, C++: `std::runtime_error`) with the same message text.

## verify.sh contract (all languages)
Prints a banner, runs tests, prints exactly one of these two lines, exits with the test runner status:
```
✅ PASS — all checks green. Your solution is correct.
❌ FAIL — some checks did not pass. Keep going!
```
Banner: `==============================================` / ` Gronex verify — Cross-Tenant Profile Leak (<Language>)` / `==============================================`.
Then after the run: `----------------------------------------------` then the PASS or FAIL line; on FAIL also print `   Read the failures above; fix src/, then run ./verify.sh again.`
Fully local, no network except dependency install. It must work from any cwd (`cd "$(dirname "$0")"`).

### JAVA
- Layout: `JAVA/pom.xml`, `JAVA/src/main/java/com/gronex/profiles/*.java`, visible tests `JAVA/tests/java/com/gronex/profiles/{Fakes.java,World.java,ProfileServiceTest.java}`, hidden test file `hidden/JAVA/tests/java/com/gronex/profiles/HiddenIncidentTest.java` (it lands at `JAVA/tests/java/com/gronex/profiles/HiddenIncidentTest.java` when overlaid).
- pom: Java 17 (`maven.compiler.release` 17), `junit-jupiter` 5.10.2 test scope, `testSourceDirectory` = `tests/java`, plugins pinned: maven-resources-plugin 3.3.1, maven-compiler-plugin 3.13.0, maven-surefire-plugin 3.2.5. groupId `com.gronex`, artifactId `tenant-cache-leak-incident`.
- Test method names = the Python test names verbatim (e.g. `void test_cache_hit_skips_origin()`), annotated `@Test`.
- verify.sh runs `mvn -q test`; exit status from mvn. Print the surefire summary line(s) (`Tests run: ...`) so the contestant sees counts: run `mvn test` to a temp log and grep `Tests run:|FAIL|ERROR` lines, or run it unquiet. Keep output readable.
- Build environment quirks ON THIS MACHINE ONLY (do not bake into verify.sh): before running mvn, `source /Users/ssrivastav2/Documents/Repo/_gronex-tools/env.sh` (sets JAVA_TOOL_OPTIONS tmpdir and MAVEN_ARGS pointing at a writable local repo + settings). Run mvn offline (`mvn -o ...`) via that env; the required plugins/deps are cached. If an artifact is missing, run `/Users/ssrivastav2/Documents/Repo/_gronex-tools/mvn-fetch-missing.sh <JAVA project dir> test`.
- Model types: `Profile` as a Java record (tenant_id -> tenantId etc.). `ServiceConfig` as a record with a static `fromMap(Map<String,Object>)` and a static `defaults()` plus `with...` style helpers if convenient. `ApiResponse(int status, Map<String,Object> body)`.
- Metrics counter names are the same strings as Python (`cache.hit`, `cache.miss`, `cache.negative_hit`, `cache.error`, `cache.tenant_mismatch`, `cache.decode_error`, `origin.load`).

### NODEJS
- Layout: `NODEJS/package.json` (`"type": "commonjs"`, scripts.test = `node --test tests`, no dependencies), `NODEJS/src/*.js` (one file per concept, CommonJS `module.exports`), visible tests `NODEJS/tests/{fakes.js,harness.js,profile_service.test.js}`, hidden `hidden/NODEJS/tests_hidden/hidden.test.js` (lands at `NODEJS/tests_hidden/hidden.test.js`; it requires `../tests/harness.js` and `../src/...`).
- Use `const test = require('node:test'); const assert = require('node:assert/strict');` and `test('test_cache_hit_skips_origin', () => {...})` with the Python names verbatim.
- verify.sh: `if [ -d tests_hidden ]; then node --test tests tests_hidden; else node --test tests; fi` (node >= 18; `node --test <dir>` runs *.test.js files in the directory).
- Profiles as frozen plain objects `{ tenantId, userId, displayName, email, version }`; compare with `assert.deepEqual`. Config as a frozen object built by `serviceConfig({...overrides})` with the same defaults; also export `configFromDict(obj)`.

### CPP
- Layout: `CPP/CMakeLists.txt`, `CPP/src/*.hpp` and `*.cpp` (header per concept; implementation .cpp for cache_keys, codec, service, api, identifiers, config), visible tests `CPP/tests/cpp/{check.hpp,fakes.hpp,harness.hpp,test_main.cpp,profile_service_tests.cpp}`, hidden `hidden/CPP/tests/cpp/hidden_tests.cpp` (lands at `CPP/tests/cpp/hidden_tests.cpp`).
- C++17, no external deps. `check.hpp` is a tiny self-registering test framework:
  ```cpp
  #pragma once
  #include <functional> <map> <stdexcept> <string> <vector> <iostream> <sstream>
  struct CheckFailure : std::runtime_error { using std::runtime_error::runtime_error; };
  using TestFn = std::function<void()>;
  std::map<std::string, TestFn>& test_registry();   // defined in test_main.cpp
  struct TestRegistrar { TestRegistrar(const char* name, TestFn fn) { test_registry()[name] = std::move(fn); } };
  #define TEST_CASE(name) static void name(); static TestRegistrar name##_registrar(#name, name); static void name()
  #define CHECK(cond) do { if (!(cond)) throw CheckFailure(std::string(__FILE__) + ":" + std::to_string(__LINE__) + " CHECK failed: " #cond); } while (0)
  #define CHECK_EQ(a, b) ... (stringify both sides with operator<< via a helper; for types without <<, use CHECK((a) == (b)))
  ```
  `test_main.cpp` defines `test_registry()` and `main(argc, argv)`: with `--list` prints one test name per line; with a test name runs only that test (exit 0 pass / 1 fail, printing the failure message); with no args runs all and prints `PASS: name` / `FAIL: name  <msg>` lines and a `N passed, M failed` summary, exit 1 if any failed.
- CMakeLists.txt: globs `src/*.cpp` and `tests/cpp/*.cpp` into one executable `incident_tests`; `enable_testing()`; then registers ONE CTest test per TEST_CASE by scanning the test sources at configure time:
  ```cmake
  file(GLOB TEST_SOURCES ${CMAKE_SOURCE_DIR}/tests/cpp/*.cpp)
  foreach(src ${TEST_SOURCES})
    file(STRINGS ${src} lines REGEX "^TEST_CASE\\(")
    foreach(line ${lines})
      string(REGEX REPLACE "^TEST_CASE\\(([A-Za-z0-9_]+)\\).*" "\\1" name "${line}")
      add_test(NAME ${name} COMMAND incident_tests ${name})
    endforeach()
  endforeach()
  ```
  Each TEST_CASE must therefore start at column 0 on its own line: `TEST_CASE(test_cache_hit_skips_origin) {`.
- verify.sh: `cmake -S . -B build -DCMAKE_BUILD_TYPE=Release` && `cmake --build build` && `(cd build && ctest --output-on-failure)`; exit with ctest status; print the ctest summary.
- Types: `struct Profile { std::string tenant_id, user_id, display_name, email; int version; bool operator==... }`, `std::optional<Profile>`, `struct ServiceConfig { std::string key_version = "v2"; int profile_ttl_s = 600; int negative_ttl_s = 30; bool negative_caching_enabled = true; static ServiceConfig from_map(const std::map<std::string,std::string>&); }`, `struct ApiResponse { int status; std::map<std::string,std::string> body; }` (version rendered as string in body), interfaces as abstract classes with virtual methods (`CacheStore`, `ProfileOrigin`, `Clock`), `CacheUnavailableError : std::runtime_error`. The service holds references/shared_ptr to the injected collaborators; the test `World` owns them. `World::with_config(config)` must return a World sharing the same cache/origin/clock objects but a fresh Metrics (as in Python).

## Semantics that must be preserved exactly
- FakeCacheStore: entry expires when `clock.now() >= expires_at` (expired entries are removed on get). `set` records `(key, value, ttl)` in `set_calls`. `seed(key, value, ttl)` bypasses `fail_sets`. `raw_value(key)` returns the stored string ignoring expiry. `keys()` sorted. `fail_gets` / `fail_sets` flags raise CacheUnavailableError("ECONNRESET").
- FakeOrigin: `put`, `load` (counts `load_count` and appends to `load_calls`), `save`.
- `World.with_config(config)` shares clock/cache/origin, fresh Metrics, new service+api.
- `profile(tenant, user, display_name=None, email=None, version=1)` helper defaults: name `User {user} of {tenant}`, email `u{user}@t{tenant}.example`.
- Broken codec: `encode` joins `display_name|email|version`; `decode(raw, tenant_id, user_id)` splits on `|`, throws if field count != 3, returns Profile with the REQUESTER's tenant/user ids. Fixed codec: payload `v3` + length-prefixed fields `len:value` for tenant_id, user_id, display_name, email, version; `decode(raw)` returns optional/null on any malformed input.
- Broken key: `"p" + tenant_id + user_id`. Fixed key: `profile:<key_version>:<len>:<tenant>:<len>:<user>`.
- Broken service: as Python main (negative sentinel stored with profile_ttl_s, ignores negative_caching_enabled, create_profile does not invalidate, cached hit decoded with requester ids, no validation). Fixed service: as Python solution (validate owner ids, evict on mismatch/decode error with metrics `cache.tenant_mismatch` / `cache.decode_error`, sentinel only when enabled and with negative_ttl_s, sentinel ignored when disabled, create_profile invalidates).
- Api: 400 if either id fails `^[A-Za-z0-9:_-]{1,64}$`; 500 if the service throws; 404 if null; else 200 with body fields tenant_id, user_id, display_name, email, version.

## When done
Run your verify.sh in all three states (broken, broken+hidden, fixed+hidden) and report the three result lines, plus the T1-T4 file:line table and the exception type/message. Remove any hidden overlay files you copied into `<LANG>/` before finishing (the hidden files must only live under `hidden/`), and remove build outputs (`build/`, `target/`) or leave them ignored; do not leave stray files elsewhere in the repo. Keep the repo free of comments in src/tests.
