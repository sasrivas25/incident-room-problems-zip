#!/usr/bin/env bash
# Measures pass counts for main, solution and two partial-fix states, per language, with the hidden overlay.
# Usage: ./scoring_runs.sh  (expects the repo on branch main with broken src)
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
REPO="$HERE/../tenant-cache-leak-incident"
WORK="${TMPDIR:-/tmp/claude-501}/scoring"
source /Users/ssrivastav2/Documents/Repo/_gronex-tools/env.sh
rm -rf "$WORK"; mkdir -p "$WORK"

count_results() {
  local lang="$1" log="$2"
  case "$lang" in
    PYTHON) grep -oE '[0-9]+ passed|[0-9]+ failed' "$log" | tr '\n' ' ' ;;
    JAVA) grep -oE 'Tests run: [0-9]+, Failures: [0-9]+, Errors: [0-9]+' "$log" | tail -1 ;;
    NODEJS) grep -E '^ℹ (pass|fail) ' "$log" | tr '\n' ' ' ;;
    CPP) grep -oE '[0-9]+% tests passed, [0-9]+ tests failed out of [0-9]+|100% tests passed, 0 tests failed out of [0-9]+' "$log" | tail -1 ;;
  esac
}

run_state() {
  local lang="$1" state="$2" src_dir="$3"
  local dir="$WORK/$lang-$state"
  rm -rf "$dir"; mkdir -p "$dir"
  cp -R "$REPO/$lang/." "$dir/"
  rm -rf "$dir/build" "$dir/target"
  cp -R "$REPO/hidden/$lang/." "$dir/"
  if [ -n "$src_dir" ]; then
    case "$lang" in
      JAVA) rm -rf "$dir/src/main/java"; cp -R "$src_dir/main/java" "$dir/src/main/java" ;;
      *) rm -rf "$dir/src"; cp -R "$src_dir" "$dir/src" ;;
    esac
  fi
  (cd "$dir" && ./verify.sh > "$dir/verify.log" 2>&1)
  echo "| $lang | $state | $(count_results "$lang" "$dir/verify.log") |"
}

echo "| Language | State | Result (visible + hidden) |"
echo "| --- | --- | --- |"
for lang in PYTHON JAVA NODEJS CPP; do
  run_state "$lang" "main" ""
  run_state "$lang" "partial-key-only" "$HERE/partials/$lang/key-only/src"
  run_state "$lang" "naive-symptom" "$HERE/partials/$lang/naive/src"
  run_state "$lang" "solution" "$HERE/solution/$lang/src"
done
