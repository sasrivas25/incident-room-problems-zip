# Triage marking key: Cross-Tenant Profile Leak (30 points)

## Canonical root cause

Deploy `2026.10.29-r2` (PROF-4471) replaced the namespaced cache key `profile:{key_version}:{tenant}:{user}` with a bare concatenation `p{tenant}{user}`. The new key is not injective: tenant `12` user `345` and tenant `123` user `45` both map to `p12345`, so one tenant's cached profile is served to another. The same collision poisons negative caching: a not-found sentinel written for a non-existent `(7, 77)` hides the real user `(77, 7)` under `p777`, producing the 404 spike. Two aggravating faults in the same change make the exposure invisible and long-lived: the compact payload dropped the owner's tenant and user ids, so the read path cannot detect a foreign entry, and the not-found sentinel is stored with the 600 s positive TTL instead of the 30 s negative TTL (and the `negative_caching_enabled` switch is ignored).

A full-credit answer names the key collision as the mechanism. Naming only "the r2 deploy broke the cache" without the collision is partial.

## Evidence that proves it

Quote any two of these for full evidence credit.

1. `logs/app.log` 09:15:12 and 09:15:19, the same key for two tenants:
   `GET /v1/tenants/123/users/45 status=200 cache=miss key=p12345` followed by `cache.set key=p12345 ttl=600 bytes=41`, then `GET /v1/tenants/12/users/345 status=200 cache=hit key=p12345`.
2. `logs/app.log` 09:16:05 and 09:16:09, negative poisoning across tenants:
   `GET /v1/tenants/7/users/77 status=404 cache=miss origin=not_found key=p777`, `cache.set key=p777 value=__NOT_FOUND__ ttl=600`, then `GET /v1/tenants/77/users/7 status=404 cache=negative key=p777`. The same user `(77, 7)` was a 200 cache hit at 09:11:41 under `profile:v2:77:7`.
3. `logs/app.log` 09:18:30 to 09:18:52, the invalidation hand-off: `PUT /v1/tenants/123/users/45` deletes `p12345`, tenant 12 repopulates it, and tenant 123 then gets a hit on tenant 12's data.
4. Pre-deploy lines use `key=profile:v2:12:345` and `key=profile:v2:123:45` (09:08:40, 09:11:02); post-deploy lines use `p12345`. The runbook's "Cache key format" section still documents the namespaced format, which shows the change removed the delimiters and the `key_version` segment.
5. `metrics/cache.csv` and `dashboard.md`: distinct key count settles about 18 percent below baseline from 09:26 with request rate unchanged, and hit ratio ends above its pre-incident baseline. Fewer distinct keys for the same population means keys are being shared. This clue exists only in the metrics.
6. `metrics/traffic.csv`: `http_404_ratio` climbs from the first r2 pod at 09:14:02 and plateaus after 09:16:30, with no relationship to the hit ratio dip, which had recovered by 09:15:45.
7. The 500s at 09:17:44, 09:22:10 and 09:31:02: `compact payload: expected 3 fields, got 4` for a display name containing `|`, with the trace in `codec`. This proves the payload format changed and is fragile; it is supporting evidence, not the root cause.

## Red herring

The `cache-3` restart at 09:13:12: `ECONNRESET` warnings with a stack trace, `cache topology changed`, the eviction spike on cache-1 and cache-2, and the `cache_hit_ratio` alert. It is one minute before the deploy, so time correlation tempts contestants to blame it. It is wrong because: the hit ratio alert resolved at 09:15:45 while 404s and the leak kept growing; the runbook lists a node restart as a self-healing event; the service's fallback worked (`cache=error` requests returned 200 from the origin); and a node loss cannot make one tenant's key resolve to another tenant's value. Contestants who name the restart as the cause score zero on root cause.

## Acceptable mitigations (first action, before the code fix)

Any of these earns full mitigation credit if the contestant says why it stops the exposure:

- Roll back to r1 (restores the namespaced key builder; old-format entries are still valid; about 3 minutes). Best answer.
- Rotate `key_version` to invalidate the namespace. Partial on its own: the broken builder ignores `key_version`, so this does nothing until the code is fixed. Full credit only if the contestant notices this from the code and pairs it with rollback or a hotfix.
- Disable negative caching to stop the 404s. Partial: it addresses only the 404 symptom and the broken switch is ignored by the r2 code, which the contestant can see in `service`.
- FLUSHALL on the cluster: zero mitigation credit. The runbook forbids it (PROF-3302) and the colliding keys would be rewritten within seconds.

## Rubric

| Component | Points | Full credit | Partial | Zero |
| --- | --- | --- | --- | --- |
| Root cause | 15 | Non-injective key `p{tenant}{user}` from r2 causes cross-tenant key sharing; names negative-cache poisoning and/or missing owner ids in the payload as the aggravators. (15) | Names the r2 key change but not the collision mechanism, or names the collision but attributes the 404s to the cache restart. (7-9) | Names the cache-3 restart, evictions, or ECONNRESET as the cause. Or "cache TTL too long" alone. (0-2) |
| Evidence | 10 | Two or more concrete lines or metrics from the list above, including at least one log line with a shared key. (10) | One correct piece of evidence, or evidence that only shows the symptom (the 404 alert line, the support ticket). (4-6) | Only red herring evidence (ECONNRESET trace, hit ratio alert). (0) |
| Mitigation | 5 | Rollback, with the reasoning that old-format entries remain valid and the exposure stops within one rollout. (5) | key_version rotation or disabling negative caching, without noticing those switches are ignored by the r2 code. (2-3) | FLUSHALL, or "restart cache-3 again", or "increase cache memory". (0) |

### Worked examples

- Full credit (30): "r2 builds cache keys as `p` + tenant + user with no delimiter and no version, so (12,345) and (123,45) share `p12345`; see 09:15:12 and 09:15:19 where tenant 12 gets a hit on an entry set by tenant 123, and 09:16:05 to 09:16:09 where a not-found sentinel for (7,77) 404s the real (77,7). The payload no longer carries the owner tenant, so the hit cannot be validated, and sentinels use the 600 s TTL. The cache-3 restart is unrelated: alert resolved at 09:15:45. Mitigate by rolling back to r1 now; old-format keys are still intact."
- Partial (about 16): "The new compact cache keys from the deploy are colliding between tenants, which leaks profiles. Evidence: 404 alert at 09:19 and the support ticket. Mitigation: flip `negative_caching_enabled` to false and rotate `key_version`." Root cause 11 (mechanism named loosely, no aggravators), evidence 3 (symptoms only), mitigation 2 (both switches are ignored by r2 code).
- Correct symptom, wrong cause (about 5): "Profiles are being served to the wrong tenant because cache-3 restarted and its key range moved to cache-1 and cache-2, mixing up entries. Evidence: ECONNRESET trace at 09:13:14 and the eviction spike. Mitigation: FLUSHALL and restart the pods." Root cause 2, evidence 0 (red herring only), mitigation 0. Add 3 if they at least quote a shared-key line.
- Named only the red herring (0-3): "Cache node restart caused eviction storm and stale data." Root cause 0, evidence 0, mitigation up to 3 if they propose rollback for an unrelated reason.
