#!/usr/bin/env python3
"""Render Grafana-styled PNG dashboards from the generated CSVs."""
import csv
import os
from datetime import datetime

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
METRICS = os.path.join(os.path.dirname(HERE), "tenant-cache-leak-incident", "PYTHON", "metrics")
OUT = os.path.join(HERE, "images")
os.makedirs(OUT, exist_ok=True)


def load(name):
    with open(os.path.join(METRICS, name)) as f:
        rows = list(csv.DictReader(f))
    times = [datetime.strptime(r["timestamp"], "%Y-%m-%dT%H:%M:%S.%fZ") for r in rows]
    return times, rows


EVENTS = [
    ("2026-10-29T09:13:12", "cache-3 restart", "#9aa0a6", ":"),
    ("2026-10-29T09:14:02", "deploy r2 start", "#ff9830", "-"),
    ("2026-10-29T09:16:30", "rollout complete", "#ff9830", "--"),
    ("2026-10-29T09:13:45", "alert cache_hit_ratio", "#f2495c", ":"),
    ("2026-10-29T09:19:15", "alert http_404_ratio", "#f2495c", "-"),
]


def style(ax, title, unit=""):
    ax.set_facecolor("#181b1f")
    ax.set_title(title, loc="left", fontsize=11, color="#d8d9da", pad=6)
    ax.grid(color="#2c3235", linewidth=0.6)
    ax.tick_params(colors="#9aa0a6", labelsize=8)
    for s in ax.spines.values():
        s.set_color("#2c3235")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    ax.xaxis.set_major_locator(mdates.MinuteLocator(interval=5))
    if unit:
        ax.set_ylabel(unit, color="#9aa0a6", fontsize=8)


def annotate(ax, label_y=None):
    for when, label, color, ls in EVENTS:
        x = datetime.strptime(when, "%Y-%m-%dT%H:%M:%S")
        ax.axvline(x, color=color, linestyle=ls, linewidth=1.1, alpha=0.9)


def legend_events(fig):
    handles = [plt.Line2D([0], [0], color=c, linestyle=ls, label=l) for _, l, c, ls in EVENTS]
    fig.legend(handles=handles, loc="lower center", ncol=5, fontsize=8, frameon=False, labelcolor="#d8d9da")


def fig_traffic():
    times, rows = load("traffic.csv")
    _, crow = load("cache.csv")
    fig, axes = plt.subplots(4, 1, figsize=(13, 10), sharex=True)
    fig.patch.set_facecolor("#111217")
    fig.suptitle("profile-service  |  2026-10-29 09:00-09:35 UTC  |  traffic and errors", color="#d8d9da", fontsize=13, x=0.02, ha="left")
    ax = axes[0]; style(ax, "Request rate", "req/s")
    ax.plot(times, [float(r["requests_per_s"]) for r in rows], color="#73bf69", linewidth=1.4); ax.set_ylim(380, 460); annotate(ax)
    ax = axes[1]; style(ax, "Cache hit ratio", "ratio")
    ax.plot(times, [float(r["cache_hit_ratio"]) for r in crow], color="#5794f2", linewidth=1.4); ax.axhline(0.80, color="#f2495c", linewidth=0.8, linestyle="--"); ax.set_ylim(0.55, 1.0); annotate(ax)
    ax = axes[2]; style(ax, "HTTP 404 ratio and 5xx ratio", "ratio")
    ax.plot(times, [float(r["http_404_ratio"]) for r in rows], color="#fade2a", linewidth=1.4, label="404")
    ax.plot(times, [float(r["http_5xx_ratio"]) for r in rows], color="#f2495c", linewidth=1.2, label="5xx")
    ax.axhline(0.020, color="#f2495c", linewidth=0.8, linestyle="--"); ax.legend(fontsize=8, frameon=False, labelcolor="#d8d9da", loc="upper left"); annotate(ax)
    ax = axes[3]; style(ax, "Origin DB queries and p99", "qps / ms")
    ax.plot(times, [float(r["origin_qps"]) for r in rows], color="#b877d9", linewidth=1.4, label="origin qps")
    ax.plot(times, [float(r["origin_p99_ms"]) for r in rows], color="#ff9830", linewidth=1.0, label="origin p99 ms")
    ax.axhline(180, color="#f2495c", linewidth=0.8, linestyle="--"); ax.legend(fontsize=8, frameon=False, labelcolor="#d8d9da", loc="upper left"); annotate(ax)
    legend_events(fig)
    fig.tight_layout(rect=(0, 0.04, 1, 0.96))
    fig.savefig(os.path.join(OUT, "dashboard-traffic.png"), dpi=130, facecolor=fig.get_facecolor())


def fig_cache():
    times, rows = load("cache.csv")
    fig, axes = plt.subplots(3, 1, figsize=(13, 8), sharex=True)
    fig.patch.set_facecolor("#111217")
    fig.suptitle("profile-service cache cluster  |  2026-10-29 09:00-09:35 UTC", color="#d8d9da", fontsize=13, x=0.02, ha="left")
    ax = axes[0]; style(ax, "Distinct keys (cluster total)", "keys")
    ax.plot(times, [int(r["cache_distinct_keys"]) for r in rows], color="#5794f2", linewidth=1.5)
    ax.axhline(1_840_000, color="#9aa0a6", linewidth=0.8, linestyle="--"); ax.text(times[2], 1_852_000, "pre-incident baseline 1.84M", color="#9aa0a6", fontsize=8)
    ax.axhline(1_510_000, color="#fade2a", linewidth=0.8, linestyle="--"); ax.text(times[2], 1_522_000, "steady state after 09:26: 1.51M (-18%)", color="#fade2a", fontsize=8)
    ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v/1e6:.2f}M")); annotate(ax)
    ax = axes[1]; style(ax, "Memory used (cluster total)", "MB")
    ax.plot(times, [int(r["cache_memory_mb"]) for r in rows], color="#73bf69", linewidth=1.5); annotate(ax)
    ax = axes[2]; style(ax, "Evictions", "per s")
    ax.plot(times, [int(r["cache_evictions_per_s"]) for r in rows], color="#f2495c", linewidth=1.5); ax.set_yscale("symlog", linthresh=50); annotate(ax)
    legend_events(fig)
    fig.tight_layout(rect=(0, 0.05, 1, 0.95))
    fig.savefig(os.path.join(OUT, "dashboard-cache.png"), dpi=130, facecolor=fig.get_facecolor())


if __name__ == "__main__":
    fig_traffic()
    fig_cache()
    print("wrote", sorted(os.listdir(OUT)))
