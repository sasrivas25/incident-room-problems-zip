#include "service.hpp"

#include "cache_keys.hpp"
#include "codec.hpp"

ProfileService::ProfileService(const ServiceConfig& config, CacheStore& cache, ProfileOrigin& origin, Clock& clock, Metrics& metrics)
    : config_(config), cache_(cache), origin_(origin), clock_(clock), metrics_(metrics) {}

std::optional<Profile> ProfileService::get_profile(const std::string& tenant_id, const std::string& user_id) {
    const std::string key = build_profile_key(config_, tenant_id, user_id);
    std::optional<std::string> raw = cache_get(key);
    if (raw.has_value()) {
        if (is_negative(*raw)) {
            metrics_.increment("cache.negative_hit");
            return std::nullopt;
        }
        metrics_.increment("cache.hit");
        return decode_profile(*raw, tenant_id, user_id);
    }
    metrics_.increment("cache.miss");
    std::optional<Profile> profile = load_from_origin(tenant_id, user_id);
    if (!profile.has_value()) {
        cache_set(key, NEGATIVE_SENTINEL, config_.profile_ttl_s);
        return std::nullopt;
    }
    cache_set(key, encode_profile(*profile), config_.profile_ttl_s);
    return profile;
}

void ProfileService::update_profile(const Profile& profile) {
    origin_.save(profile);
    cache_delete(build_profile_key(config_, profile.tenant_id, profile.user_id));
}

void ProfileService::create_profile(const Profile& profile) {
    origin_.save(profile);
}

std::optional<Profile> ProfileService::load_from_origin(const std::string& tenant_id, const std::string& user_id) {
    metrics_.increment("origin.load");
    return origin_.load(tenant_id, user_id);
}

std::optional<std::string> ProfileService::cache_get(const std::string& key) {
    try {
        return cache_.get(key);
    } catch (const CacheUnavailableError&) {
        metrics_.increment("cache.error");
        return std::nullopt;
    }
}

void ProfileService::cache_set(const std::string& key, const std::string& value, int ttl_s) {
    try {
        cache_.set(key, value, ttl_s);
    } catch (const CacheUnavailableError&) {
        metrics_.increment("cache.error");
    }
}

void ProfileService::cache_delete(const std::string& key) {
    try {
        cache_.remove(key);
    } catch (const CacheUnavailableError&) {
        metrics_.increment("cache.error");
    }
}
