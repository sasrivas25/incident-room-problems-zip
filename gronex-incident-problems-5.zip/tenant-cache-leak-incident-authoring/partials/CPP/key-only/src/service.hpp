#pragma once

#include <optional>
#include <string>

#include "cache_store.hpp"
#include "clock.hpp"
#include "config.hpp"
#include "metrics.hpp"
#include "models.hpp"
#include "origin.hpp"

class ProfileService {
public:
    ProfileService(const ServiceConfig& config, CacheStore& cache, ProfileOrigin& origin, Clock& clock, Metrics& metrics);

    std::optional<Profile> get_profile(const std::string& tenant_id, const std::string& user_id);
    void update_profile(const Profile& profile);
    void create_profile(const Profile& profile);

private:
    std::optional<Profile> load_from_origin(const std::string& tenant_id, const std::string& user_id);
    std::optional<std::string> cache_get(const std::string& key);
    void cache_set(const std::string& key, const std::string& value, int ttl_s);
    void cache_delete(const std::string& key);

    ServiceConfig config_;
    CacheStore& cache_;
    ProfileOrigin& origin_;
    Clock& clock_;
    Metrics& metrics_;
};
