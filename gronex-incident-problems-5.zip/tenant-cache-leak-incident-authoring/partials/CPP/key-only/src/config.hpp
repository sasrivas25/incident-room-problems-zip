#pragma once

#include <map>
#include <string>

struct ServiceConfig {
    std::string key_version = "v2";
    int profile_ttl_s = 600;
    int negative_ttl_s = 30;
    bool negative_caching_enabled = true;

    static ServiceConfig from_map(const std::map<std::string, std::string>& values);
};
