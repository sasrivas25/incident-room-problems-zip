#pragma once

#include <string>

#include "config.hpp"

extern const std::string KEY_PREFIX;
extern const std::string SEGMENT_SEPARATOR;

std::string build_profile_key(const ServiceConfig& config, const std::string& tenant_id, const std::string& user_id);
