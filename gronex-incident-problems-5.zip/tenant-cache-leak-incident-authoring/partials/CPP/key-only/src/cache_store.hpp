#pragma once

#include <optional>
#include <stdexcept>
#include <string>

struct CacheUnavailableError : std::runtime_error {
    using std::runtime_error::runtime_error;
};

class CacheStore {
public:
    virtual ~CacheStore() = default;
    virtual std::optional<std::string> get(const std::string& key) = 0;
    virtual void set(const std::string& key, const std::string& value, int ttl_s) = 0;
    virtual void remove(const std::string& key) = 0;
};
