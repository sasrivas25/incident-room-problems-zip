#include "codec.hpp"

#include <stdexcept>
#include <vector>

const std::string NEGATIVE_SENTINEL = "__NOT_FOUND__";
const std::string FIELD_SEPARATOR = "|";
const std::size_t COMPACT_FIELD_COUNT = 3;

namespace {

std::vector<std::string> split(const std::string& raw, const std::string& separator) {
    std::vector<std::string> parts;
    std::size_t position = 0;
    while (true) {
        std::size_t next = raw.find(separator, position);
        if (next == std::string::npos) {
            parts.push_back(raw.substr(position));
            return parts;
        }
        parts.push_back(raw.substr(position, next - position));
        position = next + separator.size();
    }
}

}

std::string encode_profile(const Profile& profile) {
    return profile.display_name + FIELD_SEPARATOR + profile.email + FIELD_SEPARATOR + std::to_string(profile.version);
}

Profile decode_profile(const std::string& raw, const std::string& tenant_id, const std::string& user_id) {
    std::vector<std::string> parts = split(raw, FIELD_SEPARATOR);
    if (parts.size() != COMPACT_FIELD_COUNT) {
        throw std::runtime_error("compact payload: expected " + std::to_string(COMPACT_FIELD_COUNT) + " fields, got " + std::to_string(parts.size()));
    }
    return Profile{tenant_id, user_id, parts[0], parts[1], std::stoi(parts[2])};
}

bool is_negative(const std::string& raw) {
    return raw == NEGATIVE_SENTINEL;
}
