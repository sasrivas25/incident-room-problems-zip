#pragma once

#include <optional>
#include <string>

#include "models.hpp"

class ProfileOrigin {
public:
    virtual ~ProfileOrigin() = default;
    virtual std::optional<Profile> load(const std::string& tenant_id, const std::string& user_id) = 0;
    virtual void save(const Profile& profile) = 0;
};
