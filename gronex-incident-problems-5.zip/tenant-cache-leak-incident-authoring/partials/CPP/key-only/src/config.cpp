#include "config.hpp"

namespace {

std::string get_or(const std::map<std::string, std::string>& values, const std::string& key, const std::string& fallback) {
    auto it = values.find(key);
    return it == values.end() ? fallback : it->second;
}

bool parse_bool(const std::string& value) {
    return value == "true" || value == "True" || value == "1" || value == "yes";
}

}

ServiceConfig ServiceConfig::from_map(const std::map<std::string, std::string>& values) {
    ServiceConfig config;
    config.key_version = get_or(values, "key_version", "v2");
    config.profile_ttl_s = std::stoi(get_or(values, "profile_ttl_s", "600"));
    config.negative_ttl_s = std::stoi(get_or(values, "negative_ttl_s", "30"));
    config.negative_caching_enabled = parse_bool(get_or(values, "negative_caching_enabled", "true"));
    return config;
}
