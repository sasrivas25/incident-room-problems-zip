#include "api.hpp"

#include <exception>
#include <optional>

#include "identifiers.hpp"

ProfileApi::ProfileApi(ProfileService& service) : service_(service) {}

ApiResponse ProfileApi::get_profile(const std::string& tenant_id, const std::string& user_id) {
    if (!is_valid_identifier(tenant_id) || !is_valid_identifier(user_id)) {
        return ApiResponse{400, {{"error", "invalid_identifier"}}};
    }
    std::optional<Profile> profile;
    try {
        profile = service_.get_profile(tenant_id, user_id);
    } catch (const std::exception&) {
        return ApiResponse{500, {{"error", "internal"}}};
    }
    if (!profile.has_value()) {
        return ApiResponse{404, {{"error", "not_found"}}};
    }
    return ApiResponse{200, {
        {"tenant_id", profile->tenant_id},
        {"user_id", profile->user_id},
        {"display_name", profile->display_name},
        {"email", profile->email},
        {"version", std::to_string(profile->version)},
    }};
}
