#pragma once

#include <string>

#include "models.hpp"

extern const std::string NEGATIVE_SENTINEL;
extern const std::string FIELD_SEPARATOR;
extern const std::size_t COMPACT_FIELD_COUNT;

std::string encode_profile(const Profile& profile);

Profile decode_profile(const std::string& raw, const std::string& tenant_id, const std::string& user_id);

bool is_negative(const std::string& raw);
