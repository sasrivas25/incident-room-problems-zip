#include "identifiers.hpp"

#include <regex>

const char* const IDENTIFIER_PATTERN = "^[A-Za-z0-9:_-]{1,64}$";

bool is_valid_identifier(const std::string& value) {
    static const std::regex pattern(IDENTIFIER_PATTERN);
    return std::regex_match(value, pattern);
}
