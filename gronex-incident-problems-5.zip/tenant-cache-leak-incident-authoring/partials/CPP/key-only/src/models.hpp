#pragma once

#include <string>

struct Profile {
    std::string tenant_id;
    std::string user_id;
    std::string display_name;
    std::string email;
    int version = 1;

    bool operator==(const Profile& other) const {
        return tenant_id == other.tenant_id && user_id == other.user_id && display_name == other.display_name &&
               email == other.email && version == other.version;
    }

    bool operator!=(const Profile& other) const { return !(*this == other); }
};
