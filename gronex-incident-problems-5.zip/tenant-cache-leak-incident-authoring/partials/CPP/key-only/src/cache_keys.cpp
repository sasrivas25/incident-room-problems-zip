#include "cache_keys.hpp"

const std::string KEY_PREFIX = "profile";
const std::string SEGMENT_SEPARATOR = ":";

namespace {

std::string length_prefixed(const std::string& value) {
    return std::to_string(value.size()) + SEGMENT_SEPARATOR + value;
}

}

std::string build_profile_key(const ServiceConfig& config, const std::string& tenant_id, const std::string& user_id) {
    return KEY_PREFIX + SEGMENT_SEPARATOR + config.key_version + SEGMENT_SEPARATOR + length_prefixed(tenant_id) +
           SEGMENT_SEPARATOR + length_prefixed(user_id);
}
