#pragma once

#include <map>
#include <string>

#include "service.hpp"

struct ApiResponse {
    int status;
    std::map<std::string, std::string> body;
};

class ProfileApi {
public:
    explicit ProfileApi(ProfileService& service);

    ApiResponse get_profile(const std::string& tenant_id, const std::string& user_id);

private:
    ProfileService& service_;
};
