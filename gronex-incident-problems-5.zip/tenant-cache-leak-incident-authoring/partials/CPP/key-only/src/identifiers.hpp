#pragma once

#include <string>

extern const char* const IDENTIFIER_PATTERN;

bool is_valid_identifier(const std::string& value);
