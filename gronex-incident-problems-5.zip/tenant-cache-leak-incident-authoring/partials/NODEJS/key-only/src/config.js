'use strict';

const DEFAULTS = Object.freeze({
  keyVersion: 'v2',
  profileTtlS: 600,
  negativeTtlS: 30,
  negativeCachingEnabled: true,
});

function serviceConfig(overrides = {}) {
  return Object.freeze({ ...DEFAULTS, ...overrides });
}

function configFromDict(values = {}) {
  return serviceConfig({
    keyVersion: String(values.key_version ?? DEFAULTS.keyVersion),
    profileTtlS: Number.parseInt(values.profile_ttl_s ?? DEFAULTS.profileTtlS, 10),
    negativeTtlS: Number.parseInt(values.negative_ttl_s ?? DEFAULTS.negativeTtlS, 10),
    negativeCachingEnabled: Boolean(values.negative_caching_enabled ?? DEFAULTS.negativeCachingEnabled),
  });
}

module.exports = { DEFAULTS, serviceConfig, configFromDict };
