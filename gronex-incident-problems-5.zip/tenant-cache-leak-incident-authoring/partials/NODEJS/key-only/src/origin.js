'use strict';

class ProfileOrigin {
  load(tenantId, userId) {
    throw new Error('not implemented');
  }

  save(profile) {
    throw new Error('not implemented');
  }
}

module.exports = { ProfileOrigin };
