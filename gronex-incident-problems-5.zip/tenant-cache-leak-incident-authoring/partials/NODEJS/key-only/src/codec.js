'use strict';

const { makeProfile } = require('./models');

const NEGATIVE_SENTINEL = '__NOT_FOUND__';
const FIELD_SEPARATOR = '|';
const COMPACT_FIELD_COUNT = 3;

function encodeProfile(profile) {
  return [profile.displayName, profile.email, String(profile.version)].join(FIELD_SEPARATOR);
}

function decodeProfile(raw, tenantId, userId) {
  const parts = raw.split(FIELD_SEPARATOR);
  if (parts.length !== COMPACT_FIELD_COUNT) {
    throw new Error(`compact payload: expected ${COMPACT_FIELD_COUNT} fields, got ${parts.length}`);
  }
  const [displayName, email, version] = parts;
  const parsedVersion = Number.parseInt(version, 10);
  if (Number.isNaN(parsedVersion)) {
    throw new Error(`compact payload: invalid version ${JSON.stringify(version)}`);
  }
  return makeProfile(tenantId, userId, displayName, email, parsedVersion);
}

function isNegative(raw) {
  return raw === NEGATIVE_SENTINEL;
}

module.exports = { NEGATIVE_SENTINEL, FIELD_SEPARATOR, COMPACT_FIELD_COUNT, encodeProfile, decodeProfile, isNegative };
