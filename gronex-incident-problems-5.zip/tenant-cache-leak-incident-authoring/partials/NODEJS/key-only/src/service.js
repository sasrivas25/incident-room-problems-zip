'use strict';

const { buildProfileKey } = require('./cache_keys');
const { CacheUnavailableError } = require('./cache_store');
const { NEGATIVE_SENTINEL, decodeProfile, encodeProfile, isNegative } = require('./codec');

class ProfileService {
  constructor(config, cache, origin, clock, metrics) {
    this._config = config;
    this._cache = cache;
    this._origin = origin;
    this._clock = clock;
    this._metrics = metrics;
  }

  getProfile(tenantId, userId) {
    const key = buildProfileKey(this._config, tenantId, userId);
    const raw = this._cacheGet(key);
    if (raw != null) {
      if (isNegative(raw)) {
        this._metrics.increment('cache.negative_hit');
        return null;
      }
      this._metrics.increment('cache.hit');
      return decodeProfile(raw, tenantId, userId);
    }
    this._metrics.increment('cache.miss');
    const profile = this._loadFromOrigin(tenantId, userId);
    if (profile == null) {
      this._cacheSet(key, NEGATIVE_SENTINEL, this._config.profileTtlS);
      return null;
    }
    this._cacheSet(key, encodeProfile(profile), this._config.profileTtlS);
    return profile;
  }

  updateProfile(profile) {
    this._origin.save(profile);
    this._cacheDelete(buildProfileKey(this._config, profile.tenantId, profile.userId));
  }

  createProfile(profile) {
    this._origin.save(profile);
  }

  _loadFromOrigin(tenantId, userId) {
    this._metrics.increment('origin.load');
    return this._origin.load(tenantId, userId);
  }

  _cacheGet(key) {
    try {
      return this._cache.get(key);
    } catch (err) {
      if (err instanceof CacheUnavailableError) {
        this._metrics.increment('cache.error');
        return null;
      }
      throw err;
    }
  }

  _cacheSet(key, value, ttlS) {
    try {
      this._cache.set(key, value, ttlS);
    } catch (err) {
      if (err instanceof CacheUnavailableError) {
        this._metrics.increment('cache.error');
        return;
      }
      throw err;
    }
  }

  _cacheDelete(key) {
    try {
      this._cache.delete(key);
    } catch (err) {
      if (err instanceof CacheUnavailableError) {
        this._metrics.increment('cache.error');
        return;
      }
      throw err;
    }
  }
}

module.exports = { ProfileService };
