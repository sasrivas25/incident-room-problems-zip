'use strict';

class CacheUnavailableError extends Error {
  constructor(message) {
    super(message);
    this.name = 'CacheUnavailableError';
  }
}

class CacheStore {
  get(key) {
    throw new Error('not implemented');
  }

  set(key, value, ttlS) {
    throw new Error('not implemented');
  }

  delete(key) {
    throw new Error('not implemented');
  }
}

module.exports = { CacheUnavailableError, CacheStore };
