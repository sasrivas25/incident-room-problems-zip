'use strict';

function makeProfile(tenantId, userId, displayName, email, version) {
  return Object.freeze({ tenantId, userId, displayName, email, version });
}

module.exports = { makeProfile };
