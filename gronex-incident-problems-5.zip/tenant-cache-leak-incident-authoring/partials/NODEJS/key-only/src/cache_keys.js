'use strict';

const KEY_PREFIX = 'profile';
const SEGMENT_SEPARATOR = ':';

function buildProfileKey(config, tenantId, userId) {
  return [KEY_PREFIX, config.keyVersion, lengthPrefixed(tenantId), lengthPrefixed(userId)].join(SEGMENT_SEPARATOR);
}

function lengthPrefixed(value) {
  return `${value.length}${SEGMENT_SEPARATOR}${value}`;
}

module.exports = { KEY_PREFIX, SEGMENT_SEPARATOR, buildProfileKey };
