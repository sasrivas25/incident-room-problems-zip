'use strict';

const IDENTIFIER_PATTERN = /^[A-Za-z0-9:_-]{1,64}$/;

function isValidIdentifier(value) {
  return typeof value === 'string' && IDENTIFIER_PATTERN.test(value);
}

module.exports = { IDENTIFIER_PATTERN, isValidIdentifier };
