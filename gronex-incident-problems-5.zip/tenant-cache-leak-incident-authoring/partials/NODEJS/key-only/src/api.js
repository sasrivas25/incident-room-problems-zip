'use strict';

const { isValidIdentifier } = require('./identifiers');

function apiResponse(status, body) {
  return Object.freeze({ status, body: Object.freeze({ ...body }) });
}

class ProfileApi {
  constructor(service) {
    this._service = service;
  }

  getProfile(tenantId, userId) {
    if (!isValidIdentifier(tenantId) || !isValidIdentifier(userId)) {
      return apiResponse(400, { error: 'invalid_identifier' });
    }
    let profile;
    try {
      profile = this._service.getProfile(tenantId, userId);
    } catch (err) {
      return apiResponse(500, { error: 'internal' });
    }
    if (profile == null) {
      return apiResponse(404, { error: 'not_found' });
    }
    return apiResponse(200, {
      tenant_id: profile.tenantId,
      user_id: profile.userId,
      display_name: profile.displayName,
      email: profile.email,
      version: profile.version,
    });
  }
}

module.exports = { apiResponse, ProfileApi };
