'use strict';

const KEY_PREFIX = 'p';

function buildProfileKey(config, tenantId, userId) {
  return KEY_PREFIX + ':' + tenantId + ':' + userId;
}

module.exports = { KEY_PREFIX, buildProfileKey };
