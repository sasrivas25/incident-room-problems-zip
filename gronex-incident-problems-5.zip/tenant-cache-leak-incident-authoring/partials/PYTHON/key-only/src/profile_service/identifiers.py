import re

IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z0-9:_-]{1,64}$")


def is_valid_identifier(value: str) -> bool:
    return bool(IDENTIFIER_PATTERN.match(value))
