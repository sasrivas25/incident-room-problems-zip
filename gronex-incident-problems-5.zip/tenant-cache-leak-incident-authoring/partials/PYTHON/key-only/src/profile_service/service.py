from typing import Optional

from .cache_keys import build_profile_key
from .cache_store import CacheStore, CacheUnavailableError
from .clock import Clock
from .codec import NEGATIVE_SENTINEL, decode_profile, encode_profile, is_negative
from .config import ServiceConfig
from .metrics import Metrics
from .models import Profile
from .origin import ProfileOrigin


class ProfileService:
    def __init__(self, config: ServiceConfig, cache: CacheStore, origin: ProfileOrigin, clock: Clock, metrics: Metrics) -> None:
        self._config = config
        self._cache = cache
        self._origin = origin
        self._clock = clock
        self._metrics = metrics

    def get_profile(self, tenant_id: str, user_id: str) -> Optional[Profile]:
        key = build_profile_key(self._config, tenant_id, user_id)
        raw = self._cache_get(key)
        if raw is not None:
            if is_negative(raw):
                self._metrics.increment("cache.negative_hit")
                return None
            self._metrics.increment("cache.hit")
            return decode_profile(raw, tenant_id, user_id)
        self._metrics.increment("cache.miss")
        profile = self._load_from_origin(tenant_id, user_id)
        if profile is None:
            self._cache_set(key, NEGATIVE_SENTINEL, self._config.profile_ttl_s)
            return None
        self._cache_set(key, encode_profile(profile), self._config.profile_ttl_s)
        return profile

    def update_profile(self, profile: Profile) -> None:
        self._origin.save(profile)
        self._cache_delete(build_profile_key(self._config, profile.tenant_id, profile.user_id))

    def create_profile(self, profile: Profile) -> None:
        self._origin.save(profile)

    def _load_from_origin(self, tenant_id: str, user_id: str) -> Optional[Profile]:
        self._metrics.increment("origin.load")
        return self._origin.load(tenant_id, user_id)

    def _cache_get(self, key: str) -> Optional[str]:
        try:
            return self._cache.get(key)
        except CacheUnavailableError:
            self._metrics.increment("cache.error")
            return None

    def _cache_set(self, key: str, value: str, ttl_s: int) -> None:
        try:
            self._cache.set(key, value, ttl_s)
        except CacheUnavailableError:
            self._metrics.increment("cache.error")

    def _cache_delete(self, key: str) -> None:
        try:
            self._cache.delete(key)
        except CacheUnavailableError:
            self._metrics.increment("cache.error")
