from dataclasses import dataclass


@dataclass(frozen=True)
class Profile:
    tenant_id: str
    user_id: str
    display_name: str
    email: str
    version: int
