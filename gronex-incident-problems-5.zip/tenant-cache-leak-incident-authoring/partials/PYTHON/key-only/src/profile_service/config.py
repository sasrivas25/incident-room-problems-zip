from dataclasses import dataclass


@dataclass(frozen=True)
class ServiceConfig:
    key_version: str = "v2"
    profile_ttl_s: int = 600
    negative_ttl_s: int = 30
    negative_caching_enabled: bool = True

    @staticmethod
    def from_dict(values: dict) -> "ServiceConfig":
        return ServiceConfig(
            key_version=str(values.get("key_version", "v2")),
            profile_ttl_s=int(values.get("profile_ttl_s", 600)),
            negative_ttl_s=int(values.get("negative_ttl_s", 30)),
            negative_caching_enabled=bool(values.get("negative_caching_enabled", True)),
        )
