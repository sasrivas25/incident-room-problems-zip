from .models import Profile

NEGATIVE_SENTINEL = "__NOT_FOUND__"
FIELD_SEPARATOR = "|"
COMPACT_FIELD_COUNT = 3


def encode_profile(profile: Profile) -> str:
    return FIELD_SEPARATOR.join([profile.display_name, profile.email, str(profile.version)])


def decode_profile(raw: str, tenant_id: str, user_id: str) -> Profile:
    parts = raw.split(FIELD_SEPARATOR)
    if len(parts) != COMPACT_FIELD_COUNT:
        raise ValueError(f"compact payload: expected {COMPACT_FIELD_COUNT} fields, got {len(parts)}")
    display_name, email, version = parts
    return Profile(tenant_id, user_id, display_name, email, int(version))


def is_negative(raw: str) -> bool:
    return raw == NEGATIVE_SENTINEL
