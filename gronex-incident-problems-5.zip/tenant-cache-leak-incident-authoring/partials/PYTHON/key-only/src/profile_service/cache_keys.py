from .config import ServiceConfig

KEY_PREFIX = "profile"
SEGMENT_SEPARATOR = ":"


def build_profile_key(config: ServiceConfig, tenant_id: str, user_id: str) -> str:
    return SEGMENT_SEPARATOR.join([KEY_PREFIX, config.key_version, _length_prefixed(tenant_id), _length_prefixed(user_id)])


def _length_prefixed(value: str) -> str:
    return f"{len(value)}{SEGMENT_SEPARATOR}{value}"
