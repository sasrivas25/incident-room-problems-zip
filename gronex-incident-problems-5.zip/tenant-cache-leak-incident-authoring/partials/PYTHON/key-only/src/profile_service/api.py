from dataclasses import dataclass

from .identifiers import is_valid_identifier
from .service import ProfileService


@dataclass(frozen=True)
class ApiResponse:
    status: int
    body: dict


class ProfileApi:
    def __init__(self, service: ProfileService) -> None:
        self._service = service

    def get_profile(self, tenant_id: str, user_id: str) -> ApiResponse:
        if not is_valid_identifier(tenant_id) or not is_valid_identifier(user_id):
            return ApiResponse(400, {"error": "invalid_identifier"})
        try:
            profile = self._service.get_profile(tenant_id, user_id)
        except Exception:
            return ApiResponse(500, {"error": "internal"})
        if profile is None:
            return ApiResponse(404, {"error": "not_found"})
        return ApiResponse(200, {
            "tenant_id": profile.tenant_id,
            "user_id": profile.user_id,
            "display_name": profile.display_name,
            "email": profile.email,
            "version": profile.version,
        })
