from typing import Optional

from .models import Profile


class ProfileOrigin:
    def load(self, tenant_id: str, user_id: str) -> Optional[Profile]:
        raise NotImplementedError

    def save(self, profile: Profile) -> None:
        raise NotImplementedError
