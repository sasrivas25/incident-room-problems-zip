package com.gronex.profiles;

import static com.gronex.profiles.CacheKeys.buildProfileKey;
import static com.gronex.profiles.Codec.NEGATIVE_SENTINEL;
import static com.gronex.profiles.Codec.decodeProfile;
import static com.gronex.profiles.Codec.encodeProfile;
import static com.gronex.profiles.Codec.isNegative;

public class ProfileService {
    private final ServiceConfig config;
    private final CacheStore cache;
    private final ProfileOrigin origin;
    private final Clock clock;
    private final Metrics metrics;

    public ProfileService(ServiceConfig config, CacheStore cache, ProfileOrigin origin, Clock clock, Metrics metrics) {
        this.config = config;
        this.cache = cache;
        this.origin = origin;
        this.clock = clock;
        this.metrics = metrics;
    }

    public Profile getProfile(String tenantId, String userId) {
        String key = buildProfileKey(config, tenantId, userId);
        String raw = cacheGet(key);
        if (raw != null) {
            if (isNegative(raw)) {
                metrics.increment("cache.negative_hit");
                return null;
            }
            metrics.increment("cache.hit");
            return decodeProfile(raw, tenantId, userId);
        }
        metrics.increment("cache.miss");
        Profile profile = loadFromOrigin(tenantId, userId);
        if (profile == null) {
            cacheSet(key, NEGATIVE_SENTINEL, config.negativeTtlS());
            return null;
        }
        cacheSet(key, encodeProfile(profile), config.profileTtlS());
        return profile;
    }

    public void updateProfile(Profile profile) {
        origin.save(profile);
        cacheDelete(buildProfileKey(config, profile.tenantId(), profile.userId()));
    }

    public void createProfile(Profile profile) {
        origin.save(profile);
    }

    private Profile loadFromOrigin(String tenantId, String userId) {
        metrics.increment("origin.load");
        return origin.load(tenantId, userId);
    }

    private String cacheGet(String key) {
        try {
            return cache.get(key);
        } catch (CacheUnavailableError e) {
            metrics.increment("cache.error");
            return null;
        }
    }

    private void cacheSet(String key, String value, int ttlS) {
        try {
            cache.set(key, value, ttlS);
        } catch (CacheUnavailableError e) {
            metrics.increment("cache.error");
        }
    }

    private void cacheDelete(String key) {
        try {
            cache.delete(key);
        } catch (CacheUnavailableError e) {
            metrics.increment("cache.error");
        }
    }
}
