package com.gronex.profiles;

public final class CacheKeys {
    public static final String KEY_PREFIX = "p";

    private CacheKeys() {
    }

    public static String buildProfileKey(ServiceConfig config, String tenantId, String userId) {
        return KEY_PREFIX + ":" + tenantId + ":" + userId;
    }
}
