package com.gronex.profiles;

public class CacheUnavailableError extends RuntimeException {
    public CacheUnavailableError(String message) {
        super(message);
    }
}
