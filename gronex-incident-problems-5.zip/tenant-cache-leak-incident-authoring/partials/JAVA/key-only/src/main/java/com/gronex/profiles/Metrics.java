package com.gronex.profiles;

import java.util.HashMap;
import java.util.Map;

public class Metrics {
    private final Map<String, Integer> counters = new HashMap<>();

    public void increment(String name) {
        increment(name, 1);
    }

    public void increment(String name, int amount) {
        counters.merge(name, amount, Integer::sum);
    }

    public int value(String name) {
        return counters.getOrDefault(name, 0);
    }
}
