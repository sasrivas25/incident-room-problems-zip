package com.gronex.profiles;

public interface ProfileOrigin {
    Profile load(String tenantId, String userId);

    void save(Profile profile);
}
