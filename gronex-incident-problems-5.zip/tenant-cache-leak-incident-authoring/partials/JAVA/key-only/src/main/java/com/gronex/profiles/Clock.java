package com.gronex.profiles;

public interface Clock {
    double now();
}
