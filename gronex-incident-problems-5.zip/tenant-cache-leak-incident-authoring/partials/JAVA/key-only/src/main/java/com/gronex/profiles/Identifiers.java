package com.gronex.profiles;

import java.util.regex.Pattern;

public final class Identifiers {
    public static final Pattern IDENTIFIER_PATTERN = Pattern.compile("^[A-Za-z0-9:_-]{1,64}$");

    private Identifiers() {
    }

    public static boolean isValidIdentifier(String value) {
        return value != null && IDENTIFIER_PATTERN.matcher(value).matches();
    }
}
