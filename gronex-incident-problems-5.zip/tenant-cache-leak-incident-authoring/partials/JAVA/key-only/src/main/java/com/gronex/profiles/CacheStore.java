package com.gronex.profiles;

public interface CacheStore {
    String get(String key);

    void set(String key, String value, int ttlS);

    void delete(String key);
}
