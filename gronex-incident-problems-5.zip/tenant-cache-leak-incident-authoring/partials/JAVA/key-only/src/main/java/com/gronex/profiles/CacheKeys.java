package com.gronex.profiles;

public final class CacheKeys {
    public static final String KEY_PREFIX = "profile";
    public static final String SEGMENT_SEPARATOR = ":";

    private CacheKeys() {
    }

    public static String buildProfileKey(ServiceConfig config, String tenantId, String userId) {
        return String.join(SEGMENT_SEPARATOR, KEY_PREFIX, config.keyVersion(), lengthPrefixed(tenantId), lengthPrefixed(userId));
    }

    private static String lengthPrefixed(String value) {
        return value.length() + SEGMENT_SEPARATOR + value;
    }
}
