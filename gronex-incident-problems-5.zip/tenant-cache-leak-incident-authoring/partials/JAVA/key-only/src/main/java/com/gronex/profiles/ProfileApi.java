package com.gronex.profiles;

import static com.gronex.profiles.Identifiers.isValidIdentifier;

import java.util.LinkedHashMap;
import java.util.Map;

public class ProfileApi {
    private final ProfileService service;

    public ProfileApi(ProfileService service) {
        this.service = service;
    }

    public ApiResponse getProfile(String tenantId, String userId) {
        if (!isValidIdentifier(tenantId) || !isValidIdentifier(userId)) {
            return new ApiResponse(400, Map.of("error", "invalid_identifier"));
        }
        Profile profile;
        try {
            profile = service.getProfile(tenantId, userId);
        } catch (Exception e) {
            return new ApiResponse(500, Map.of("error", "internal"));
        }
        if (profile == null) {
            return new ApiResponse(404, Map.of("error", "not_found"));
        }
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("tenant_id", profile.tenantId());
        body.put("user_id", profile.userId());
        body.put("display_name", profile.displayName());
        body.put("email", profile.email());
        body.put("version", profile.version());
        return new ApiResponse(200, body);
    }
}
