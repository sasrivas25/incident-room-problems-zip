package com.gronex.profiles;

import java.util.regex.Pattern;

public final class Codec {
    public static final String NEGATIVE_SENTINEL = "__NOT_FOUND__";
    public static final String FIELD_SEPARATOR = "|";
    public static final int COMPACT_FIELD_COUNT = 3;

    private Codec() {
    }

    public static String encodeProfile(Profile profile) {
        return String.join(FIELD_SEPARATOR, profile.displayName(), profile.email(), String.valueOf(profile.version()));
    }

    public static Profile decodeProfile(String raw, String tenantId, String userId) {
        String[] parts = raw.split(Pattern.quote(FIELD_SEPARATOR), -1);
        if (parts.length != COMPACT_FIELD_COUNT) {
            throw new IllegalStateException("compact payload: expected " + COMPACT_FIELD_COUNT + " fields, got " + parts.length);
        }
        return new Profile(tenantId, userId, parts[0], parts[1], Integer.parseInt(parts[2]));
    }

    public static boolean isNegative(String raw) {
        return NEGATIVE_SENTINEL.equals(raw);
    }
}
