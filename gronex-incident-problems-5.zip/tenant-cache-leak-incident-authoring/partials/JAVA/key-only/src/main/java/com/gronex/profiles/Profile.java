package com.gronex.profiles;

public record Profile(String tenantId, String userId, String displayName, String email, int version) {
}
