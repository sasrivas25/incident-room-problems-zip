package com.gronex.profiles;

import java.util.Map;

public record ApiResponse(int status, Map<String, Object> body) {
}
