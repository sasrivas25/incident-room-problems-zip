package com.gronex.profiles;

import java.util.Map;

public record ServiceConfig(String keyVersion, int profileTtlS, int negativeTtlS, boolean negativeCachingEnabled) {

    public static ServiceConfig defaults() {
        return new ServiceConfig("v2", 600, 30, true);
    }

    public static ServiceConfig fromMap(Map<String, Object> values) {
        return new ServiceConfig(
                String.valueOf(values.getOrDefault("key_version", "v2")),
                toInt(values.getOrDefault("profile_ttl_s", 600)),
                toInt(values.getOrDefault("negative_ttl_s", 30)),
                toBoolean(values.getOrDefault("negative_caching_enabled", true)));
    }

    public ServiceConfig withKeyVersion(String value) {
        return new ServiceConfig(value, profileTtlS, negativeTtlS, negativeCachingEnabled);
    }

    public ServiceConfig withProfileTtlS(int value) {
        return new ServiceConfig(keyVersion, value, negativeTtlS, negativeCachingEnabled);
    }

    public ServiceConfig withNegativeTtlS(int value) {
        return new ServiceConfig(keyVersion, profileTtlS, value, negativeCachingEnabled);
    }

    public ServiceConfig withNegativeCachingEnabled(boolean value) {
        return new ServiceConfig(keyVersion, profileTtlS, negativeTtlS, value);
    }

    private static int toInt(Object value) {
        if (value instanceof Number number) {
            return number.intValue();
        }
        return Integer.parseInt(String.valueOf(value));
    }

    private static boolean toBoolean(Object value) {
        if (value instanceof Boolean flag) {
            return flag;
        }
        return Boolean.parseBoolean(String.valueOf(value));
    }
}
