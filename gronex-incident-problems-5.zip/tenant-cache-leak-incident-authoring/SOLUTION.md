# Solution review: Cross-Tenant Profile Leak

This is the post-contest walkthrough. It reconstructs the incident from the artifacts, names each fault, explains the fix and the trade-off, and lists what would have caught it earlier.

## Timeline reconstructed from the logs

| Time (UTC) | Source | What happened |
| --- | --- | --- |
| 09:08:40, 09:11:02 | app.log | Tenants 123 and 12 are served under distinct keys `profile:v2:123:45` and `profile:v2:12:345`. Normal. |
| 09:13:10 to 09:13:48 | cache.log, app.log | cache-3 reboots for host maintenance. `ECONNRESET` warnings, ring remap, evictions spike on cache-1 and cache-2, `cache_hit_ratio` alert at 09:13:45. Requests fall back to the origin and return 200. |
| 09:14:02 to 09:16:30 | deploy.log, app.log | Build 2026.10.29-r2 rolls out pod by pod. New pods log compact keys `p...`. The rollout controller marks SUCCESS at 09:16:35 because error rate, p99 and memory trend all look good. |
| 09:15:12, 09:15:19 | app.log | Tenant 123 user 45 populates `p12345`; seven seconds later tenant 12 user 345 gets a cache hit on the same key. First observable leak. |
| 09:15:45 | app.log | `cache_hit_ratio` alert resolves. The red herring is over. |
| 09:16:05, 09:16:09 | app.log | A lookup of the non-existent (7, 77) writes a not-found sentinel under `p777` with `ttl=600`; the real user (77, 7) then 404s from the negative cache. It is still 404 at 09:21:40, 09:24:49 and 09:33:31. |
| 09:17:44 | app.log | A profile whose display name contains `|` fails to decode: `compact payload: expected 3 fields, got 4`, stack trace in `codec`. Repeats at 09:22:10 and 09:31:02. |
| 09:18:30 to 09:18:52 | app.log | Tenant 123 updates user 45, which deletes `p12345`; tenant 12 repopulates it; tenant 123 now gets a hit on tenant 12's data. |
| 09:19:15 | app.log | `http_404_ratio` alert fires at 2.1 percent, climbing to 3.4 percent. |
| 09:21:04 | statement | Support escalation SUP-88213. |
| 09:26 onward | cache.csv | Distinct key count settles at 1.51M, 18 percent below the 1.84M baseline, with request rate unchanged. Hit ratio settles above its baseline. |

## Root cause and faults

### Fault 1: the cache key is not injective

`cache_keys` builds `"p" + tenant_id + user_id`. Concatenating two variable-length strings without a delimiter is not injective: `(12, 345)` and `(123, 45)` both produce `p12345`. Every collision serves one tenant's profile to another, and the invalidation on update hands the key back and forth between the two tenants. The builder also ignores `config.key_version`, so the runbook's "rotate key_version" lever silently does nothing.

Fix: `profile:{key_version}:{len}:{tenant}:{len}:{user}`. The length prefix makes the encoding injective even when ids contain the delimiter, which the runbook allows (`:` is in the id alphabet). A delimiter alone fixes digit ids and fails the hidden test with `12:3` / `3:45`.

### Fault 2: negative caching is poisoned, long-lived and unswitchable

On an origin miss the service stores `__NOT_FOUND__` under the same colliding key with `profile_ttl_s` (600 s) instead of `negative_ttl_s` (30 s). A missing user in one tenant therefore hides an existing user in another tenant for ten minutes, which is the 404 spike. `create_profile` does not invalidate, so a freshly created user 404s until the sentinel expires. The `negative_caching_enabled` switch is read by nobody, so the runbook's mitigation is a no-op.

Fix: sentinel written only when the switch is on and with `negative_ttl_s`; on read, a sentinel is ignored when the switch is off; `create_profile` deletes the key.

### Fault 3: the cached payload cannot be validated

The compact payload is `display_name|email|version`. It no longer carries the owner's tenant and user ids; `decode_profile` fills in the requester's ids, so a foreign entry looks like a legitimate hit. The `|` separator also breaks on display names containing `|`, which is the 500s.

Fix: payload `v3` with length-prefixed fields including tenant and user id; `decode_profile` returns nothing on malformed input; the service rejects any entry whose owner differs from the request, counts `cache.tenant_mismatch` (or `cache.decode_error`), deletes the entry and reloads from the origin. This is invariant I1 in the runbook, enforced at the read boundary.

### Why the order matters

Fixing fault 2 alone makes the 404 alert disappear within 30 seconds while the leak continues. Fixing fault 1 alone stops new collisions but leaves no defence against entries written by old pods during the rolling deploy and gives up the runbook's rotation lever if `key_version` is still ignored. Fixing fault 3 alone catches every leak at the cost of an origin reload on each poisoned read, and the 404s remain. All three together restore the invariants; the hidden suite checks each independently.

## Why the cache-3 restart is a red herring

It is the loudest thing in the logs: a stack trace, topology changes, an eviction storm and an alert. It is also one minute before the deploy, so time correlation points at it. But the alert resolved at 09:15:45 while the 404 ratio kept climbing; the fallback path worked (requests logged `cache=error` returned 200 from the origin); and a node leaving the ring moves key ranges between nodes, it cannot map two different keys to one value. The runbook lists the restart as a self-healing event. The deploy log even notes that the degraded ring was not a rollout gate, which is correct.

## The trade-off

The fastest way to stop the exposure was a rollback to r1. The fix-forward keeps most of PROF-4471's memory saving (payload grows by two short ids and five length prefixes) and adds a decode plus two string comparisons on every hit. The alternative of flushing the cluster would have stopped exposure a few seconds sooner at the cost of 420 origin qps, twice the documented ceiling, and the runbook records the last time that was tried. Because the new keys live in a different namespace, the fix never reads a poisoned entry; the old `p...` keys age out under their 600 s TTL with no operator action.

Rejected alternatives:

- Delimiter-only key: not injective for ids containing `:`, and no `key_version`.
- Hashing the key: fixes injectivity in practice, but makes the key opaque in logs and still needs the version segment and owner validation.
- Validate on read without changing the key: correct but every colliding read costs an origin load and an eviction; the hit ratio for colliding pairs becomes zero.
- Disable negative caching permanently: shifts enumeration and typo traffic to the origin; keep it with the tenant-scoped key and a 30 s TTL.

## Key files in the fix

- `cache_keys`: versioned, length-prefixed key.
- `codec`: `v3` payload with owner ids; decode is total and returns nothing on malformed input.
- `service`: owner validation on hit, eviction and metrics on mismatch, sentinel TTL and switch handling, invalidation on create.

## What would have caught it sooner

- A post-deploy correctness check comparing a sample of cached responses with the origin by tenant, not only error rate and latency.
- An alert on distinct key count diverging from the active user population, or on hit ratio rising above its historical band with flat traffic.
- A unit test that the key builder is injective over a set of ids including the delimiter, and one that the key contains `key_version`.
- Counting `cache.tenant_mismatch` in production as a security signal; it was zero only because nothing checked.
- A runbook review as part of the change that removed the key format it documented.
