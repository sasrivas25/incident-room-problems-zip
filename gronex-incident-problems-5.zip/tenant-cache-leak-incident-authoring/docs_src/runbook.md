# profile-service on-call runbook

Owner: Identity Platform team. Pager: `#identity-oncall`. Last reviewed 2026-08-14.

## Service summary

`profile-service` serves `GET /v1/tenants/{tenant_id}/users/{user_id}` for every customer workspace. Reads go through a shared cache cluster (3 nodes, consistent hashing, `allkeys-lru`, 1024 MB per node) in front of the profiles database (the origin). Writes (`PUT`, `POST`) go to the origin and invalidate the cache entry.

Traffic: about 420 req/s steady, 90 percent served from cache. The origin is sized for roughly 200 qps; above that, p99 degrades and other tenants of the shared database are affected.

## Request path

```
client -> edge -> profile-service pod (6 pods) -> cache cluster (cache-1, cache-2, cache-3)
                                              \-> profiles DB (origin) on miss
```

Read-through logic in `service`: build key, cache get, decode on hit, otherwise load from origin and populate. A miss on the origin writes a short-lived not-found sentinel so repeated lookups of deleted or mistyped users do not reach the database (negative caching).

## Cache key format

Keys are namespaced per tenant and per key version:

```
profile:{key_version}:{tenant_id}:{user_id}
```

`key_version` comes from config (`key_version`, currently `v2`). Rotating it is the supported way to invalidate the whole profile namespace without flushing the cluster; the old entries age out under their TTL.

## Invariants

| Id | Invariant |
| --- | --- |
| I1 | A profile is never served to a tenant other than its owner. Enforce this at the read boundary (what comes back from the cache), not only through key construction. |
| I2 | Tenant and user ids are opaque strings, 1 to 64 characters, alphabet `A-Z a-z 0-9 : _ -`. Numeric-looking ids are common but not guaranteed. Never assume ids have a fixed length. |
| I3 | A not-found sentinel lives at most `negative_ttl_s` (30 s). A positive entry lives `profile_ttl_s` (600 s). |
| I4 | Creating a profile must make it readable immediately, including when a not-found sentinel exists for that id. |
| I5 | Cache unavailability degrades to origin reads; it never fails a request. |

## Configuration

| Key | Default | Effect |
| --- | --- | --- |
| `key_version` | `v2` | Namespace segment in every key. Rotate to invalidate everything. |
| `profile_ttl_s` | `600` | TTL of positive entries. |
| `negative_ttl_s` | `30` | TTL of not-found sentinels. |
| `negative_caching_enabled` | `true` | When false, misses are not cached and existing sentinels are ignored. |

Config is injected at pod start; a change requires a pod restart (about 30 s per pod, rolling).

## Alerts

| Alert | Threshold | Usual cause |
| --- | --- | --- |
| `cache_hit_ratio` | below 0.80 for 30 s | Cache node restart or ring change. Self-heals in 2 to 3 minutes as the cold node refills. No action unless origin qps exceeds 180. |
| `http_404_ratio` | above 0.020 for 60 s | Bulk user deletion by a tenant, or a client bug. Check which tenants dominate the 404s. |
| `http_5xx_ratio` | above 0.010 for 60 s | Origin outage or a deploy regression. |
| `origin_qps` | above 180 for 60 s | Cache failure. Consider shedding load before the shared database degrades. |

## Known failure modes

### Cache node restart

Hit ratio drops to about 0.6 while the ring remaps, evictions spike on the surviving nodes because they take the extra key range at their memory limit, and the origin sees 3 to 5 times its normal load for about two minutes. Metrics recover without intervention. Do not flush or restart anything else.

### Origin slow

p99 above 200 ms with hit ratio normal. Page the database on-call. The cache keeps absorbing 90 percent of reads.

### Bad deploy

Rollback is manual for this service (`rollout undo profile-service`). Auto-rollback was disabled after PROF-3302 because the rollout controller rolled back a good build during a cache incident.

## Mitigation levers, fastest first

1. Rollback the deploy if the symptom correlates with a rollout. About 3 minutes for 6 pods.
2. Disable negative caching (`negative_caching_enabled=false`) when users report 404s for profiles that exist. Costs about 15 origin qps. Existing sentinels must stop being served as soon as the switch is off.
3. Rotate `key_version` to drop every cached profile at once. Origin load rises to roughly 100 qps for the first minute, within capacity.
4. Never run FLUSHALL on the cluster in production. PROF-3302 (2026-03-11): a flush during peak sent 420 qps to the origin, which saturated the shared database for 11 minutes and took three other services down with it.

## Verification after a fix

- `cache.tenant_mismatch` and `cache.decode_error` counters should be zero in steady state; a non-zero rate means poisoned entries are still being read and rejected.
- Hit ratio should return to 0.90 to 0.92. A hit ratio noticeably above the historical baseline with unchanged traffic is suspicious, not good news.
- Distinct key count on the cluster should match the active (tenant, user) population; compare against the previous day at the same hour.

## Escalation

- Identity Platform lead: `#identity-platform`.
- Data protection: any confirmed cross-tenant exposure must be reported to `#privacy-incidents` within one hour with the affected tenant ids and the exposure window.
