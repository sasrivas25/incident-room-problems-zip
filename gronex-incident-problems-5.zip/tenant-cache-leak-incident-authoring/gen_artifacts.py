#!/usr/bin/env python3
"""Generate logs, metrics CSVs and dashboard.md for tenant-cache-leak-incident.

Single source of truth for timestamps, request ids and spikes. Writes identical
copies into every language folder; only the stack traces are language specific
(frames come from trace_lines.json).
"""
import csv
import json
import math
import os
import random
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.join(os.path.dirname(HERE), "tenant-cache-leak-incident")
LANGS = ["PYTHON", "JAVA", "NODEJS", "CPP"]
T0 = datetime(2026, 10, 29, 9, 0, 0, tzinfo=timezone.utc)
END = 35 * 60

CACHE3_DOWN = 13 * 60 + 12
CACHE3_UP = 13 * 60 + 48
HIT_ALERT_FIRE = 13 * 60 + 45
HIT_ALERT_RESOLVE = 15 * 60 + 45
DEPLOY_START = 14 * 60 + 2
POD_SWITCH = [DEPLOY_START + 30 * k for k in range(5)] + [DEPLOY_START + 148]
DEPLOY_DONE = POD_SWITCH[-1]
NOTFOUND_ALERT = 19 * 60 + 15
DECODE_ERRORS = [17 * 60 + 44.120, 22 * 60 + 10.447, 31 * 60 + 2.903]
BASELINE_KEYS = 1_840_000
STEADY_KEYS = 1_510_000

rng = random.Random(20261029)


def ts(seconds):
    return (T0 + timedelta(seconds=seconds)).strftime("%Y-%m-%dT%H:%M:%S.") + f"{int(round((seconds % 1) * 1000)) % 1000:03d}Z"


def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def smooth(x):
    x = clamp(x)
    return x * x * (3 - 2 * x)


def r2_fraction(t):
    return sum(1 for s in POD_SWITCH if t >= s) / len(POD_SWITCH)


def metric_rps(t):
    return 420 + 6 * math.sin(t / 300.0) + rng.uniform(-4, 4)


def metric_hit_ratio(t):
    base = 0.91 + rng.uniform(-0.004, 0.004)
    if CACHE3_DOWN <= t < CACHE3_UP:
        base = 0.91 - 0.29 * smooth((t - CACHE3_DOWN) / 15.0)
    elif CACHE3_UP <= t < HIT_ALERT_RESOLVE + 15:
        base = 0.62 + 0.27 * smooth((t - CACHE3_UP) / (HIT_ALERT_RESOLVE + 15 - CACHE3_UP)) + rng.uniform(-0.004, 0.004)
    boost = 0.025 * r2_fraction(t) * smooth((t - DEPLOY_START) / 720.0) if t >= DEPLOY_START else 0.0
    return round(clamp(base + boost), 3)


def metric_404(t):
    base = 0.004 + rng.uniform(-0.0006, 0.0006)
    rise = 0.030 * r2_fraction(t) * smooth((t - DEPLOY_START) / 420.0) if t >= DEPLOY_START else 0.0
    return round(base + rise, 4)


def metric_5xx(t):
    for e in DECODE_ERRORS:
        if t <= e < t + 15:
            return round(0.0019 + rng.uniform(0, 0.0006), 4)
    return 0.0


def metric_keys(t):
    if t < CACHE3_DOWN:
        return int(BASELINE_KEYS + rng.uniform(-1500, 1500))
    if t < CACHE3_UP:
        return int(1_236_000 + rng.uniform(-800, 800))
    refill = 1_236_000 + (1_800_000 - 1_236_000) * (1 - math.exp(-(t - CACHE3_UP) / 70.0))
    glide = 1_800_000 - (1_800_000 - STEADY_KEYS) * smooth((t - 1000) / 560.0) if t >= 1000 else 1_800_000
    return int(min(refill, glide) + rng.uniform(-1500, 1500))


def metric_memory(t):
    if t < CACHE3_DOWN:
        return int(2100 + rng.uniform(-6, 6))
    if t < CACHE3_UP:
        return int(1410 + rng.uniform(-4, 4))
    refill = 1410 + (2060 - 1410) * (1 - math.exp(-(t - CACHE3_UP) / 70.0))
    glide = 2060 - (2060 - 1480) * smooth((t - 1000) / 560.0) if t >= 1000 else 2060
    return int(min(refill, glide) + rng.uniform(-6, 6))


def metric_evictions(t):
    base = 20 + rng.uniform(-3, 3)
    if CACHE3_DOWN <= t < CACHE3_DOWN + 40:
        return int(1200 - 300 * (t - CACHE3_DOWN) / 40.0 + rng.uniform(-30, 30))
    if CACHE3_DOWN + 40 <= t < 960:
        return int(base + 880 * math.exp(-(t - (CACHE3_DOWN + 40)) / 35.0))
    if 1000 <= t < 1500:
        return int(base + 45 * math.sin(math.pi * (t - 1000) / 500.0))
    return int(base)


def metric_origin_qps(rps, hit_ratio):
    return round(rps * (1 - hit_ratio) * 1.0 + rng.uniform(-0.8, 0.8), 1)


def metric_origin_p99(t, hit_ratio):
    return round(18 + (0.91 - hit_ratio) * 80 + rng.uniform(-0.8, 0.8), 1)


def build_metrics():
    rows = []
    for t in range(0, END + 1, 15):
        rps = metric_rps(t)
        hit = metric_hit_ratio(t)
        rows.append({
            "timestamp": ts(t),
            "t": t,
            "requests_per_s": round(rps, 1),
            "http_404_ratio": metric_404(t),
            "http_5xx_ratio": metric_5xx(t),
            "origin_qps": metric_origin_qps(rps, hit),
            "origin_p99_ms": metric_origin_p99(t, hit),
            "cache_hit_ratio": hit,
            "cache_distinct_keys": metric_keys(t),
            "cache_memory_mb": metric_memory(t),
            "cache_evictions_per_s": metric_evictions(t),
        })
    return rows


def write_csvs(rows, out_dir):
    traffic_cols = ["timestamp", "requests_per_s", "http_404_ratio", "http_5xx_ratio", "origin_qps", "origin_p99_ms"]
    cache_cols = ["timestamp", "cache_hit_ratio", "cache_distinct_keys", "cache_memory_mb", "cache_evictions_per_s"]
    for name, cols in (("traffic.csv", traffic_cols), ("cache.csv", cache_cols)):
        with open(os.path.join(out_dir, name), "w", newline="") as f:
            w = csv.writer(f, lineterminator="\n")
            w.writerow(cols)
            for r in rows:
                w.writerow([r[c] for c in cols])


SPARK = "▁▂▃▄▅▆▇█"


def sparkline(values, lo=None, hi=None):
    lo = min(values) if lo is None else lo
    hi = max(values) if hi is None else hi
    span = hi - lo if hi > lo else 1.0
    return "".join(SPARK[min(7, int((v - lo) / span * 7.999))] for v in values)


def marker_row(times, events):
    row = [" "] * len(times)
    for t_ev, ch in events:
        idx = min(range(len(times)), key=lambda i: abs(times[i] - t_ev))
        row[idx] = ch
    return "".join(row)


def fmt(v, kind):
    if kind == "ratio":
        return f"{v:.3f}"
    if kind == "int":
        return f"{int(v):,}"
    return f"{v:.1f}"


def write_dashboard(rows, out_dir):
    sampled = rows[::2]
    times = [r["t"] for r in sampled]
    events = [(CACHE3_DOWN, "R"), (DEPLOY_START, "▲"), (DEPLOY_DONE, "△"), (HIT_ALERT_FIRE, "!"), (NOTFOUND_ALERT, "!")]
    marks = marker_row(times, events)
    axis = "09:00" + " " * (len(times) // 2 - 10) + "09:17:30" + " " * (len(times) - len(times) // 2 - 13) + "09:35"
    panels = [
        ("requests_per_s", "Request rate (req/s, all pods)", "num"),
        ("cache_hit_ratio", "Cache hit ratio (0-1)", "ratio"),
        ("http_404_ratio", "HTTP 404 ratio (0-1)", "ratio"),
        ("http_5xx_ratio", "HTTP 5xx ratio (0-1)", "ratio"),
        ("origin_qps", "Origin DB queries (qps)", "num"),
        ("origin_p99_ms", "Origin DB p99 latency (ms)", "num"),
        ("cache_distinct_keys", "Cache distinct keys (cluster total)", "int"),
        ("cache_memory_mb", "Cache memory used (MB, cluster total)", "int"),
        ("cache_evictions_per_s", "Cache evictions (per s, cluster total)", "num"),
    ]
    checkpoints = [(600, "09:10:00 baseline"), (CACHE3_DOWN + 18, "09:13:30 cache-3 down"), (DEPLOY_DONE, "09:16:30 rollout complete"),
                   (NOTFOUND_ALERT, "09:19:15 404 alert"), (1560, "09:26:00 steady state"), (END, "09:35:00 end")]
    by_t = {r["t"]: r for r in rows}
    lines = []
    lines.append("# profile-service dashboard, 2026-10-29 09:00-09:35 UTC")
    lines.append("")
    lines.append("Text rendering of `traffic.csv` and `cache.csv` (15 s resolution; charts below sample every 30 s, one character per sample).")
    lines.append("")
    lines.append("Markers under each chart: `R` cache-3 restart 09:13:12, `▲` deploy r2 started 09:14:02, `△` rollout complete 09:16:30, `!` alert fired (09:13:45 cache_hit_ratio, 09:19:15 http_404_ratio).")
    lines.append("")
    lines.append("## Timeline")
    lines.append("")
    lines.append("| Time (UTC) | Event |")
    lines.append("| --- | --- |")
    lines.append("| 09:13:10 | cache-3 host maintenance reboot begins |")
    lines.append("| 09:13:12 | cache-3 leaves the ring; its key range remaps to cache-1 and cache-2 |")
    lines.append("| 09:13:45 | ALERT cache_hit_ratio below 0.80 |")
    lines.append("| 09:13:48 | cache-3 rejoins the ring, cold |")
    lines.append("| 09:14:02 | deploy 2026.10.29-r2 (PROF-4471) starts, pod 1 of 6 |")
    lines.append("| 09:15:45 | cache_hit_ratio alert resolved |")
    lines.append("| 09:16:30 | rollout complete, 6 of 6 pods on r2 |")
    lines.append("| 09:19:15 | ALERT http_404_ratio above 0.020 |")
    lines.append("| 09:21:04 | Support escalation SUP-88213 (tenant 12 sees a tenant 123 profile), not in logs |")
    lines.append("")
    lines.append("## Panels")
    lines.append("")
    for col, title, kind in panels:
        vals = [r[col] for r in sampled]
        lines.append(f"### {title}")
        lines.append("")
        lines.append("```")
        lines.append(f"max {fmt(max(vals), kind)}")
        lines.append(sparkline(vals))
        lines.append(marks)
        lines.append(axis)
        lines.append(f"min {fmt(min(vals), kind)}")
        lines.append("```")
        lines.append("")
        lines.append("| Checkpoint | Value |")
        lines.append("| --- | --- |")
        for t_cp, label in checkpoints:
            lines.append(f"| {label} | {fmt(by_t[t_cp][col], kind)} |")
        lines.append("")
    lines.append("## Panel notes")
    lines.append("")
    lines.append("- Request rate is flat across the whole window. Nothing upstream changed.")
    lines.append("- Cache hit ratio dips with the cache-3 restart and recovers by 09:15:45. After the rollout it settles above the pre-incident baseline.")
    lines.append("- Origin query rate and p99 track the hit ratio dip and return to baseline; the origin is not the bottleneck at any point.")
    lines.append("- Distinct key count: the restart removes about a third of keys and the refill is nearly complete by 09:16. From 09:17 the count declines again and settles around 09:26, 18 percent below the pre-incident baseline, with request rate unchanged. Legacy entries written before 09:16:30 reach their 600 s TTL between 09:24 and 09:26:30.")
    lines.append("- Memory follows the key count and the smaller r2 payload.")
    lines.append("- Evictions spike while cache-1 and cache-2 absorb the cache-3 key range, then a mild second bump accompanies the key turnover after the rollout.")
    lines.append("- 404 ratio starts climbing with the first r2 pod and plateaus near 3.4 percent once all pods are on r2. It does not correlate with the hit ratio dip.")
    lines.append("- 5xx ratio shows three isolated blips (09:17:44, 09:22:10, 09:31:02); see the stack traces in app.log.")
    with open(os.path.join(out_dir, "dashboard.md"), "w") as f:
        f.write("\n".join(lines) + "\n")


def req_id():
    return f"{rng.getrandbits(32):08x}"


R1_PODS = [f"pp-5f8c-{k}" for k in range(1, 7)]
R2_PODS = [f"pp-7d2e-{k}" for k in range(1, 7)]
BASE_TENANTS = ["4821", "310", "1200", "9", "56", "3002", "640", "2048", "15", "777"]


def pod_at(t):
    k = rng.randrange(6)
    return R2_PODS[k] if t >= POD_SWITCH[k] else R1_PODS[k]


def is_r2(pod):
    return pod.startswith("pp-7d2e")


def key_for(pod, tenant, user):
    return f"p{tenant}{user}" if is_r2(pod) else f"profile:v2:{tenant}:{user}"


def payload_bytes(pod):
    return rng.randrange(36, 48) if is_r2(pod) else rng.randrange(108, 131)


def app_line(t, level, pod, req, msg):
    return (t, f"{ts(t)} {level:<5} [profile-service] pod={pod} req={req} {msg}")


def render_trace(cfg, kind):
    style = cfg["style"]
    if kind == "decode":
        frames = [cfg["api"], cfg["service_decode"], cfg["codec"]]
        error = cfg["decode_error"]
    else:
        frames = [cfg["api"], cfg["service_cache_call"], cfg["service_cache_get"]]
        error = cfg["cache_error"]
    out = []
    if style == "python":
        out.append("Traceback (most recent call last):")
        if kind == "cache":
            out.append("  File \"/srv/profile-service/lib/httpd/dispatcher.py\", line 88, in handle")
            out.append("    response = route(request)")
        for fr in frames:
            out.append(f"  File \"{cfg['root']}{fr['file']}\", line {fr['line']}, in {fr['func']}")
            out.append(f"    {fr['code']}")
        if kind == "cache":
            out.append("  File \"/srv/profile-service/lib/cachelib/client.py\", line 212, in get")
            out.append("    return self._connection_for(key).command(\"GET\", key)")
            out.append("  File \"/srv/profile-service/lib/cachelib/connection.py\", line 97, in command")
            out.append("    raise CacheUnavailableError(f\"{self.node}: ECONNRESET\") from exc")
        out.append(error)
    elif style == "java":
        pkg = cfg["package"]
        out.append(error)
        if kind == "cache":
            out.append(f"\tat {pkg}.cachelib.Connection.command(Connection.java:97)")
            out.append(f"\tat {pkg}.cachelib.CacheClient.get(CacheClient.java:212)")
        for fr in reversed(frames):
            cls = fr["file"].replace(".java", "")
            out.append(f"\tat {pkg}.{cls}.{fr['func']}({fr['file']}:{fr['line']})")
        out.append(f"\tat {pkg}.httpd.Dispatcher.handle(Dispatcher.java:88)")
        out.append("\tat java.base/java.lang.Thread.run(Thread.java:1583)")
    elif style == "node":
        out.append(error)
        if kind == "cache":
            out.append("    at Connection.command (/srv/profile-service/lib/cachelib/connection.js:97:11)")
            out.append("    at CacheClient.get (/srv/profile-service/lib/cachelib/client.js:212:28)")
        for fr in reversed(frames):
            out.append(f"    at {fr['func']} ({cfg['root']}{fr['file']}:{fr['line']}:{fr['col']})")
        out.append("    at Dispatcher.handle (/srv/profile-service/lib/httpd/dispatcher.js:88:17)")
        out.append("    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)")
    elif style == "cpp":
        out.append(f"exception caught in request handler: {error}")
        idx = 0
        if kind == "cache":
            out.append(f"  #{idx} cachelib::Connection::command(std::string const&, std::string const&) at lib/cachelib/connection.cpp:97"); idx += 1
            out.append(f"  #{idx} cachelib::CacheClient::get(std::string const&) at lib/cachelib/client.cpp:212"); idx += 1
        for fr in reversed(frames):
            out.append(f"  #{idx} {fr['func']} at {cfg['root']}{fr['file']}:{fr['line']}")
            idx += 1
        out.append(f"  #{idx} httpd::Dispatcher::handle(httpd::Request const&) at lib/httpd/dispatcher.cpp:88")
    return out


def build_app_log(cfg):
    lines = []
    t = 3.0
    while t < END:
        pod = pod_at(t)
        tenant = rng.choice(BASE_TENANTS)
        user = str(rng.randrange(100, 99999))
        hit = rng.random() < 0.9
        key = key_for(pod, tenant, user)
        if hit:
            lines.append(app_line(t, "INFO", pod, req_id(), f"GET /v1/tenants/{tenant}/users/{user} status=200 cache=hit key={key} dur_ms={rng.randrange(1, 4)}"))
        else:
            r = req_id()
            lines.append(app_line(t, "INFO", pod, r, f"GET /v1/tenants/{tenant}/users/{user} status=200 cache=miss key={key} dur_ms={rng.randrange(7, 14)}"))
            lines.append(app_line(t + 0.004, "DEBUG", pod, r, f"cache.set key={key} ttl=600 bytes={payload_bytes(pod)}"))
        t += rng.uniform(22, 34)

    lines.append(app_line(520.311, "INFO", R1_PODS[1], "6d1f0a42", "GET /v1/tenants/123/users/45 status=200 cache=hit key=profile:v2:123:45 dur_ms=2"))
    lines.append(app_line(662.904, "INFO", R1_PODS[4], "0b7e9c13", "GET /v1/tenants/12/users/345 status=200 cache=miss key=profile:v2:12:345 dur_ms=9"))
    lines.append(app_line(662.908, "DEBUG", R1_PODS[4], "0b7e9c13", "cache.set key=profile:v2:12:345 ttl=600 bytes=121"))
    lines.append(app_line(701.150, "INFO", R1_PODS[2], "e2a4c8f0", "GET /v1/tenants/77/users/7 status=200 cache=hit key=profile:v2:77:7 dur_ms=1"))

    lines.append(app_line(CACHE3_DOWN + 0.412, "INFO", R1_PODS[0], "-", "cache topology changed: cache-3 LEFT ring, key range remapped to cache-1,cache-2"))
    for i, dt in enumerate([2.208, 5.771, 9.034, 14.502, 19.960, 24.311, 29.877, 33.105]):
        pod = R1_PODS[i % 6]
        tenant = rng.choice(BASE_TENANTS)
        user = str(rng.randrange(100, 99999))
        r = req_id()
        lines.append(app_line(CACHE3_DOWN + dt, "WARN", pod, r, f"cache unavailable, falling back to origin node=cache-3 cause=ECONNRESET key=profile:v2:{tenant}:{user}"))
        if i == 0:
            for tl in render_trace(cfg, "cache"):
                lines.append((CACHE3_DOWN + dt + 0.0001, tl))
        lines.append(app_line(CACHE3_DOWN + dt + 0.013, "INFO", pod, r, f"GET /v1/tenants/{tenant}/users/{user} status=200 cache=error key=profile:v2:{tenant}:{user} dur_ms={rng.randrange(12, 23)}"))
    lines.append(app_line(HIT_ALERT_FIRE + 0.002, "ALERT", "-", "-", "[monitor] cache_hit_ratio=0.63 below threshold 0.80 for 30s (runbook: cache node restart)"))
    lines.append(app_line(CACHE3_UP + 0.117, "INFO", R1_PODS[3], "-", "cache topology changed: cache-3 JOINED ring (cold)"))
    lines.append(app_line(HIT_ALERT_RESOLVE + 0.002, "ALERT", "-", "-", "[monitor] RESOLVED cache_hit_ratio=0.89 above threshold 0.80"))

    for k, s in enumerate(POD_SWITCH):
        lines.append(app_line(s - 1.4, "INFO", R1_PODS[k], "-", "shutting down: SIGTERM from rollout controller, draining 42 in-flight requests"))
        lines.append(app_line(s + 0.117, "INFO", R2_PODS[k], "-", "starting build=2026.10.29-r2 commit=7f3c9e1 change=PROF-4471 config key_version=v2 profile_ttl_s=600 negative_ttl_s=30 negative_caching_enabled=true"))
        lines.append(app_line(s + 2.903, "INFO", R2_PODS[k], "-", "ready: health=ok cache_nodes=3 origin=ok"))

    def r2pod(k):
        return R2_PODS[k]

    lines.append(app_line(912.433, "INFO", r2pod(0), "a19c2e07", "GET /v1/tenants/123/users/45 status=200 cache=miss key=p12345 dur_ms=9"))
    lines.append(app_line(912.437, "DEBUG", r2pod(0), "a19c2e07", "cache.set key=p12345 ttl=600 bytes=41"))
    lines.append(app_line(919.702, "INFO", r2pod(1), "5e30b8d1", "GET /v1/tenants/12/users/345 status=200 cache=hit key=p12345 dur_ms=2"))

    lines.append(app_line(965.118, "INFO", r2pod(2), "c7d20f4a", "GET /v1/tenants/7/users/77 status=404 cache=miss origin=not_found key=p777 dur_ms=8"))
    lines.append(app_line(965.121, "DEBUG", r2pod(2), "c7d20f4a", "cache.set key=p777 value=__NOT_FOUND__ ttl=600"))
    lines.append(app_line(969.540, "INFO", r2pod(3), "88f1a3b6", "GET /v1/tenants/77/users/7 status=404 cache=negative key=p777 dur_ms=1"))

    lines.append(app_line(1050.207, "INFO", r2pod(4), "b41e0c9c", "GET /v1/tenants/88/users/1204 status=200 cache=miss key=p881204 dur_ms=10"))
    lines.append(app_line(1050.211, "DEBUG", r2pod(4), "b41e0c9c", "cache.set key=p881204 ttl=600 bytes=44"))
    for i, e in enumerate(DECODE_ERRORS):
        r = ["b41e0c9d", "f09a7e22", "3c5d81b7"][i]
        pod = r2pod([2, 0, 5][i])
        lines.append(app_line(e, "ERROR", pod, r, "GET /v1/tenants/88/users/1204 status=500 cache=hit key=p881204 unhandled error"))
        if i == 0:
            for tl in render_trace(cfg, "decode"):
                lines.append((e + 0.0001, tl))
        else:
            lines.append((e + 0.0001, f"{cfg['decode_error']} (see trace at {ts(DECODE_ERRORS[0])})"))

    lines.append(app_line(1110.624, "INFO", r2pod(1), "9d4b6e20", "PUT /v1/tenants/123/users/45 status=204 origin=saved"))
    lines.append(app_line(1110.627, "DEBUG", r2pod(1), "9d4b6e20", "cache.delete key=p12345"))
    lines.append(app_line(1121.088, "INFO", r2pod(5), "27ac51e9", "GET /v1/tenants/12/users/345 status=200 cache=miss key=p12345 dur_ms=8"))
    lines.append(app_line(1121.092, "DEBUG", r2pod(5), "27ac51e9", "cache.set key=p12345 ttl=600 bytes=39"))
    lines.append(app_line(1132.350, "INFO", r2pod(0), "e81d7f03", "GET /v1/tenants/123/users/45 status=200 cache=hit key=p12345 dur_ms=1"))

    lines.append(app_line(NOTFOUND_ALERT + 0.002, "ALERT", "-", "-", "[monitor] http_404_ratio=0.021 above threshold 0.020 for 60s"))

    lines.append(app_line(1198.455, "INFO", r2pod(3), "4f6e2a9b", "GET /v1/tenants/451/users/203 status=200 cache=miss key=p451203 dur_ms=11"))
    lines.append(app_line(1198.459, "DEBUG", r2pod(3), "4f6e2a9b", "cache.set key=p451203 ttl=600 bytes=43"))
    lines.append(app_line(1203.014, "INFO", r2pod(2), "d0c3e5f8", "GET /v1/tenants/45/users/1203 status=200 cache=hit key=p451203 dur_ms=1"))

    lines.append(app_line(1300.771, "INFO", r2pod(4), "71b9d2c4", "GET /v1/tenants/77/users/7 status=404 cache=negative key=p777 dur_ms=1"))
    lines.append(app_line(1402.209, "INFO", r2pod(1), "0ae5c7d9", "GET /v1/tenants/12/users/345 status=200 cache=hit key=p12345 dur_ms=2"))
    lines.append(app_line(1489.633, "INFO", r2pod(5), "b3e8f1a2", "GET /v1/tenants/77/users/7 status=404 cache=negative key=p777 dur_ms=1"))
    lines.append(app_line(1566.002, "INFO", r2pod(2), "6c2d9e4f", "GET /v1/tenants/7/users/77 status=404 cache=miss origin=not_found key=p777 dur_ms=8"))
    lines.append(app_line(1566.006, "DEBUG", r2pod(2), "6c2d9e4f", "cache.set key=p777 value=__NOT_FOUND__ ttl=600"))
    lines.append(app_line(1571.418, "INFO", r2pod(0), "f4a7b0c1", "GET /v1/tenants/77/users/7 status=404 cache=negative key=p777 dur_ms=1"))
    lines.append(app_line(1710.930, "INFO", r2pod(3), "8e1f3d5a", "GET /v1/tenants/123/users/45 status=200 cache=hit key=p12345 dur_ms=1"))
    lines.append(app_line(1890.512, "INFO", r2pod(4), "a2c4e6f8", "GET /v1/tenants/9/users/1203 status=200 cache=miss key=p91203 dur_ms=9"))
    lines.append(app_line(1890.516, "DEBUG", r2pod(4), "a2c4e6f8", "cache.set key=p91203 ttl=600 bytes=40"))
    lines.append(app_line(1897.880, "INFO", r2pod(1), "c9b1d3e5", "GET /v1/tenants/91/users/203 status=200 cache=hit key=p91203 dur_ms=2"))
    lines.append(app_line(2011.345, "INFO", r2pod(5), "5d7f9a1b", "GET /v1/tenants/77/users/7 status=404 cache=negative key=p777 dur_ms=1"))

    lines.sort(key=lambda x: x[0])
    return [l for _, l in lines]


def build_cache_log():
    lines = []
    for t in range(30, END, 120):
        for node, mem_share in (("cache-1", 0.333), ("cache-2", 0.334), ("cache-3", 0.333)):
            tt = t + {"cache-1": 0.0, "cache-2": 0.4, "cache-3": 0.8}[node]
            if node == "cache-3" and CACHE3_DOWN <= tt < CACHE3_UP:
                continue
            mem = int(metric_memory(tt) * mem_share)
            if tt >= CACHE3_DOWN and tt < 1000 and node != "cache-3":
                mem = min(1024, int(metric_memory(tt) * 0.5))
            if node == "cache-3" and CACHE3_UP <= tt < 1000:
                mem = int(metric_memory(tt) * 0.333 * min(1.0, (tt - CACHE3_UP) / 120.0))
            ev = metric_evictions(tt)
            ev_node = int(ev * (0.5 if (node != "cache-3" and CACHE3_DOWN <= tt < 1000) else 0.333))
            lines.append((tt, f"{ts(tt)} INFO  [{node}] stats mem_mb={mem}/1024 conns={rng.randrange(180, 221)} evict_per_s={ev_node} get_per_s={int(metric_rps(tt) / 3)}"))
    lines.append((CACHE3_DOWN - 2.0, f"{ts(CACHE3_DOWN - 2.0)} WARN  [cache-3] host maintenance: scheduled kernel reboot window 09:13-09:15, draining"))
    lines.append((CACHE3_DOWN, f"{ts(CACHE3_DOWN)} INFO  [cache-3] shutting down, 613,402 keys in memory will be lost (no persistence)"))
    lines.append((CACHE3_DOWN + 0.4, f"{ts(CACHE3_DOWN + 0.4)} INFO  [ring] cache-3 removed, hash range 0x5555-0xaaaa remapped to cache-1,cache-2"))
    for i, dt in enumerate([3.1, 11.6, 24.9, 38.3, 52.0, 66.7]):
        node = "cache-1" if i % 2 == 0 else "cache-2"
        lines.append((CACHE3_DOWN + dt, f"{ts(CACHE3_DOWN + dt)} WARN  [{node}] memory limit reached mem_mb=1024/1024 evict_per_s={int(metric_evictions(CACHE3_DOWN + dt) / 2)} policy=allkeys-lru"))
    lines.append((CACHE3_UP - 2.0, f"{ts(CACHE3_UP - 2.0)} INFO  [cache-3] started version=6.2.14 mem_mb=0/1024 keys=0"))
    lines.append((CACHE3_UP, f"{ts(CACHE3_UP)} INFO  [ring] cache-3 added, hash range 0x5555-0xaaaa remapped back to cache-3 (cold)"))
    lines.append((1005.0, f"{ts(1005.0)} INFO  [cache-1] memory below limit mem_mb=990/1024, eviction pressure cleared"))
    lines.append((1006.2, f"{ts(1006.2)} INFO  [cache-2] memory below limit mem_mb=986/1024, eviction pressure cleared"))
    lines.sort(key=lambda x: x[0])
    return [l for _, l in lines]


def build_deploy_log():
    L = []
    L.append((835.0, "rollout profile-service build=2026.10.29-r2 commit=7f3c9e1 change=PROF-4471 title=\"compact cache keys and compact payload\" requested_by=mlindqvist strategy=rolling max_unavailable=1"))
    L.append((836.2, "pre-flight: config diff vs r1: none (key_version=v2 profile_ttl_s=600 negative_ttl_s=30 negative_caching_enabled=true)"))
    L.append((837.5, "pre-flight: dependency check cache ring degraded (cache-3 absent); cache is not a rollout gate, proceeding"))
    L.append((838.8, "pre-flight: change notes: PROF-4471 reduces cache memory by ~30% (shorter keys, compact payload); removes legacy key builder; no API change"))
    for k, s in enumerate(POD_SWITCH):
        L.append((s - 1.6, f"pod {k + 1}/6 pp-5f8c-{k + 1}: terminating"))
        L.append((s, f"pod {k + 1}/6 pp-7d2e-{k + 1}: created image=profile-service:2026.10.29-r2"))
        L.append((s + 3.1, f"pod {k + 1}/6 pp-7d2e-{k + 1}: ready (health=ok), traffic shifted"))
    L.append((DEPLOY_DONE + 4.0, "rollout complete 6/6 pods healthy on build 2026.10.29-r2"))
    L.append((DEPLOY_DONE + 5.0, "post-deploy check (5 min window): error_rate=0.000 p99_ms=11 cache_memory_trend=down, marking rollout SUCCESS"))
    L.append((NOTFOUND_ALERT + 30.0, "alert http_404_ratio linked to rollout by time correlation; auto-rollback disabled for this service (policy: manual rollback only)"))
    out = []
    for t, msg in sorted(L, key=lambda x: x[0]):
        out.append(f"{ts(t)} [rollout-controller] {msg}")
    return out


def main():
    with open(os.path.join(HERE, "trace_lines.json")) as f:
        traces = json.load(f)
    global rng
    rng = random.Random(20261029)
    rows = build_metrics()
    rng = random.Random(7)
    cache_log = build_cache_log()
    deploy_log = build_deploy_log()
    app_logs = {}
    for lang in LANGS:
        rng = random.Random(1029)
        app_logs[lang] = build_app_log(traces[lang])
    for lang in LANGS:
        base = os.path.join(REPO, lang)
        os.makedirs(os.path.join(base, "logs"), exist_ok=True)
        os.makedirs(os.path.join(base, "metrics"), exist_ok=True)
        with open(os.path.join(base, "logs", "app.log"), "w") as f:
            f.write("\n".join(app_logs[lang]) + "\n")
        with open(os.path.join(base, "logs", "cache.log"), "w") as f:
            f.write("\n".join(cache_log) + "\n")
        with open(os.path.join(base, "logs", "deploy.log"), "w") as f:
            f.write("\n".join(deploy_log) + "\n")
        write_csvs(rows, os.path.join(base, "metrics"))
        write_dashboard(rows, os.path.join(base, "metrics"))
    print(f"app.log lines: {len(app_logs['PYTHON'])}, cache.log: {len(cache_log)}, deploy.log: {len(deploy_log)}, metric rows: {len(rows)}")


if __name__ == "__main__":
    main()
