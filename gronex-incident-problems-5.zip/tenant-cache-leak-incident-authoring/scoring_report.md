# Scoring report: tenant-cache-leak-incident

30 tests per language: 18 visible (`tests/`) plus 12 hidden (overlaid from `hidden/<LANG>/`). Score is the share passing out of 30. Measured with `scoring_runs.sh`; the four fix states are:

- **main**: the broken code contestants receive.
- **partial, key only**: the most obvious fault fixed in isolation. The solution's `cache_keys` (versioned, length-prefixed) copied over the broken tree; codec and service untouched.
- **naive, symptom only**: the two edits a hurried contestant makes after reading the failing visible test names: a `:` delimiter inserted in the key (`p:<tenant>:<user>`, no version, no length prefix) and the not-found sentinel written with `negative_ttl_s` instead of `profile_ttl_s`. No owner validation, no switch handling, no invalidation on create.
- **solution**: the `solution` branch.

| Language | main | partial, key only | naive, symptom only | solution |
| --- | --- | --- | --- | --- |
| Python | 11 / 30 (8 visible + 3 hidden) | 21 / 30 | 20 / 30 | 30 / 30 |
| Java | 11 / 30 (8 visible + 3 hidden) | 21 / 30 | 20 / 30 | 30 / 30 |
| Node.js | 11 / 30 (8 visible + 3 hidden) | 21 / 30 | 20 / 30 | 30 / 30 |
| C++ | 11 / 30 (8 visible + 3 hidden) | 21 / 30 | 20 / 30 | 30 / 30 |

Percent of 100: main 37, key only 70, naive 67, solution 100. Identical across languages because the test names and assertions are identical and the pass/fail sets were diffed per language.

## What each state still fails

**main (19 failing)**: every key test, every negative-caching test, the owner-validation tests and the `|` payload test. The 11 passing tests are the behaviours that must not regress: read-through, hit, positive TTL, fallback on cache error, invalidation on update, 404 for unknown user, negative hit within 30 s, cache-set failure tolerance, invalid identifier 400, and negative caching leaving positive entries alone.

**partial, key only (9 failing)**: `test_negative_entry_uses_negative_ttl`, `test_create_profile_clears_negative_entry`, `test_negative_caching_can_be_disabled_by_config`, `test_cached_value_with_foreign_tenant_is_rejected_and_reloaded`, `test_hidden_negative_entry_expires_exactly_at_negative_ttl_boundary`, `test_hidden_tenant_mismatch_evicts_poisoned_entry_and_repopulates`, `test_hidden_foreign_user_id_under_correct_tenant_is_rejected`, `test_hidden_display_name_with_separator_character_roundtrips_through_cache`, `test_hidden_disabled_negative_caching_ignores_existing_sentinel`. Fixing the key alone removes the collision and therefore the cross-tenant negative poisoning, which is why it scores 70. It leaves every defence-in-depth and switch behaviour broken.

**naive, symptom only (10 failing)**: everything in the key-only list except the two negative-TTL tests, plus `test_key_includes_key_version`, `test_key_version_rotation_isolates_old_entries` and `test_hidden_key_injective_with_delimiter_characters_in_ids`. The 404 alert would stop within 30 s in production and digit-id collisions are gone, but rotation does not work, ids containing `:` still collide, and a poisoned entry is still served.

## Score movement

- Fixing fault 1 (key): +10 tests.
- Fixing fault 2 (negative caching TTL, switch, create invalidation) on top: +5 tests.
- Fixing fault 3 (owner ids in payload, validation, eviction, `|`-safe encoding) on top: +4 tests, reaching 30.
