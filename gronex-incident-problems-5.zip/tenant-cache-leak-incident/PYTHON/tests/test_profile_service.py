from itertools import product

from profile_service.cache_keys import build_profile_key
from profile_service.codec import encode_profile
from profile_service.config import ServiceConfig

from harness import World, profile


def test_cache_miss_loads_from_origin_and_populates_cache():
    w = World()
    w.origin.put(profile("12", "7"))
    first = w.service.get_profile("12", "7")
    assert first == profile("12", "7")
    assert w.origin.load_count == 1
    assert w.metrics.value("cache.miss") == 1
    assert w.metrics.value("origin.load") == 1
    assert len(w.cache.keys()) == 1


def test_cache_hit_skips_origin():
    w = World()
    w.origin.put(profile("12", "7"))
    w.service.get_profile("12", "7")
    second = w.service.get_profile("12", "7")
    assert second == profile("12", "7")
    assert w.origin.load_count == 1
    assert w.metrics.value("cache.hit") == 1


def test_cache_entry_expires_after_profile_ttl():
    w = World()
    w.origin.put(profile("12", "7"))
    w.service.get_profile("12", "7")
    w.clock.advance(599)
    w.service.get_profile("12", "7")
    assert w.origin.load_count == 1
    w.clock.advance(1)
    w.service.get_profile("12", "7")
    assert w.origin.load_count == 2


def test_cache_unavailable_falls_back_to_origin():
    w = World()
    w.origin.put(profile("12", "7"))
    w.cache.fail_gets = True
    assert w.service.get_profile("12", "7") == profile("12", "7")
    assert w.origin.load_count == 1
    assert w.metrics.value("cache.error") >= 1


def test_update_profile_invalidates_cache_entry():
    w = World()
    w.origin.put(profile("12", "7", version=1))
    w.service.get_profile("12", "7")
    w.service.update_profile(profile("12", "7", display_name="Renamed", version=2))
    updated = w.service.get_profile("12", "7")
    assert updated.display_name == "Renamed"
    assert updated.version == 2
    assert w.origin.load_count == 2


def test_distinct_tenants_same_user_id_get_distinct_profiles():
    w = World()
    w.origin.put(profile("12", "7", display_name="Acme Seven"))
    w.origin.put(profile("13", "7", display_name="Globex Seven"))
    assert w.service.get_profile("12", "7").display_name == "Acme Seven"
    assert w.service.get_profile("13", "7").display_name == "Globex Seven"
    assert w.service.get_profile("12", "7").display_name == "Acme Seven"


def test_api_returns_404_for_unknown_user():
    w = World()
    response = w.api.get_profile("12", "404")
    assert response.status == 404
    assert response.body == {"error": "not_found"}


def test_negative_entry_served_within_negative_ttl():
    w = World()
    w.service.get_profile("12", "9")
    w.clock.advance(29)
    assert w.service.get_profile("12", "9") is None
    assert w.origin.load_count == 1
    assert w.metrics.value("cache.negative_hit") == 1


def test_key_collision_tenant_12_user_345_vs_tenant_123_user_45():
    config = ServiceConfig()
    assert build_profile_key(config, "12", "345") != build_profile_key(config, "123", "45")


def test_key_builder_is_injective_for_digit_ids():
    config = ServiceConfig()
    ids = ["1", "2", "12", "21", "123", "4", "45", "345"]
    keys = {}
    for tenant_id, user_id in product(ids, ids):
        key = build_profile_key(config, tenant_id, user_id)
        assert key not in keys, (tenant_id, user_id, keys.get(key))
        keys[key] = (tenant_id, user_id)


def test_key_includes_key_version():
    assert "v2" in build_profile_key(ServiceConfig(key_version="v2"), "12", "7")
    assert "v3" in build_profile_key(ServiceConfig(key_version="v3"), "12", "7")
    assert build_profile_key(ServiceConfig(key_version="v2"), "12", "7") != build_profile_key(ServiceConfig(key_version="v3"), "12", "7")


def test_served_profile_belongs_to_requesting_tenant_after_collision():
    w = World()
    w.origin.put(profile("12", "345", display_name="Acme Person", email="acme@acme.example"))
    w.origin.put(profile("123", "45", display_name="Globex Person", email="globex@globex.example"))
    w.service.get_profile("123", "45")
    served = w.service.get_profile("12", "345")
    assert served.tenant_id == "12"
    assert served.user_id == "345"
    assert served.display_name == "Acme Person"
    assert served.email == "acme@acme.example"


def test_key_version_rotation_isolates_old_entries():
    w = World(ServiceConfig(key_version="v2"))
    w.origin.put(profile("12", "7", display_name="Before"))
    w.service.get_profile("12", "7")
    w.origin.save(profile("12", "7", display_name="After", version=2))
    rotated = w.with_config(ServiceConfig(key_version="v3"))
    assert rotated.service.get_profile("12", "7").display_name == "After"
    assert w.service.get_profile("12", "7").display_name == "Before"


def test_negative_entry_uses_negative_ttl():
    w = World()
    w.service.get_profile("12", "9")
    w.clock.advance(30)
    w.origin.put(profile("12", "9"))
    assert w.service.get_profile("12", "9") == profile("12", "9")
    assert w.origin.load_count == 2


def test_create_profile_clears_negative_entry():
    w = World()
    assert w.service.get_profile("12", "9") is None
    w.service.create_profile(profile("12", "9", display_name="Fresh"))
    created = w.service.get_profile("12", "9")
    assert created is not None
    assert created.display_name == "Fresh"


def test_negative_caching_can_be_disabled_by_config():
    w = World(ServiceConfig(negative_caching_enabled=False))
    assert w.service.get_profile("12", "9") is None
    assert w.service.get_profile("12", "9") is None
    assert w.origin.load_count == 2
    assert w.metrics.value("cache.negative_hit") == 0


def test_missing_user_in_one_tenant_does_not_hide_user_in_other_tenant():
    w = World()
    w.origin.put(profile("123", "45", display_name="Globex Person"))
    assert w.service.get_profile("12", "345") is None
    found = w.service.get_profile("123", "45")
    assert found is not None
    assert found.display_name == "Globex Person"
    assert w.api.get_profile("123", "45").status == 200


def test_cached_value_with_foreign_tenant_is_rejected_and_reloaded():
    w = World()
    w.origin.put(profile("12", "7", display_name="Acme Seven"))
    foreign = profile("99", "7", display_name="Initech Seven", email="leak@initech.example")
    w.cache.seed(build_profile_key(w.config, "12", "7"), encode_profile(foreign), 600)
    served = w.service.get_profile("12", "7")
    assert served.tenant_id == "12"
    assert served.display_name == "Acme Seven"
    assert served.email != "leak@initech.example"
    assert w.origin.load_count == 1
    assert w.metrics.value("cache.tenant_mismatch") == 1
