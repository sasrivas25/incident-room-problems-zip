from typing import Dict, List, Optional, Tuple

from profile_service.cache_store import CacheStore, CacheUnavailableError
from profile_service.clock import Clock
from profile_service.models import Profile
from profile_service.origin import ProfileOrigin


class FakeClock(Clock):
    def __init__(self, start: float = 1_000_000.0) -> None:
        self._now = start

    def now(self) -> float:
        return self._now

    def advance(self, seconds: float) -> None:
        self._now += seconds


class FakeCacheStore(CacheStore):
    def __init__(self, clock: FakeClock) -> None:
        self._clock = clock
        self._entries: Dict[str, Tuple[str, float]] = {}
        self.fail_gets = False
        self.fail_sets = False
        self.set_calls: List[Tuple[str, str, int]] = []

    def get(self, key: str) -> Optional[str]:
        if self.fail_gets:
            raise CacheUnavailableError("ECONNRESET")
        entry = self._entries.get(key)
        if entry is None:
            return None
        value, expires_at = entry
        if self._clock.now() >= expires_at:
            del self._entries[key]
            return None
        return value

    def set(self, key: str, value: str, ttl_s: int) -> None:
        if self.fail_sets:
            raise CacheUnavailableError("ECONNRESET")
        self.set_calls.append((key, value, ttl_s))
        self._entries[key] = (value, self._clock.now() + ttl_s)

    def delete(self, key: str) -> None:
        self._entries.pop(key, None)

    def seed(self, key: str, value: str, ttl_s: int) -> None:
        self._entries[key] = (value, self._clock.now() + ttl_s)

    def raw_value(self, key: str) -> Optional[str]:
        entry = self._entries.get(key)
        return None if entry is None else entry[0]

    def keys(self) -> List[str]:
        return sorted(self._entries.keys())


class FakeOrigin(ProfileOrigin):
    def __init__(self) -> None:
        self._rows: Dict[Tuple[str, str], Profile] = {}
        self.load_count = 0
        self.load_calls: List[Tuple[str, str]] = []

    def put(self, profile: Profile) -> None:
        self._rows[(profile.tenant_id, profile.user_id)] = profile

    def load(self, tenant_id: str, user_id: str) -> Optional[Profile]:
        self.load_count += 1
        self.load_calls.append((tenant_id, user_id))
        return self._rows.get((tenant_id, user_id))

    def save(self, profile: Profile) -> None:
        self._rows[(profile.tenant_id, profile.user_id)] = profile
