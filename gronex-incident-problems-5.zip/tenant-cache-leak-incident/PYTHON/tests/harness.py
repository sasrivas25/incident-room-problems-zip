from profile_service.api import ProfileApi
from profile_service.config import ServiceConfig
from profile_service.metrics import Metrics
from profile_service.models import Profile
from profile_service.service import ProfileService

from fakes import FakeCacheStore, FakeClock, FakeOrigin


class World:
    def __init__(self, config: ServiceConfig = None) -> None:
        self.config = config or ServiceConfig()
        self.clock = FakeClock()
        self.cache = FakeCacheStore(self.clock)
        self.origin = FakeOrigin()
        self.metrics = Metrics()
        self.service = ProfileService(self.config, self.cache, self.origin, self.clock, self.metrics)
        self.api = ProfileApi(self.service)

    def with_config(self, config: ServiceConfig) -> "World":
        other = World(config)
        other.clock = self.clock
        other.cache = self.cache
        other.origin = self.origin
        other.metrics = Metrics()
        other.service = ProfileService(config, self.cache, self.origin, self.clock, other.metrics)
        other.api = ProfileApi(other.service)
        return other


def profile(tenant_id: str, user_id: str, display_name: str = None, email: str = None, version: int = 1) -> Profile:
    name = display_name or f"User {user_id} of {tenant_id}"
    mail = email or f"u{user_id}@t{tenant_id}.example"
    return Profile(tenant_id, user_id, name, mail, version)
