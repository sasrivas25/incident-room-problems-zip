from .config import ServiceConfig

KEY_PREFIX = "p"


def build_profile_key(config: ServiceConfig, tenant_id: str, user_id: str) -> str:
    return KEY_PREFIX + tenant_id + user_id
