# Incident Room: Cross-Tenant Profile Leak (Python)

You are on call for `profile-service`, the multi-tenant profile lookup API behind the account pages of every customer workspace. At 09:14 UTC today, build `2026.10.29-r2` (change PROF-4471, "compact cache keys and compact payload") finished rolling out. At 09:19 the `http_404_ratio` alert fired. At 09:21 Support escalated ticket SUP-88213: an administrator at tenant `12` (Acme) opened a colleague's profile and saw the name and email of an employee of tenant `123` (Globex). Two more tenants reported the same thing within ten minutes. A cache node also restarted a minute before the deploy and the `cache_hit_ratio` alert fired and resolved on its own.

The service is still serving traffic. Nobody has rolled back yet.

## What you have

| Path | Contents |
| --- | --- |
| `logs/app.log` | profile-service application log for 09:00-09:35 UTC |
| `logs/cache.log` | cache cluster log (nodes cache-1..3) for the same window |
| `logs/deploy.log` | rollout controller log for build r2 |
| `metrics/*.csv` | time series for the incident window, 15 s resolution |
| `metrics/dashboard.md` | the same series as text charts with annotations |
| `docs/runbook.md` | the on-call runbook for profile-service |
| `src/profile_service/` | the code under test. This is the only place you may change |
| `tests/` | the visible test suite. Do not edit it |

## The three phases

1. **Triage.** Read the logs, metrics, runbook and code. Submit a root cause, the evidence that proves it, and a mitigation that stops the bleeding before the real fix. Tests are locked until you submit.
2. **Recover.** Fix `src/`. Your score is the share of tests passing, visible plus a hidden suite that covers edge cases of the same faults and rejects fixes that only hide the symptom.
3. **Defend.** Explain what you changed, why it is safe, and what you would watch or fix next.

## Project layout

```
src/profile_service/
  api.py            HTTP-shaped entry point: validation, status codes
  service.py        read-through cache logic, negative caching, invalidation
  cache_keys.py     cache key construction
  codec.py          cached payload encoding and the not-found sentinel
  config.py         ServiceConfig (key_version, TTLs, negative caching switch)
  identifiers.py    tenant and user id validation
  cache_store.py    CacheStore interface and CacheUnavailableError
  origin.py         ProfileOrigin interface (the profiles database)
  metrics.py        counters
  clock.py          Clock interface
  models.py         Profile
tests/
  fakes.py          FakeClock, FakeCacheStore (TTL-aware), FakeOrigin
  harness.py        World: wires a service with fakes; with_config() shares cache and origin
  test_profile_service.py
```

Everything is injected: the clock, the cache, the origin database and the config. There is no network, no sleep and no wall clock in the tests.

## How to run

```
./verify.sh
```

Requires Python 3.9+ and pytest. `verify.sh` installs pytest for the current user if it is missing. Set `PYTHON=/path/to/python` to pick an interpreter.

## Rules

- Change files under `src/` only. Tests, logs, metrics and docs are read-only.
- Keep the service deterministic. No wall clock, sleeps, threads or randomness.
- Counter names used by the tests: `cache.hit`, `cache.miss`, `cache.negative_hit`, `cache.error`, `cache.tenant_mismatch`, `cache.decode_error`, `origin.load`.
