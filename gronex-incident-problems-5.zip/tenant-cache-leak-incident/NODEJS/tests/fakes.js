'use strict';

const { CacheStore, CacheUnavailableError } = require('../src/cache_store');
const { Clock } = require('../src/clock');
const { ProfileOrigin } = require('../src/origin');

class FakeClock extends Clock {
  constructor(start = 1000000) {
    super();
    this._now = start;
  }

  now() {
    return this._now;
  }

  advance(seconds) {
    this._now += seconds;
  }
}

class FakeCacheStore extends CacheStore {
  constructor(clock) {
    super();
    this._clock = clock;
    this._entries = new Map();
    this.failGets = false;
    this.failSets = false;
    this.setCalls = [];
  }

  get(key) {
    if (this.failGets) {
      throw new CacheUnavailableError('ECONNRESET');
    }
    const entry = this._entries.get(key);
    if (entry === undefined) {
      return null;
    }
    const [value, expiresAt] = entry;
    if (this._clock.now() >= expiresAt) {
      this._entries.delete(key);
      return null;
    }
    return value;
  }

  set(key, value, ttlS) {
    if (this.failSets) {
      throw new CacheUnavailableError('ECONNRESET');
    }
    this.setCalls.push([key, value, ttlS]);
    this._entries.set(key, [value, this._clock.now() + ttlS]);
  }

  delete(key) {
    this._entries.delete(key);
  }

  seed(key, value, ttlS) {
    this._entries.set(key, [value, this._clock.now() + ttlS]);
  }

  rawValue(key) {
    const entry = this._entries.get(key);
    return entry === undefined ? null : entry[0];
  }

  keys() {
    return [...this._entries.keys()].sort();
  }
}

class FakeOrigin extends ProfileOrigin {
  constructor() {
    super();
    this._rows = new Map();
    this.loadCount = 0;
    this.loadCalls = [];
  }

  put(profile) {
    this._rows.set(rowKey(profile.tenantId, profile.userId), profile);
  }

  load(tenantId, userId) {
    this.loadCount += 1;
    this.loadCalls.push([tenantId, userId]);
    return this._rows.get(rowKey(tenantId, userId)) ?? null;
  }

  save(profile) {
    this._rows.set(rowKey(profile.tenantId, profile.userId), profile);
  }
}

function rowKey(tenantId, userId) {
  return JSON.stringify([tenantId, userId]);
}

module.exports = { FakeClock, FakeCacheStore, FakeOrigin };
