'use strict';

const { ProfileApi } = require('../src/api');
const { serviceConfig } = require('../src/config');
const { Metrics } = require('../src/metrics');
const { makeProfile } = require('../src/models');
const { ProfileService } = require('../src/service');

const { FakeCacheStore, FakeClock, FakeOrigin } = require('./fakes');

class World {
  constructor(config = null) {
    this.config = config ?? serviceConfig();
    this.clock = new FakeClock();
    this.cache = new FakeCacheStore(this.clock);
    this.origin = new FakeOrigin();
    this.metrics = new Metrics();
    this.service = new ProfileService(this.config, this.cache, this.origin, this.clock, this.metrics);
    this.api = new ProfileApi(this.service);
  }

  withConfig(config) {
    const other = new World(config);
    other.clock = this.clock;
    other.cache = this.cache;
    other.origin = this.origin;
    other.metrics = new Metrics();
    other.service = new ProfileService(config, this.cache, this.origin, this.clock, other.metrics);
    other.api = new ProfileApi(other.service);
    return other;
  }
}

function profile(tenantId, userId, displayName = null, email = null, version = 1) {
  const name = displayName || `User ${userId} of ${tenantId}`;
  const mail = email || `u${userId}@t${tenantId}.example`;
  return makeProfile(tenantId, userId, name, mail, version);
}

function countCalls(calls, tenantId, userId) {
  return calls.filter(([t, u]) => t === tenantId && u === userId).length;
}

module.exports = { World, profile, countCalls };
