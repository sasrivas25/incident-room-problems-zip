'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { buildProfileKey } = require('../src/cache_keys');
const { encodeProfile } = require('../src/codec');
const { serviceConfig } = require('../src/config');

const { World, profile } = require('./harness');

test('test_cache_miss_loads_from_origin_and_populates_cache', () => {
  const w = new World();
  w.origin.put(profile('12', '7'));
  const first = w.service.getProfile('12', '7');
  assert.deepEqual(first, profile('12', '7'));
  assert.equal(w.origin.loadCount, 1);
  assert.equal(w.metrics.value('cache.miss'), 1);
  assert.equal(w.metrics.value('origin.load'), 1);
  assert.equal(w.cache.keys().length, 1);
});

test('test_cache_hit_skips_origin', () => {
  const w = new World();
  w.origin.put(profile('12', '7'));
  w.service.getProfile('12', '7');
  const second = w.service.getProfile('12', '7');
  assert.deepEqual(second, profile('12', '7'));
  assert.equal(w.origin.loadCount, 1);
  assert.equal(w.metrics.value('cache.hit'), 1);
});

test('test_cache_entry_expires_after_profile_ttl', () => {
  const w = new World();
  w.origin.put(profile('12', '7'));
  w.service.getProfile('12', '7');
  w.clock.advance(599);
  w.service.getProfile('12', '7');
  assert.equal(w.origin.loadCount, 1);
  w.clock.advance(1);
  w.service.getProfile('12', '7');
  assert.equal(w.origin.loadCount, 2);
});

test('test_cache_unavailable_falls_back_to_origin', () => {
  const w = new World();
  w.origin.put(profile('12', '7'));
  w.cache.failGets = true;
  assert.deepEqual(w.service.getProfile('12', '7'), profile('12', '7'));
  assert.equal(w.origin.loadCount, 1);
  assert.ok(w.metrics.value('cache.error') >= 1);
});

test('test_update_profile_invalidates_cache_entry', () => {
  const w = new World();
  w.origin.put(profile('12', '7', null, null, 1));
  w.service.getProfile('12', '7');
  w.service.updateProfile(profile('12', '7', 'Renamed', null, 2));
  const updated = w.service.getProfile('12', '7');
  assert.equal(updated.displayName, 'Renamed');
  assert.equal(updated.version, 2);
  assert.equal(w.origin.loadCount, 2);
});

test('test_distinct_tenants_same_user_id_get_distinct_profiles', () => {
  const w = new World();
  w.origin.put(profile('12', '7', 'Acme Seven'));
  w.origin.put(profile('13', '7', 'Globex Seven'));
  assert.equal(w.service.getProfile('12', '7').displayName, 'Acme Seven');
  assert.equal(w.service.getProfile('13', '7').displayName, 'Globex Seven');
  assert.equal(w.service.getProfile('12', '7').displayName, 'Acme Seven');
});

test('test_api_returns_404_for_unknown_user', () => {
  const w = new World();
  const response = w.api.getProfile('12', '404');
  assert.equal(response.status, 404);
  assert.deepEqual(response.body, { error: 'not_found' });
});

test('test_negative_entry_served_within_negative_ttl', () => {
  const w = new World();
  w.service.getProfile('12', '9');
  w.clock.advance(29);
  assert.equal(w.service.getProfile('12', '9'), null);
  assert.equal(w.origin.loadCount, 1);
  assert.equal(w.metrics.value('cache.negative_hit'), 1);
});

test('test_key_collision_tenant_12_user_345_vs_tenant_123_user_45', () => {
  const config = serviceConfig();
  assert.notEqual(buildProfileKey(config, '12', '345'), buildProfileKey(config, '123', '45'));
});

test('test_key_builder_is_injective_for_digit_ids', () => {
  const config = serviceConfig();
  const ids = ['1', '2', '12', '21', '123', '4', '45', '345'];
  const keys = new Map();
  for (const tenantId of ids) {
    for (const userId of ids) {
      const key = buildProfileKey(config, tenantId, userId);
      assert.ok(!keys.has(key), JSON.stringify([tenantId, userId, keys.get(key)]));
      keys.set(key, [tenantId, userId]);
    }
  }
});

test('test_key_includes_key_version', () => {
  assert.ok(buildProfileKey(serviceConfig({ keyVersion: 'v2' }), '12', '7').includes('v2'));
  assert.ok(buildProfileKey(serviceConfig({ keyVersion: 'v3' }), '12', '7').includes('v3'));
  assert.notEqual(
    buildProfileKey(serviceConfig({ keyVersion: 'v2' }), '12', '7'),
    buildProfileKey(serviceConfig({ keyVersion: 'v3' }), '12', '7'),
  );
});

test('test_served_profile_belongs_to_requesting_tenant_after_collision', () => {
  const w = new World();
  w.origin.put(profile('12', '345', 'Acme Person', 'acme@acme.example'));
  w.origin.put(profile('123', '45', 'Globex Person', 'globex@globex.example'));
  w.service.getProfile('123', '45');
  const served = w.service.getProfile('12', '345');
  assert.equal(served.tenantId, '12');
  assert.equal(served.userId, '345');
  assert.equal(served.displayName, 'Acme Person');
  assert.equal(served.email, 'acme@acme.example');
});

test('test_key_version_rotation_isolates_old_entries', () => {
  const w = new World(serviceConfig({ keyVersion: 'v2' }));
  w.origin.put(profile('12', '7', 'Before'));
  w.service.getProfile('12', '7');
  w.origin.save(profile('12', '7', 'After', null, 2));
  const rotated = w.withConfig(serviceConfig({ keyVersion: 'v3' }));
  assert.equal(rotated.service.getProfile('12', '7').displayName, 'After');
  assert.equal(w.service.getProfile('12', '7').displayName, 'Before');
});

test('test_negative_entry_uses_negative_ttl', () => {
  const w = new World();
  w.service.getProfile('12', '9');
  w.clock.advance(30);
  w.origin.put(profile('12', '9'));
  assert.deepEqual(w.service.getProfile('12', '9'), profile('12', '9'));
  assert.equal(w.origin.loadCount, 2);
});

test('test_create_profile_clears_negative_entry', () => {
  const w = new World();
  assert.equal(w.service.getProfile('12', '9'), null);
  w.service.createProfile(profile('12', '9', 'Fresh'));
  const created = w.service.getProfile('12', '9');
  assert.notEqual(created, null);
  assert.equal(created.displayName, 'Fresh');
});

test('test_negative_caching_can_be_disabled_by_config', () => {
  const w = new World(serviceConfig({ negativeCachingEnabled: false }));
  assert.equal(w.service.getProfile('12', '9'), null);
  assert.equal(w.service.getProfile('12', '9'), null);
  assert.equal(w.origin.loadCount, 2);
  assert.equal(w.metrics.value('cache.negative_hit'), 0);
});

test('test_missing_user_in_one_tenant_does_not_hide_user_in_other_tenant', () => {
  const w = new World();
  w.origin.put(profile('123', '45', 'Globex Person'));
  assert.equal(w.service.getProfile('12', '345'), null);
  const found = w.service.getProfile('123', '45');
  assert.notEqual(found, null);
  assert.equal(found.displayName, 'Globex Person');
  assert.equal(w.api.getProfile('123', '45').status, 200);
});

test('test_cached_value_with_foreign_tenant_is_rejected_and_reloaded', () => {
  const w = new World();
  w.origin.put(profile('12', '7', 'Acme Seven'));
  const foreign = profile('99', '7', 'Initech Seven', 'leak@initech.example');
  w.cache.seed(buildProfileKey(w.config, '12', '7'), encodeProfile(foreign), 600);
  const served = w.service.getProfile('12', '7');
  assert.equal(served.tenantId, '12');
  assert.equal(served.displayName, 'Acme Seven');
  assert.notEqual(served.email, 'leak@initech.example');
  assert.equal(w.origin.loadCount, 1);
  assert.equal(w.metrics.value('cache.tenant_mismatch'), 1);
});
