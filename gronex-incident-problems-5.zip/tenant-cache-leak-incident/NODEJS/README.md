# Incident Room: Cross-Tenant Profile Leak (Node.js)

You are on call for `profile-service`, the multi-tenant profile lookup API behind the account pages of every customer workspace. At 09:14 UTC today, build `2026.10.29-r2` (change PROF-4471, "compact cache keys and compact payload") finished rolling out. At 09:19 the `http_404_ratio` alert fired. At 09:21 Support escalated ticket SUP-88213: an administrator at tenant `12` (Acme) opened a colleague's profile and saw the name and email of an employee of tenant `123` (Globex). Two more tenants reported the same thing within ten minutes. A cache node also restarted a minute before the deploy and the `cache_hit_ratio` alert fired and resolved on its own.

The service is still serving traffic. Nobody has rolled back yet.

## What you have

| Path | Contents |
| --- | --- |
| `logs/app.log` | profile-service application log for 09:00-09:35 UTC |
| `logs/cache.log` | cache cluster log (nodes cache-1..3) for the same window |
| `logs/deploy.log` | rollout controller log for build r2 |
| `metrics/*.csv` | time series for the incident window, 15 s resolution |
| `metrics/dashboard.md` | the same series as text charts with annotations |
| `docs/runbook.md` | the on-call runbook for profile-service |
| `src/` | the code under test. This is the only place you may change |
| `tests/` | the visible test suite. Do not edit it |

## The three phases

1. **Triage.** Read the logs, metrics, runbook and code. Submit a root cause, the evidence that proves it, and a mitigation that stops the bleeding before the real fix. Tests are locked until you submit.
2. **Recover.** Fix `src/`. Your score is the share of tests passing, visible plus a hidden suite that covers edge cases of the same faults and rejects fixes that only hide the symptom.
3. **Defend.** Explain what you changed, why it is safe, and what you would watch or fix next.

## Project layout

```
src/
  api.js            HTTP-shaped entry point: validation, status codes
  service.js        read-through cache logic, negative caching, invalidation
  cache_keys.js     cache key construction
  codec.js          cached payload encoding and the not-found sentinel
  config.js         serviceConfig() / configFromDict() (keyVersion, TTLs, negative caching switch)
  identifiers.js    tenant and user id validation
  cache_store.js    CacheStore interface and CacheUnavailableError
  origin.js         ProfileOrigin interface (the profiles database)
  metrics.js        counters
  clock.js          Clock interface
  models.js         makeProfile(): frozen { tenantId, userId, displayName, email, version }
tests/
  fakes.js          FakeClock, FakeCacheStore (TTL-aware), FakeOrigin
  harness.js        World: wires a service with fakes; withConfig() shares cache and origin
  profile_service.test.js
```

Everything is injected: the clock, the cache, the origin database and the config. There is no network, no sleep and no wall clock in the tests. Modules are CommonJS (`require` / `module.exports`); there are no npm dependencies.

## How to run

```
./verify.sh
```

Requires Node.js 18 or newer. The tests use the built-in `node:test` runner and `node:assert/strict`; nothing is installed. `npm test` runs the same visible suite.

## Rules

- Change files under `src/` only. Tests, logs, metrics and docs are read-only.
- Keep the service deterministic. No wall clock, sleeps, threads or randomness.
- Counter names used by the tests: `cache.hit`, `cache.miss`, `cache.negative_hit`, `cache.error`, `cache.tenant_mismatch`, `cache.decode_error`, `origin.load`.
