#include <algorithm>
#include <map>
#include <string>
#include <utility>
#include <vector>

#include "cache_keys.hpp"
#include "check.hpp"
#include "codec.hpp"
#include "config.hpp"
#include "harness.hpp"

TEST_CASE(test_hidden_key_injective_with_delimiter_characters_in_ids) {
    ServiceConfig config;
    const std::vector<std::pair<std::string, std::string>> pairs = {
        {"12:3", "45"}, {"12", "3:45"}, {"1", "2:3:45"}, {"12:3:4", "5"}, {"a-b", "c"}, {"a", "b-c"}, {"a_b", "c"}, {"a", "b_c"}};
    std::map<std::string, std::pair<std::string, std::string>> keys;
    for (const auto& pair : pairs) {
        const std::string key = build_profile_key(config, pair.first, pair.second);
        CHECK(keys.find(key) == keys.end());
        keys[key] = pair;
    }
}

TEST_CASE(test_hidden_key_injective_over_cross_product_of_ids) {
    ServiceConfig config;
    const std::vector<std::string> ids = {"1", "12", "123", "1234", "2", "21", "3", "31", "13", "0", "01", "10"};
    std::map<std::string, std::pair<std::string, std::string>> keys;
    for (const auto& tenant_id : ids) {
        for (const auto& user_id : ids) {
            const std::string key = build_profile_key(config, tenant_id, user_id);
            CHECK(keys.find(key) == keys.end());
            keys[key] = {tenant_id, user_id};
        }
    }
}

TEST_CASE(test_hidden_negative_sentinel_is_tenant_scoped) {
    World w;
    w.origin->put(profile("77", "7", "Seventy Seven"));
    CHECK(!w.service->get_profile("7", "77").has_value());
    CHECK_EQ(w.service->get_profile("77", "7").value().display_name, "Seventy Seven");
    CHECK(!w.service->get_profile("7", "77").has_value());
    CHECK_EQ(w.service->get_profile("77", "7").value().display_name, "Seventy Seven");
}

TEST_CASE(test_hidden_negative_entry_expires_exactly_at_negative_ttl_boundary) {
    ServiceConfig config;
    config.negative_ttl_s = 45;
    World w(config);
    w.service->get_profile("12", "9");
    w.clock->advance(44);
    w.service->get_profile("12", "9");
    CHECK_EQ(w.origin->load_count, 1);
    w.clock->advance(1);
    w.service->get_profile("12", "9");
    CHECK_EQ(w.origin->load_count, 2);
}

TEST_CASE(test_hidden_update_from_one_tenant_does_not_evict_other_tenant) {
    World w;
    w.origin->put(profile("12", "345", "Acme Person"));
    w.origin->put(profile("123", "45", "Globex Person"));
    w.service->get_profile("123", "45");
    w.service->update_profile(profile("12", "345", "Acme Renamed", "", 2));
    CHECK_EQ(w.service->get_profile("123", "45").value().display_name, "Globex Person");
    const std::pair<std::string, std::string> globex{"123", "45"};
    CHECK_EQ(std::count(w.origin->load_calls.begin(), w.origin->load_calls.end(), globex), 1);
}

TEST_CASE(test_hidden_tenant_mismatch_evicts_poisoned_entry_and_repopulates) {
    World w;
    w.origin->put(profile("12", "7", "Acme Seven"));
    Profile foreign = profile("99", "7", "Initech Seven");
    const std::string key = build_profile_key(w.config, "12", "7");
    w.cache->seed(key, encode_profile(foreign), 600);
    w.service->get_profile("12", "7");
    CHECK(w.cache->raw_value(key) != encode_profile(foreign));
    CHECK_EQ(w.service->get_profile("12", "7").value().display_name, "Acme Seven");
    CHECK_EQ(w.origin->load_count, 1);
    CHECK_EQ(w.metrics->value("cache.tenant_mismatch"), 1);
    CHECK_EQ(w.metrics->value("cache.hit"), 1);
}

TEST_CASE(test_hidden_foreign_user_id_under_correct_tenant_is_rejected) {
    World w;
    w.origin->put(profile("12", "7", "Acme Seven"));
    Profile other_user = profile("12", "8", "Acme Eight");
    w.cache->seed(build_profile_key(w.config, "12", "7"), encode_profile(other_user), 600);
    auto served = w.service->get_profile("12", "7");
    CHECK_EQ(served.value().user_id, "7");
    CHECK_EQ(served.value().display_name, "Acme Seven");
    CHECK_EQ(w.metrics->value("cache.tenant_mismatch"), 1);
}

TEST_CASE(test_hidden_disabling_negative_caching_does_not_affect_positive_entries) {
    ServiceConfig config;
    config.negative_caching_enabled = false;
    World w(config);
    w.origin->put(profile("12", "7"));
    w.service->get_profile("12", "7");
    w.service->get_profile("12", "7");
    CHECK_EQ(w.origin->load_count, 1);
    CHECK_EQ(w.metrics->value("cache.hit"), 1);
}

TEST_CASE(test_hidden_display_name_with_separator_character_roundtrips_through_cache) {
    World w;
    w.origin->put(profile("88", "1204", "Ops | Platform", "ops@acme.example"));
    auto first = w.api->get_profile("88", "1204");
    auto second = w.api->get_profile("88", "1204");
    CHECK_EQ(first.status, 200);
    CHECK_EQ(second.status, 200);
    CHECK_EQ(second.body["display_name"], "Ops | Platform");
    CHECK_EQ(second.body["email"], "ops@acme.example");
    CHECK_EQ(w.origin->load_count, 1);
}

TEST_CASE(test_hidden_cache_set_failure_does_not_fail_request) {
    World w;
    w.origin->put(profile("12", "7"));
    w.cache->fail_sets = true;
    CHECK_EQ(w.api->get_profile("12", "7").status, 200);
    CHECK(w.service->get_profile("12", "7") == profile("12", "7"));
    CHECK_EQ(w.origin->load_count, 2);
}

TEST_CASE(test_hidden_disabled_negative_caching_ignores_existing_sentinel) {
    ServiceConfig enabled;
    enabled.negative_caching_enabled = true;
    World w(enabled);
    CHECK(!w.service->get_profile("12", "9").has_value());
    w.origin->put(profile("12", "9", "Arrived"));
    ServiceConfig disabled_config;
    disabled_config.negative_caching_enabled = false;
    World disabled = w.with_config(disabled_config);
    auto found = disabled.service->get_profile("12", "9");
    CHECK(found.has_value());
    CHECK_EQ(found.value().display_name, "Arrived");
}

TEST_CASE(test_hidden_api_rejects_invalid_identifier_with_400) {
    World w;
    w.origin->put(profile("12", "7"));
    CHECK_EQ(w.api->get_profile("12", "7 ").status, 400);
    CHECK_EQ(w.api->get_profile("", "7").status, 400);
    CHECK_EQ(w.api->get_profile("12", std::string(65, 'x')).status, 400);
    CHECK_EQ(w.api->get_profile("12", "7").status, 200);
    CHECK_EQ(w.origin->load_count, 1);
}
