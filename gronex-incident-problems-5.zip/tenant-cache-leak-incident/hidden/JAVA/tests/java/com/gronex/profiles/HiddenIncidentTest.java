package com.gronex.profiles;

import static com.gronex.profiles.CacheKeys.buildProfileKey;
import static com.gronex.profiles.Codec.encodeProfile;
import static com.gronex.profiles.World.profile;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

class HiddenIncidentTest {

    @Test
    void test_hidden_key_injective_with_delimiter_characters_in_ids() {
        ServiceConfig config = ServiceConfig.defaults();
        List<List<String>> pairs = List.of(
                List.of("12:3", "45"), List.of("12", "3:45"), List.of("1", "2:3:45"), List.of("12:3:4", "5"),
                List.of("a-b", "c"), List.of("a", "b-c"), List.of("a_b", "c"), List.of("a", "b_c"));
        Map<String, List<String>> keys = new HashMap<>();
        for (List<String> pair : pairs) {
            String tenantId = pair.get(0);
            String userId = pair.get(1);
            String key = buildProfileKey(config, tenantId, userId);
            assertFalse(keys.containsKey(key), () -> "(" + tenantId + ", " + userId + ") collides with " + keys.get(key));
            keys.put(key, pair);
        }
    }

    @Test
    void test_hidden_key_injective_over_cross_product_of_ids() {
        ServiceConfig config = ServiceConfig.defaults();
        List<String> ids = List.of("1", "12", "123", "1234", "2", "21", "3", "31", "13", "0", "01", "10");
        Map<String, List<String>> keys = new HashMap<>();
        for (String tenantId : ids) {
            for (String userId : ids) {
                String key = buildProfileKey(config, tenantId, userId);
                assertFalse(keys.containsKey(key), () -> "(" + tenantId + ", " + userId + ") collides with " + keys.get(key));
                keys.put(key, List.of(tenantId, userId));
            }
        }
    }

    @Test
    void test_hidden_negative_sentinel_is_tenant_scoped() {
        World w = new World();
        w.origin.put(profile("77", "7", "Seventy Seven"));
        assertNull(w.service.getProfile("7", "77"));
        assertEquals("Seventy Seven", w.service.getProfile("77", "7").displayName());
        assertNull(w.service.getProfile("7", "77"));
        assertEquals("Seventy Seven", w.service.getProfile("77", "7").displayName());
    }

    @Test
    void test_hidden_negative_entry_expires_exactly_at_negative_ttl_boundary() {
        World w = new World(ServiceConfig.defaults().withNegativeTtlS(45));
        w.service.getProfile("12", "9");
        w.clock.advance(44);
        w.service.getProfile("12", "9");
        assertEquals(1, w.origin.loadCount);
        w.clock.advance(1);
        w.service.getProfile("12", "9");
        assertEquals(2, w.origin.loadCount);
    }

    @Test
    void test_hidden_update_from_one_tenant_does_not_evict_other_tenant() {
        World w = new World();
        w.origin.put(profile("12", "345", "Acme Person"));
        w.origin.put(profile("123", "45", "Globex Person"));
        w.service.getProfile("123", "45");
        w.service.updateProfile(profile("12", "345", "Acme Renamed", null, 2));
        assertEquals("Globex Person", w.service.getProfile("123", "45").displayName());
        assertEquals(1, Collections.frequency(w.origin.loadCalls, new Fakes.LoadCall("123", "45")));
    }

    @Test
    void test_hidden_tenant_mismatch_evicts_poisoned_entry_and_repopulates() {
        World w = new World();
        w.origin.put(profile("12", "7", "Acme Seven"));
        Profile foreign = profile("99", "7", "Initech Seven");
        String key = buildProfileKey(w.config, "12", "7");
        w.cache.seed(key, encodeProfile(foreign), 600);
        w.service.getProfile("12", "7");
        assertNotEquals(encodeProfile(foreign), w.cache.rawValue(key));
        assertEquals("Acme Seven", w.service.getProfile("12", "7").displayName());
        assertEquals(1, w.origin.loadCount);
        assertEquals(1, w.metrics.value("cache.tenant_mismatch"));
        assertEquals(1, w.metrics.value("cache.hit"));
    }

    @Test
    void test_hidden_foreign_user_id_under_correct_tenant_is_rejected() {
        World w = new World();
        w.origin.put(profile("12", "7", "Acme Seven"));
        Profile otherUser = profile("12", "8", "Acme Eight");
        w.cache.seed(buildProfileKey(w.config, "12", "7"), encodeProfile(otherUser), 600);
        Profile served = w.service.getProfile("12", "7");
        assertEquals("7", served.userId());
        assertEquals("Acme Seven", served.displayName());
        assertEquals(1, w.metrics.value("cache.tenant_mismatch"));
    }

    @Test
    void test_hidden_disabling_negative_caching_does_not_affect_positive_entries() {
        World w = new World(ServiceConfig.defaults().withNegativeCachingEnabled(false));
        w.origin.put(profile("12", "7"));
        w.service.getProfile("12", "7");
        w.service.getProfile("12", "7");
        assertEquals(1, w.origin.loadCount);
        assertEquals(1, w.metrics.value("cache.hit"));
    }

    @Test
    void test_hidden_display_name_with_separator_character_roundtrips_through_cache() {
        World w = new World();
        w.origin.put(profile("88", "1204", "Ops | Platform", "ops@acme.example"));
        ApiResponse first = w.api.getProfile("88", "1204");
        ApiResponse second = w.api.getProfile("88", "1204");
        assertEquals(200, first.status());
        assertEquals(200, second.status());
        assertEquals("Ops | Platform", second.body().get("display_name"));
        assertEquals("ops@acme.example", second.body().get("email"));
        assertEquals(1, w.origin.loadCount);
    }

    @Test
    void test_hidden_cache_set_failure_does_not_fail_request() {
        World w = new World();
        w.origin.put(profile("12", "7"));
        w.cache.failSets = true;
        assertEquals(200, w.api.getProfile("12", "7").status());
        assertEquals(profile("12", "7"), w.service.getProfile("12", "7"));
        assertEquals(2, w.origin.loadCount);
    }

    @Test
    void test_hidden_disabled_negative_caching_ignores_existing_sentinel() {
        World w = new World(ServiceConfig.defaults().withNegativeCachingEnabled(true));
        assertNull(w.service.getProfile("12", "9"));
        w.origin.put(profile("12", "9", "Arrived"));
        World disabled = w.withConfig(ServiceConfig.defaults().withNegativeCachingEnabled(false));
        Profile found = disabled.service.getProfile("12", "9");
        assertNotNull(found);
        assertEquals("Arrived", found.displayName());
    }

    @Test
    void test_hidden_api_rejects_invalid_identifier_with_400() {
        World w = new World();
        w.origin.put(profile("12", "7"));
        assertEquals(400, w.api.getProfile("12", "7 ").status());
        assertEquals(400, w.api.getProfile("", "7").status());
        assertEquals(400, w.api.getProfile("12", "x".repeat(65)).status());
        assertEquals(200, w.api.getProfile("12", "7").status());
        assertEquals(1, w.origin.loadCount);
    }
}
