from itertools import product

from profile_service.cache_keys import build_profile_key
from profile_service.codec import encode_profile
from profile_service.config import ServiceConfig

from harness import World, profile


def test_hidden_key_injective_with_delimiter_characters_in_ids():
    config = ServiceConfig()
    pairs = [("12:3", "45"), ("12", "3:45"), ("1", "2:3:45"), ("12:3:4", "5"), ("a-b", "c"), ("a", "b-c"), ("a_b", "c"), ("a", "b_c")]
    keys = {}
    for tenant_id, user_id in pairs:
        key = build_profile_key(config, tenant_id, user_id)
        assert key not in keys, (tenant_id, user_id, keys.get(key))
        keys[key] = (tenant_id, user_id)


def test_hidden_key_injective_over_cross_product_of_ids():
    config = ServiceConfig()
    ids = ["1", "12", "123", "1234", "2", "21", "3", "31", "13", "0", "01", "10"]
    keys = {}
    for tenant_id, user_id in product(ids, ids):
        key = build_profile_key(config, tenant_id, user_id)
        assert key not in keys, (tenant_id, user_id, keys.get(key))
        keys[key] = (tenant_id, user_id)


def test_hidden_negative_sentinel_is_tenant_scoped():
    w = World()
    w.origin.put(profile("77", "7", display_name="Seventy Seven"))
    assert w.service.get_profile("7", "77") is None
    assert w.service.get_profile("77", "7").display_name == "Seventy Seven"
    assert w.service.get_profile("7", "77") is None
    assert w.service.get_profile("77", "7").display_name == "Seventy Seven"


def test_hidden_negative_entry_expires_exactly_at_negative_ttl_boundary():
    w = World(ServiceConfig(negative_ttl_s=45))
    w.service.get_profile("12", "9")
    w.clock.advance(44)
    w.service.get_profile("12", "9")
    assert w.origin.load_count == 1
    w.clock.advance(1)
    w.service.get_profile("12", "9")
    assert w.origin.load_count == 2


def test_hidden_update_from_one_tenant_does_not_evict_other_tenant():
    w = World()
    w.origin.put(profile("12", "345", display_name="Acme Person"))
    w.origin.put(profile("123", "45", display_name="Globex Person"))
    w.service.get_profile("123", "45")
    w.service.update_profile(profile("12", "345", display_name="Acme Renamed", version=2))
    assert w.service.get_profile("123", "45").display_name == "Globex Person"
    assert w.origin.load_calls.count(("123", "45")) == 1


def test_hidden_tenant_mismatch_evicts_poisoned_entry_and_repopulates():
    w = World()
    w.origin.put(profile("12", "7", display_name="Acme Seven"))
    foreign = profile("99", "7", display_name="Initech Seven")
    key = build_profile_key(w.config, "12", "7")
    w.cache.seed(key, encode_profile(foreign), 600)
    w.service.get_profile("12", "7")
    assert w.cache.raw_value(key) != encode_profile(foreign)
    assert w.service.get_profile("12", "7").display_name == "Acme Seven"
    assert w.origin.load_count == 1
    assert w.metrics.value("cache.tenant_mismatch") == 1
    assert w.metrics.value("cache.hit") == 1


def test_hidden_foreign_user_id_under_correct_tenant_is_rejected():
    w = World()
    w.origin.put(profile("12", "7", display_name="Acme Seven"))
    other_user = profile("12", "8", display_name="Acme Eight")
    w.cache.seed(build_profile_key(w.config, "12", "7"), encode_profile(other_user), 600)
    served = w.service.get_profile("12", "7")
    assert served.user_id == "7"
    assert served.display_name == "Acme Seven"
    assert w.metrics.value("cache.tenant_mismatch") == 1


def test_hidden_disabling_negative_caching_does_not_affect_positive_entries():
    w = World(ServiceConfig(negative_caching_enabled=False))
    w.origin.put(profile("12", "7"))
    w.service.get_profile("12", "7")
    w.service.get_profile("12", "7")
    assert w.origin.load_count == 1
    assert w.metrics.value("cache.hit") == 1


def test_hidden_display_name_with_separator_character_roundtrips_through_cache():
    w = World()
    w.origin.put(profile("88", "1204", display_name="Ops | Platform", email="ops@acme.example"))
    first = w.api.get_profile("88", "1204")
    second = w.api.get_profile("88", "1204")
    assert first.status == 200
    assert second.status == 200
    assert second.body["display_name"] == "Ops | Platform"
    assert second.body["email"] == "ops@acme.example"
    assert w.origin.load_count == 1


def test_hidden_cache_set_failure_does_not_fail_request():
    w = World()
    w.origin.put(profile("12", "7"))
    w.cache.fail_sets = True
    assert w.api.get_profile("12", "7").status == 200
    assert w.service.get_profile("12", "7") == profile("12", "7")
    assert w.origin.load_count == 2


def test_hidden_disabled_negative_caching_ignores_existing_sentinel():
    w = World(ServiceConfig(negative_caching_enabled=True))
    assert w.service.get_profile("12", "9") is None
    w.origin.put(profile("12", "9", display_name="Arrived"))
    disabled = w.with_config(ServiceConfig(negative_caching_enabled=False))
    found = disabled.service.get_profile("12", "9")
    assert found is not None
    assert found.display_name == "Arrived"


def test_hidden_api_rejects_invalid_identifier_with_400():
    w = World()
    w.origin.put(profile("12", "7"))
    assert w.api.get_profile("12", "7 ").status == 400
    assert w.api.get_profile("", "7").status == 400
    assert w.api.get_profile("12", "x" * 65).status == 400
    assert w.api.get_profile("12", "7").status == 200
    assert w.origin.load_count == 1
