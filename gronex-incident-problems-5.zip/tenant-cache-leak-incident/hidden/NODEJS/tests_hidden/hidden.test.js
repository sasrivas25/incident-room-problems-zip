'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { buildProfileKey } = require('../src/cache_keys');
const { encodeProfile } = require('../src/codec');
const { serviceConfig } = require('../src/config');

const { World, profile, countCalls } = require('../tests/harness');

test('test_hidden_key_injective_with_delimiter_characters_in_ids', () => {
  const config = serviceConfig();
  const pairs = [['12:3', '45'], ['12', '3:45'], ['1', '2:3:45'], ['12:3:4', '5'], ['a-b', 'c'], ['a', 'b-c'], ['a_b', 'c'], ['a', 'b_c']];
  const keys = new Map();
  for (const [tenantId, userId] of pairs) {
    const key = buildProfileKey(config, tenantId, userId);
    assert.ok(!keys.has(key), JSON.stringify([tenantId, userId, keys.get(key)]));
    keys.set(key, [tenantId, userId]);
  }
});

test('test_hidden_key_injective_over_cross_product_of_ids', () => {
  const config = serviceConfig();
  const ids = ['1', '12', '123', '1234', '2', '21', '3', '31', '13', '0', '01', '10'];
  const keys = new Map();
  for (const tenantId of ids) {
    for (const userId of ids) {
      const key = buildProfileKey(config, tenantId, userId);
      assert.ok(!keys.has(key), JSON.stringify([tenantId, userId, keys.get(key)]));
      keys.set(key, [tenantId, userId]);
    }
  }
});

test('test_hidden_negative_sentinel_is_tenant_scoped', () => {
  const w = new World();
  w.origin.put(profile('77', '7', 'Seventy Seven'));
  assert.equal(w.service.getProfile('7', '77'), null);
  assert.equal(w.service.getProfile('77', '7').displayName, 'Seventy Seven');
  assert.equal(w.service.getProfile('7', '77'), null);
  assert.equal(w.service.getProfile('77', '7').displayName, 'Seventy Seven');
});

test('test_hidden_negative_entry_expires_exactly_at_negative_ttl_boundary', () => {
  const w = new World(serviceConfig({ negativeTtlS: 45 }));
  w.service.getProfile('12', '9');
  w.clock.advance(44);
  w.service.getProfile('12', '9');
  assert.equal(w.origin.loadCount, 1);
  w.clock.advance(1);
  w.service.getProfile('12', '9');
  assert.equal(w.origin.loadCount, 2);
});

test('test_hidden_update_from_one_tenant_does_not_evict_other_tenant', () => {
  const w = new World();
  w.origin.put(profile('12', '345', 'Acme Person'));
  w.origin.put(profile('123', '45', 'Globex Person'));
  w.service.getProfile('123', '45');
  w.service.updateProfile(profile('12', '345', 'Acme Renamed', null, 2));
  assert.equal(w.service.getProfile('123', '45').displayName, 'Globex Person');
  assert.equal(countCalls(w.origin.loadCalls, '123', '45'), 1);
});

test('test_hidden_tenant_mismatch_evicts_poisoned_entry_and_repopulates', () => {
  const w = new World();
  w.origin.put(profile('12', '7', 'Acme Seven'));
  const foreign = profile('99', '7', 'Initech Seven');
  const key = buildProfileKey(w.config, '12', '7');
  w.cache.seed(key, encodeProfile(foreign), 600);
  w.service.getProfile('12', '7');
  assert.notEqual(w.cache.rawValue(key), encodeProfile(foreign));
  assert.equal(w.service.getProfile('12', '7').displayName, 'Acme Seven');
  assert.equal(w.origin.loadCount, 1);
  assert.equal(w.metrics.value('cache.tenant_mismatch'), 1);
  assert.equal(w.metrics.value('cache.hit'), 1);
});

test('test_hidden_foreign_user_id_under_correct_tenant_is_rejected', () => {
  const w = new World();
  w.origin.put(profile('12', '7', 'Acme Seven'));
  const otherUser = profile('12', '8', 'Acme Eight');
  w.cache.seed(buildProfileKey(w.config, '12', '7'), encodeProfile(otherUser), 600);
  const served = w.service.getProfile('12', '7');
  assert.equal(served.userId, '7');
  assert.equal(served.displayName, 'Acme Seven');
  assert.equal(w.metrics.value('cache.tenant_mismatch'), 1);
});

test('test_hidden_disabling_negative_caching_does_not_affect_positive_entries', () => {
  const w = new World(serviceConfig({ negativeCachingEnabled: false }));
  w.origin.put(profile('12', '7'));
  w.service.getProfile('12', '7');
  w.service.getProfile('12', '7');
  assert.equal(w.origin.loadCount, 1);
  assert.equal(w.metrics.value('cache.hit'), 1);
});

test('test_hidden_display_name_with_separator_character_roundtrips_through_cache', () => {
  const w = new World();
  w.origin.put(profile('88', '1204', 'Ops | Platform', 'ops@acme.example'));
  const first = w.api.getProfile('88', '1204');
  const second = w.api.getProfile('88', '1204');
  assert.equal(first.status, 200);
  assert.equal(second.status, 200);
  assert.equal(second.body.display_name, 'Ops | Platform');
  assert.equal(second.body.email, 'ops@acme.example');
  assert.equal(w.origin.loadCount, 1);
});

test('test_hidden_cache_set_failure_does_not_fail_request', () => {
  const w = new World();
  w.origin.put(profile('12', '7'));
  w.cache.failSets = true;
  assert.equal(w.api.getProfile('12', '7').status, 200);
  assert.deepEqual(w.service.getProfile('12', '7'), profile('12', '7'));
  assert.equal(w.origin.loadCount, 2);
});

test('test_hidden_disabled_negative_caching_ignores_existing_sentinel', () => {
  const w = new World(serviceConfig({ negativeCachingEnabled: true }));
  assert.equal(w.service.getProfile('12', '9'), null);
  w.origin.put(profile('12', '9', 'Arrived'));
  const disabled = w.withConfig(serviceConfig({ negativeCachingEnabled: false }));
  const found = disabled.service.getProfile('12', '9');
  assert.notEqual(found, null);
  assert.equal(found.displayName, 'Arrived');
});

test('test_hidden_api_rejects_invalid_identifier_with_400', () => {
  const w = new World();
  w.origin.put(profile('12', '7'));
  assert.equal(w.api.getProfile('12', '7 ').status, 400);
  assert.equal(w.api.getProfile('', '7').status, 400);
  assert.equal(w.api.getProfile('12', 'x'.repeat(65)).status, 400);
  assert.equal(w.api.getProfile('12', '7').status, 200);
  assert.equal(w.origin.loadCount, 1);
});
