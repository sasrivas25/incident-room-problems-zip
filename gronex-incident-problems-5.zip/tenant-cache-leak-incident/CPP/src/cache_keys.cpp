#include "cache_keys.hpp"

const std::string KEY_PREFIX = "p";

std::string build_profile_key(const ServiceConfig& config, const std::string& tenant_id, const std::string& user_id) {
    (void)config;
    return KEY_PREFIX + tenant_id + user_id;
}
