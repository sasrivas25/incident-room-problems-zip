# profile-service dashboard, 2026-10-29 09:00-09:35 UTC

Text rendering of `traffic.csv` and `cache.csv` (15 s resolution; charts below sample every 30 s, one character per sample).

Markers under each chart: `R` cache-3 restart 09:13:12, `▲` deploy r2 started 09:14:02, `△` rollout complete 09:16:30, `!` alert fired (09:13:45 cache_hit_ratio, 09:19:15 http_404_ratio).

## Timeline

| Time (UTC) | Event |
| --- | --- |
| 09:13:10 | cache-3 host maintenance reboot begins |
| 09:13:12 | cache-3 leaves the ring; its key range remaps to cache-1 and cache-2 |
| 09:13:45 | ALERT cache_hit_ratio below 0.80 |
| 09:13:48 | cache-3 rejoins the ring, cold |
| 09:14:02 | deploy 2026.10.29-r2 (PROF-4471) starts, pod 1 of 6 |
| 09:15:45 | cache_hit_ratio alert resolved |
| 09:16:30 | rollout complete, 6 of 6 pods on r2 |
| 09:19:15 | ALERT http_404_ratio above 0.020 |
| 09:21:04 | Support escalation SUP-88213 (tenant 12 sees a tenant 123 profile), not in logs |

## Panels

### Request rate (req/s, all pods)

```
max 429.4
▄▆▆▆▆▇▆▆█▆▅▅██▇▅█▆█▅▇▇▆▇▇▇▅▇▄▆▄▄▂▄▂▅▂▃▃▁▃▃▁▃▃▃▂▁▁▁▁▁▁▄▃▁▁▂▅▃▂▄▂▅▄▅▅▇▆▇▄
                          R!▲    △    !                                
09:00                         09:17:30                       09:35
min 411.8
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 426.1 |
| 09:13:30 cache-3 down | 425.1 |
| 09:16:30 rollout complete | 418.7 |
| 09:19:15 404 alert | 416.8 |
| 09:26:00 steady state | 413.8 |
| 09:35:00 end | 420.4 |

### Cache hit ratio (0-1)

```
max 0.938
███████████████████████████▁▁▂▄▆███████████████████████████████████████
                          R!▲    △    !                                
09:00                         09:17:30                       09:35
min 0.620
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 0.908 |
| 09:13:30 cache-3 down | 0.620 |
| 09:16:30 rollout complete | 0.913 |
| 09:19:15 404 alert | 0.920 |
| 09:26:00 steady state | 0.935 |
| 09:35:00 end | 0.933 |

### HTTP 404 ratio (0-1)

```
max 0.035
▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▂▃▄▄▅▆▇▇███████████████████████████████
                          R!▲    △    !                                
09:00                         09:17:30                       09:35
min 0.004
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 0.004 |
| 09:13:30 cache-3 down | 0.004 |
| 09:16:30 rollout complete | 0.012 |
| 09:19:15 404 alert | 0.029 |
| 09:26:00 steady state | 0.034 |
| 09:35:00 end | 0.033 |

### HTTP 5xx ratio (0-1)

```
max 0.002
▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁█▁▁▁▁▁▁▁▁█▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁█▁▁▁▁▁▁▁▁
                          R!▲    △    !                                
09:00                         09:17:30                       09:35
min 0.000
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 0.000 |
| 09:13:30 cache-3 down | 0.000 |
| 09:16:30 rollout complete | 0.000 |
| 09:19:15 404 alert | 0.000 |
| 09:26:00 steady state | 0.000 |
| 09:35:00 end | 0.000 |

### Origin DB queries (qps)

```
max 162.3
▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁██▇▅▃▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁
                          R!▲    △    !                                
09:00                         09:17:30                       09:35
min 25.9
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 38.8 |
| 09:13:30 cache-3 down | 162.3 |
| 09:16:30 rollout complete | 35.7 |
| 09:19:15 404 alert | 34.0 |
| 09:26:00 steady state | 26.9 |
| 09:35:00 end | 28.4 |

### Origin DB p99 latency (ms)

```
max 42.0
▁▁▁▁▁▁▂▁▁▂▁▁▂▁▂▁▁▁▂▁▂▁▁▁▁▁▁██▇▅▃▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁
                          R!▲    △    !                                
09:00                         09:17:30                       09:35
min 15.1
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 18.5 |
| 09:13:30 cache-3 down | 42.0 |
| 09:16:30 rollout complete | 17.4 |
| 09:19:15 404 alert | 17.6 |
| 09:26:00 steady state | 15.5 |
| 09:35:00 end | 15.5 |

### Cache distinct keys (cluster total)

```
max 1,841,191
███████████████████████████▁▂▄▅▆▇▇▇███▇▇▇▇▆▆▆▅▅▅▅▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
                          R!▲    △    !                                
09:00                         09:17:30                       09:35
min 1,236,060
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 1,838,932 |
| 09:13:30 cache-3 down | 1,236,060 |
| 09:16:30 rollout complete | 1,743,574 |
| 09:19:15 404 alert | 1,746,883 |
| 09:26:00 steady state | 1,510,542 |
| 09:35:00 end | 1,511,424 |

### Cache memory used (MB, cluster total)

```
max 2,105
███████████████████████████▁▂▄▅▆▇▇███▇▇▆▆▅▅▄▄▃▃▂▂▂▂▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁
                          R!▲    △    !                                
09:00                         09:17:30                       09:35
min 1,409
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 2,099 |
| 09:13:30 cache-3 down | 1,409 |
| 09:16:30 rollout complete | 1,993 |
| 09:19:15 404 alert | 1,945 |
| 09:26:00 steady state | 1,482 |
| 09:35:00 end | 1,477 |

### Cache evictions (per s, cluster total)

```
max 1060.0
▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁█▆▃▂▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁
                          R!▲    △    !                                
09:00                         09:17:30                       09:35
min 17.0
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 22.0 |
| 09:13:30 cache-3 down | 1060.0 |
| 09:16:30 rollout complete | 22.0 |
| 09:19:15 404 alert | 54.0 |
| 09:26:00 steady state | 21.0 |
| 09:35:00 end | 20.0 |

## Panel notes

- Request rate is flat across the whole window. Nothing upstream changed.
- Cache hit ratio dips with the cache-3 restart and recovers by 09:15:45. After the rollout it settles above the pre-incident baseline.
- Origin query rate and p99 track the hit ratio dip and return to baseline; the origin is not the bottleneck at any point.
- Distinct key count: the restart removes about a third of keys and the refill is nearly complete by 09:16. From 09:17 the count declines again and settles around 09:26, 18 percent below the pre-incident baseline, with request rate unchanged. Legacy entries written before 09:16:30 reach their 600 s TTL between 09:24 and 09:26:30.
- Memory follows the key count and the smaller r2 payload.
- Evictions spike while cache-1 and cache-2 absorb the cache-3 key range, then a mild second bump accompanies the key turnover after the rollout.
- 404 ratio starts climbing with the first r2 pod and plateaus near 3.4 percent once all pods are on r2. It does not correlate with the hit ratio dip.
- 5xx ratio shows three isolated blips (09:17:44, 09:22:10, 09:31:02); see the stack traces in app.log.
