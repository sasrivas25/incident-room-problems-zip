#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "=============================================="
echo " Gronex verify — Cross-Tenant Profile Leak (C++)"
echo "=============================================="

if ! command -v cmake >/dev/null 2>&1; then
  echo "ERROR: cmake not found. Install CMake 3.15+ and a C++17 compiler, then re-run ./verify.sh"
  exit 2
fi

# Configure + build. A hidden test file dropped into tests/cpp/ is picked up by the glob,
# so always re-run the configure step.
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build

set +e
(cd build && ctest --output-on-failure)
STATUS=$?
set -e

echo "----------------------------------------------"
if [ "$STATUS" -eq 0 ]; then
  echo "✅ PASS — all checks green. Your solution is correct."
else
  echo "❌ FAIL — some checks did not pass. Keep going!"
  echo "   Read the failures above; fix src/, then run ./verify.sh again."
fi
exit "$STATUS"
