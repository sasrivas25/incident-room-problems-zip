#pragma once

#include <memory>
#include <string>

#include "api.hpp"
#include "config.hpp"
#include "fakes.hpp"
#include "metrics.hpp"
#include "models.hpp"
#include "service.hpp"

struct World {
    ServiceConfig config;
    std::shared_ptr<FakeClock> clock;
    std::shared_ptr<FakeCacheStore> cache;
    std::shared_ptr<FakeOrigin> origin;
    std::shared_ptr<Metrics> metrics;
    std::shared_ptr<ProfileService> service;
    std::shared_ptr<ProfileApi> api;

    explicit World(const ServiceConfig& config_ = ServiceConfig{})
        : config(config_),
          clock(std::make_shared<FakeClock>()),
          cache(std::make_shared<FakeCacheStore>(*clock)),
          origin(std::make_shared<FakeOrigin>()),
          metrics(std::make_shared<Metrics>()),
          service(std::make_shared<ProfileService>(config, *cache, *origin, *clock, *metrics)),
          api(std::make_shared<ProfileApi>(*service)) {}

    World with_config(const ServiceConfig& other_config) const {
        World other(other_config);
        other.clock = clock;
        other.cache = cache;
        other.origin = origin;
        other.metrics = std::make_shared<Metrics>();
        other.service = std::make_shared<ProfileService>(other_config, *other.cache, *other.origin, *other.clock, *other.metrics);
        other.api = std::make_shared<ProfileApi>(*other.service);
        return other;
    }
};

inline Profile profile(const std::string& tenant_id, const std::string& user_id, const std::string& display_name = "",
                       const std::string& email = "", int version = 1) {
    const std::string name = display_name.empty() ? "User " + user_id + " of " + tenant_id : display_name;
    const std::string mail = email.empty() ? "u" + user_id + "@t" + tenant_id + ".example" : email;
    return Profile{tenant_id, user_id, name, mail, version};
}
