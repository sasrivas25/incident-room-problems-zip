#pragma once

#include <algorithm>
#include <map>
#include <optional>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

#include "cache_store.hpp"
#include "clock.hpp"
#include "models.hpp"
#include "origin.hpp"

class FakeClock : public Clock {
public:
    explicit FakeClock(double start = 1000000.0) : now_(start) {}

    double now() override { return now_; }

    void advance(double seconds) { now_ += seconds; }

private:
    double now_;
};

class FakeCacheStore : public CacheStore {
public:
    explicit FakeCacheStore(FakeClock& clock) : clock_(clock) {}

    bool fail_gets = false;
    bool fail_sets = false;
    std::vector<std::tuple<std::string, std::string, int>> set_calls;

    std::optional<std::string> get(const std::string& key) override {
        if (fail_gets) {
            throw CacheUnavailableError("ECONNRESET");
        }
        auto it = entries_.find(key);
        if (it == entries_.end()) {
            return std::nullopt;
        }
        if (clock_.now() >= it->second.second) {
            entries_.erase(it);
            return std::nullopt;
        }
        return it->second.first;
    }

    void set(const std::string& key, const std::string& value, int ttl_s) override {
        if (fail_sets) {
            throw CacheUnavailableError("ECONNRESET");
        }
        set_calls.emplace_back(key, value, ttl_s);
        entries_[key] = {value, clock_.now() + ttl_s};
    }

    void remove(const std::string& key) override { entries_.erase(key); }

    void seed(const std::string& key, const std::string& value, int ttl_s) {
        entries_[key] = {value, clock_.now() + ttl_s};
    }

    std::optional<std::string> raw_value(const std::string& key) const {
        auto it = entries_.find(key);
        if (it == entries_.end()) {
            return std::nullopt;
        }
        return it->second.first;
    }

    std::vector<std::string> keys() const {
        std::vector<std::string> result;
        for (const auto& entry : entries_) {
            result.push_back(entry.first);
        }
        std::sort(result.begin(), result.end());
        return result;
    }

private:
    FakeClock& clock_;
    std::map<std::string, std::pair<std::string, double>> entries_;
};

class FakeOrigin : public ProfileOrigin {
public:
    int load_count = 0;
    std::vector<std::pair<std::string, std::string>> load_calls;

    void put(const Profile& profile) { rows_[{profile.tenant_id, profile.user_id}] = profile; }

    std::optional<Profile> load(const std::string& tenant_id, const std::string& user_id) override {
        ++load_count;
        load_calls.emplace_back(tenant_id, user_id);
        auto it = rows_.find({tenant_id, user_id});
        if (it == rows_.end()) {
            return std::nullopt;
        }
        return it->second;
    }

    void save(const Profile& profile) override { rows_[{profile.tenant_id, profile.user_id}] = profile; }

private:
    std::map<std::pair<std::string, std::string>, Profile> rows_;
};
