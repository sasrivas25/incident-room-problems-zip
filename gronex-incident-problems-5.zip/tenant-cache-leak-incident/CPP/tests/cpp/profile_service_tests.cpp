#include <map>
#include <string>
#include <utility>
#include <vector>

#include "cache_keys.hpp"
#include "check.hpp"
#include "codec.hpp"
#include "config.hpp"
#include "harness.hpp"

TEST_CASE(test_cache_miss_loads_from_origin_and_populates_cache) {
    World w;
    w.origin->put(profile("12", "7"));
    auto first = w.service->get_profile("12", "7");
    CHECK(first == profile("12", "7"));
    CHECK_EQ(w.origin->load_count, 1);
    CHECK_EQ(w.metrics->value("cache.miss"), 1);
    CHECK_EQ(w.metrics->value("origin.load"), 1);
    CHECK_EQ(w.cache->keys().size(), 1u);
}

TEST_CASE(test_cache_hit_skips_origin) {
    World w;
    w.origin->put(profile("12", "7"));
    w.service->get_profile("12", "7");
    auto second = w.service->get_profile("12", "7");
    CHECK(second == profile("12", "7"));
    CHECK_EQ(w.origin->load_count, 1);
    CHECK_EQ(w.metrics->value("cache.hit"), 1);
}

TEST_CASE(test_cache_entry_expires_after_profile_ttl) {
    World w;
    w.origin->put(profile("12", "7"));
    w.service->get_profile("12", "7");
    w.clock->advance(599);
    w.service->get_profile("12", "7");
    CHECK_EQ(w.origin->load_count, 1);
    w.clock->advance(1);
    w.service->get_profile("12", "7");
    CHECK_EQ(w.origin->load_count, 2);
}

TEST_CASE(test_cache_unavailable_falls_back_to_origin) {
    World w;
    w.origin->put(profile("12", "7"));
    w.cache->fail_gets = true;
    CHECK(w.service->get_profile("12", "7") == profile("12", "7"));
    CHECK_EQ(w.origin->load_count, 1);
    CHECK(w.metrics->value("cache.error") >= 1);
}

TEST_CASE(test_update_profile_invalidates_cache_entry) {
    World w;
    w.origin->put(profile("12", "7", "", "", 1));
    w.service->get_profile("12", "7");
    w.service->update_profile(profile("12", "7", "Renamed", "", 2));
    auto updated = w.service->get_profile("12", "7");
    CHECK_EQ(updated.value().display_name, "Renamed");
    CHECK_EQ(updated.value().version, 2);
    CHECK_EQ(w.origin->load_count, 2);
}

TEST_CASE(test_distinct_tenants_same_user_id_get_distinct_profiles) {
    World w;
    w.origin->put(profile("12", "7", "Acme Seven"));
    w.origin->put(profile("13", "7", "Globex Seven"));
    CHECK_EQ(w.service->get_profile("12", "7").value().display_name, "Acme Seven");
    CHECK_EQ(w.service->get_profile("13", "7").value().display_name, "Globex Seven");
    CHECK_EQ(w.service->get_profile("12", "7").value().display_name, "Acme Seven");
}

TEST_CASE(test_api_returns_404_for_unknown_user) {
    World w;
    auto response = w.api->get_profile("12", "404");
    CHECK_EQ(response.status, 404);
    CHECK(response.body == (std::map<std::string, std::string>{{"error", "not_found"}}));
}

TEST_CASE(test_negative_entry_served_within_negative_ttl) {
    World w;
    w.service->get_profile("12", "9");
    w.clock->advance(29);
    CHECK(!w.service->get_profile("12", "9").has_value());
    CHECK_EQ(w.origin->load_count, 1);
    CHECK_EQ(w.metrics->value("cache.negative_hit"), 1);
}

TEST_CASE(test_key_collision_tenant_12_user_345_vs_tenant_123_user_45) {
    ServiceConfig config;
    CHECK(build_profile_key(config, "12", "345") != build_profile_key(config, "123", "45"));
}

TEST_CASE(test_key_builder_is_injective_for_digit_ids) {
    ServiceConfig config;
    const std::vector<std::string> ids = {"1", "2", "12", "21", "123", "4", "45", "345"};
    std::map<std::string, std::pair<std::string, std::string>> keys;
    for (const auto& tenant_id : ids) {
        for (const auto& user_id : ids) {
            const std::string key = build_profile_key(config, tenant_id, user_id);
            CHECK(keys.find(key) == keys.end());
            keys[key] = {tenant_id, user_id};
        }
    }
}

TEST_CASE(test_key_includes_key_version) {
    ServiceConfig v2;
    v2.key_version = "v2";
    ServiceConfig v3;
    v3.key_version = "v3";
    CHECK(build_profile_key(v2, "12", "7").find("v2") != std::string::npos);
    CHECK(build_profile_key(v3, "12", "7").find("v3") != std::string::npos);
    CHECK(build_profile_key(v2, "12", "7") != build_profile_key(v3, "12", "7"));
}

TEST_CASE(test_served_profile_belongs_to_requesting_tenant_after_collision) {
    World w;
    w.origin->put(profile("12", "345", "Acme Person", "acme@acme.example"));
    w.origin->put(profile("123", "45", "Globex Person", "globex@globex.example"));
    w.service->get_profile("123", "45");
    auto served = w.service->get_profile("12", "345");
    CHECK_EQ(served.value().tenant_id, "12");
    CHECK_EQ(served.value().user_id, "345");
    CHECK_EQ(served.value().display_name, "Acme Person");
    CHECK_EQ(served.value().email, "acme@acme.example");
}

TEST_CASE(test_key_version_rotation_isolates_old_entries) {
    ServiceConfig v2;
    v2.key_version = "v2";
    World w(v2);
    w.origin->put(profile("12", "7", "Before"));
    w.service->get_profile("12", "7");
    w.origin->save(profile("12", "7", "After", "", 2));
    ServiceConfig v3;
    v3.key_version = "v3";
    World rotated = w.with_config(v3);
    CHECK_EQ(rotated.service->get_profile("12", "7").value().display_name, "After");
    CHECK_EQ(w.service->get_profile("12", "7").value().display_name, "Before");
}

TEST_CASE(test_negative_entry_uses_negative_ttl) {
    World w;
    w.service->get_profile("12", "9");
    w.clock->advance(30);
    w.origin->put(profile("12", "9"));
    CHECK(w.service->get_profile("12", "9") == profile("12", "9"));
    CHECK_EQ(w.origin->load_count, 2);
}

TEST_CASE(test_create_profile_clears_negative_entry) {
    World w;
    CHECK(!w.service->get_profile("12", "9").has_value());
    w.service->create_profile(profile("12", "9", "Fresh"));
    auto created = w.service->get_profile("12", "9");
    CHECK(created.has_value());
    CHECK_EQ(created.value().display_name, "Fresh");
}

TEST_CASE(test_negative_caching_can_be_disabled_by_config) {
    ServiceConfig config;
    config.negative_caching_enabled = false;
    World w(config);
    CHECK(!w.service->get_profile("12", "9").has_value());
    CHECK(!w.service->get_profile("12", "9").has_value());
    CHECK_EQ(w.origin->load_count, 2);
    CHECK_EQ(w.metrics->value("cache.negative_hit"), 0);
}

TEST_CASE(test_missing_user_in_one_tenant_does_not_hide_user_in_other_tenant) {
    World w;
    w.origin->put(profile("123", "45", "Globex Person"));
    CHECK(!w.service->get_profile("12", "345").has_value());
    auto found = w.service->get_profile("123", "45");
    CHECK(found.has_value());
    CHECK_EQ(found.value().display_name, "Globex Person");
    CHECK_EQ(w.api->get_profile("123", "45").status, 200);
}

TEST_CASE(test_cached_value_with_foreign_tenant_is_rejected_and_reloaded) {
    World w;
    w.origin->put(profile("12", "7", "Acme Seven"));
    Profile foreign = profile("99", "7", "Initech Seven", "leak@initech.example");
    w.cache->seed(build_profile_key(w.config, "12", "7"), encode_profile(foreign), 600);
    auto served = w.service->get_profile("12", "7");
    CHECK_EQ(served.value().tenant_id, "12");
    CHECK_EQ(served.value().display_name, "Acme Seven");
    CHECK(served.value().email != "leak@initech.example");
    CHECK_EQ(w.origin->load_count, 1);
    CHECK_EQ(w.metrics->value("cache.tenant_mismatch"), 1);
}
