package com.gronex.profiles;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Fakes {
    private Fakes() {
    }

    public static final class FakeClock implements Clock {
        private double now;

        public FakeClock() {
            this(1_000_000.0);
        }

        public FakeClock(double start) {
            this.now = start;
        }

        @Override
        public double now() {
            return now;
        }

        public void advance(double seconds) {
            now += seconds;
        }
    }

    public record SetCall(String key, String value, int ttlS) {
    }

    public static final class FakeCacheStore implements CacheStore {
        private record Entry(String value, double expiresAt) {
        }

        private final FakeClock clock;
        private final Map<String, Entry> entries = new HashMap<>();
        public boolean failGets = false;
        public boolean failSets = false;
        public final List<SetCall> setCalls = new ArrayList<>();

        public FakeCacheStore(FakeClock clock) {
            this.clock = clock;
        }

        @Override
        public String get(String key) {
            if (failGets) {
                throw new CacheUnavailableError("ECONNRESET");
            }
            Entry entry = entries.get(key);
            if (entry == null) {
                return null;
            }
            if (clock.now() >= entry.expiresAt()) {
                entries.remove(key);
                return null;
            }
            return entry.value();
        }

        @Override
        public void set(String key, String value, int ttlS) {
            if (failSets) {
                throw new CacheUnavailableError("ECONNRESET");
            }
            setCalls.add(new SetCall(key, value, ttlS));
            entries.put(key, new Entry(value, clock.now() + ttlS));
        }

        @Override
        public void delete(String key) {
            entries.remove(key);
        }

        public void seed(String key, String value, int ttlS) {
            entries.put(key, new Entry(value, clock.now() + ttlS));
        }

        public String rawValue(String key) {
            Entry entry = entries.get(key);
            return entry == null ? null : entry.value();
        }

        public List<String> keys() {
            List<String> keys = new ArrayList<>(entries.keySet());
            Collections.sort(keys);
            return keys;
        }
    }

    public record LoadCall(String tenantId, String userId) {
    }

    public static final class FakeOrigin implements ProfileOrigin {
        private record RowKey(String tenantId, String userId) {
        }

        private final Map<RowKey, Profile> rows = new HashMap<>();
        public int loadCount = 0;
        public final List<LoadCall> loadCalls = new ArrayList<>();

        public void put(Profile profile) {
            rows.put(new RowKey(profile.tenantId(), profile.userId()), profile);
        }

        @Override
        public Profile load(String tenantId, String userId) {
            loadCount += 1;
            loadCalls.add(new LoadCall(tenantId, userId));
            return rows.get(new RowKey(tenantId, userId));
        }

        @Override
        public void save(Profile profile) {
            rows.put(new RowKey(profile.tenantId(), profile.userId()), profile);
        }
    }
}
