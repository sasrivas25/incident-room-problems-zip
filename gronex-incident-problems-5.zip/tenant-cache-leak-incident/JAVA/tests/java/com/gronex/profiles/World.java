package com.gronex.profiles;

public final class World {
    public ServiceConfig config;
    public Fakes.FakeClock clock;
    public Fakes.FakeCacheStore cache;
    public Fakes.FakeOrigin origin;
    public Metrics metrics;
    public ProfileService service;
    public ProfileApi api;

    public World() {
        this(null);
    }

    public World(ServiceConfig config) {
        this.config = config == null ? ServiceConfig.defaults() : config;
        this.clock = new Fakes.FakeClock();
        this.cache = new Fakes.FakeCacheStore(this.clock);
        this.origin = new Fakes.FakeOrigin();
        this.metrics = new Metrics();
        this.service = new ProfileService(this.config, this.cache, this.origin, this.clock, this.metrics);
        this.api = new ProfileApi(this.service);
    }

    public World withConfig(ServiceConfig config) {
        World other = new World(config);
        other.clock = this.clock;
        other.cache = this.cache;
        other.origin = this.origin;
        other.metrics = new Metrics();
        other.service = new ProfileService(config, this.cache, this.origin, this.clock, other.metrics);
        other.api = new ProfileApi(other.service);
        return other;
    }

    public static Profile profile(String tenantId, String userId) {
        return profile(tenantId, userId, null, null, 1);
    }

    public static Profile profile(String tenantId, String userId, String displayName) {
        return profile(tenantId, userId, displayName, null, 1);
    }

    public static Profile profile(String tenantId, String userId, String displayName, String email) {
        return profile(tenantId, userId, displayName, email, 1);
    }

    public static Profile profile(String tenantId, String userId, String displayName, String email, int version) {
        String name = displayName == null || displayName.isEmpty() ? "User " + userId + " of " + tenantId : displayName;
        String mail = email == null || email.isEmpty() ? "u" + userId + "@t" + tenantId + ".example" : email;
        return new Profile(tenantId, userId, name, mail, version);
    }
}
