package com.gronex.profiles;

import static com.gronex.profiles.CacheKeys.buildProfileKey;
import static com.gronex.profiles.Codec.encodeProfile;
import static com.gronex.profiles.World.profile;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

class ProfileServiceTest {

    @Test
    void test_cache_miss_loads_from_origin_and_populates_cache() {
        World w = new World();
        w.origin.put(profile("12", "7"));
        Profile first = w.service.getProfile("12", "7");
        assertEquals(profile("12", "7"), first);
        assertEquals(1, w.origin.loadCount);
        assertEquals(1, w.metrics.value("cache.miss"));
        assertEquals(1, w.metrics.value("origin.load"));
        assertEquals(1, w.cache.keys().size());
    }

    @Test
    void test_cache_hit_skips_origin() {
        World w = new World();
        w.origin.put(profile("12", "7"));
        w.service.getProfile("12", "7");
        Profile second = w.service.getProfile("12", "7");
        assertEquals(profile("12", "7"), second);
        assertEquals(1, w.origin.loadCount);
        assertEquals(1, w.metrics.value("cache.hit"));
    }

    @Test
    void test_cache_entry_expires_after_profile_ttl() {
        World w = new World();
        w.origin.put(profile("12", "7"));
        w.service.getProfile("12", "7");
        w.clock.advance(599);
        w.service.getProfile("12", "7");
        assertEquals(1, w.origin.loadCount);
        w.clock.advance(1);
        w.service.getProfile("12", "7");
        assertEquals(2, w.origin.loadCount);
    }

    @Test
    void test_cache_unavailable_falls_back_to_origin() {
        World w = new World();
        w.origin.put(profile("12", "7"));
        w.cache.failGets = true;
        assertEquals(profile("12", "7"), w.service.getProfile("12", "7"));
        assertEquals(1, w.origin.loadCount);
        assertTrue(w.metrics.value("cache.error") >= 1);
    }

    @Test
    void test_update_profile_invalidates_cache_entry() {
        World w = new World();
        w.origin.put(profile("12", "7", null, null, 1));
        w.service.getProfile("12", "7");
        w.service.updateProfile(profile("12", "7", "Renamed", null, 2));
        Profile updated = w.service.getProfile("12", "7");
        assertEquals("Renamed", updated.displayName());
        assertEquals(2, updated.version());
        assertEquals(2, w.origin.loadCount);
    }

    @Test
    void test_distinct_tenants_same_user_id_get_distinct_profiles() {
        World w = new World();
        w.origin.put(profile("12", "7", "Acme Seven"));
        w.origin.put(profile("13", "7", "Globex Seven"));
        assertEquals("Acme Seven", w.service.getProfile("12", "7").displayName());
        assertEquals("Globex Seven", w.service.getProfile("13", "7").displayName());
        assertEquals("Acme Seven", w.service.getProfile("12", "7").displayName());
    }

    @Test
    void test_api_returns_404_for_unknown_user() {
        World w = new World();
        ApiResponse response = w.api.getProfile("12", "404");
        assertEquals(404, response.status());
        assertEquals(Map.of("error", "not_found"), response.body());
    }

    @Test
    void test_negative_entry_served_within_negative_ttl() {
        World w = new World();
        w.service.getProfile("12", "9");
        w.clock.advance(29);
        assertNull(w.service.getProfile("12", "9"));
        assertEquals(1, w.origin.loadCount);
        assertEquals(1, w.metrics.value("cache.negative_hit"));
    }

    @Test
    void test_key_collision_tenant_12_user_345_vs_tenant_123_user_45() {
        ServiceConfig config = ServiceConfig.defaults();
        assertNotEquals(buildProfileKey(config, "12", "345"), buildProfileKey(config, "123", "45"));
    }

    @Test
    void test_key_builder_is_injective_for_digit_ids() {
        ServiceConfig config = ServiceConfig.defaults();
        List<String> ids = List.of("1", "2", "12", "21", "123", "4", "45", "345");
        Map<String, List<String>> keys = new HashMap<>();
        for (String tenantId : ids) {
            for (String userId : ids) {
                String key = buildProfileKey(config, tenantId, userId);
                assertFalse(keys.containsKey(key), () -> "(" + tenantId + ", " + userId + ") collides with " + keys.get(key));
                keys.put(key, List.of(tenantId, userId));
            }
        }
    }

    @Test
    void test_key_includes_key_version() {
        assertTrue(buildProfileKey(ServiceConfig.defaults().withKeyVersion("v2"), "12", "7").contains("v2"));
        assertTrue(buildProfileKey(ServiceConfig.defaults().withKeyVersion("v3"), "12", "7").contains("v3"));
        assertNotEquals(buildProfileKey(ServiceConfig.defaults().withKeyVersion("v2"), "12", "7"), buildProfileKey(ServiceConfig.defaults().withKeyVersion("v3"), "12", "7"));
    }

    @Test
    void test_served_profile_belongs_to_requesting_tenant_after_collision() {
        World w = new World();
        w.origin.put(profile("12", "345", "Acme Person", "acme@acme.example"));
        w.origin.put(profile("123", "45", "Globex Person", "globex@globex.example"));
        w.service.getProfile("123", "45");
        Profile served = w.service.getProfile("12", "345");
        assertEquals("12", served.tenantId());
        assertEquals("345", served.userId());
        assertEquals("Acme Person", served.displayName());
        assertEquals("acme@acme.example", served.email());
    }

    @Test
    void test_key_version_rotation_isolates_old_entries() {
        World w = new World(ServiceConfig.defaults().withKeyVersion("v2"));
        w.origin.put(profile("12", "7", "Before"));
        w.service.getProfile("12", "7");
        w.origin.save(profile("12", "7", "After", null, 2));
        World rotated = w.withConfig(ServiceConfig.defaults().withKeyVersion("v3"));
        assertEquals("After", rotated.service.getProfile("12", "7").displayName());
        assertEquals("Before", w.service.getProfile("12", "7").displayName());
    }

    @Test
    void test_negative_entry_uses_negative_ttl() {
        World w = new World();
        w.service.getProfile("12", "9");
        w.clock.advance(30);
        w.origin.put(profile("12", "9"));
        assertEquals(profile("12", "9"), w.service.getProfile("12", "9"));
        assertEquals(2, w.origin.loadCount);
    }

    @Test
    void test_create_profile_clears_negative_entry() {
        World w = new World();
        assertNull(w.service.getProfile("12", "9"));
        w.service.createProfile(profile("12", "9", "Fresh"));
        Profile created = w.service.getProfile("12", "9");
        assertNotNull(created);
        assertEquals("Fresh", created.displayName());
    }

    @Test
    void test_negative_caching_can_be_disabled_by_config() {
        World w = new World(ServiceConfig.defaults().withNegativeCachingEnabled(false));
        assertNull(w.service.getProfile("12", "9"));
        assertNull(w.service.getProfile("12", "9"));
        assertEquals(2, w.origin.loadCount);
        assertEquals(0, w.metrics.value("cache.negative_hit"));
    }

    @Test
    void test_missing_user_in_one_tenant_does_not_hide_user_in_other_tenant() {
        World w = new World();
        w.origin.put(profile("123", "45", "Globex Person"));
        assertNull(w.service.getProfile("12", "345"));
        Profile found = w.service.getProfile("123", "45");
        assertNotNull(found);
        assertEquals("Globex Person", found.displayName());
        assertEquals(200, w.api.getProfile("123", "45").status());
    }

    @Test
    void test_cached_value_with_foreign_tenant_is_rejected_and_reloaded() {
        World w = new World();
        w.origin.put(profile("12", "7", "Acme Seven"));
        Profile foreign = profile("99", "7", "Initech Seven", "leak@initech.example");
        w.cache.seed(buildProfileKey(w.config, "12", "7"), encodeProfile(foreign), 600);
        Profile served = w.service.getProfile("12", "7");
        assertEquals("12", served.tenantId());
        assertEquals("Acme Seven", served.displayName());
        assertNotEquals("leak@initech.example", served.email());
        assertEquals(1, w.origin.loadCount);
        assertEquals(1, w.metrics.value("cache.tenant_mismatch"));
    }
}
