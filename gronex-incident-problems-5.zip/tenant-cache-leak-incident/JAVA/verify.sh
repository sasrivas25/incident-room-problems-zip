#!/usr/bin/env bash
set -uo pipefail
cd "$(dirname "$0")"

echo "=============================================="
echo " Gronex verify — Cross-Tenant Profile Leak (Java)"
echo "=============================================="

if ! command -v mvn >/dev/null 2>&1; then
  echo "ERROR: mvn not found. Install Maven 3.6+ and a JDK 17+, then re-run ./verify.sh"
  exit 2
fi

LOG="$(mktemp "${TMPDIR:-/tmp}/gronex-java-verify.XXXXXX")"
trap 'rm -f "$LOG"' EXIT

# Full run goes to a log; only the lines a contestant needs are echoed back.
mvn -Dstyle.color=never test >"$LOG" 2>&1
STATUS=$?

grep -E 'Tests run:|FAIL|ERROR' "$LOG" \
  | grep -vE 'JAVA_TOOL_OPTIONS|^\[ERROR\] *$|Help 1|re-run Maven|Re-run Maven|Please refer|For more information|Failed to execute goal' \
  || true

echo "----------------------------------------------"
if [ "$STATUS" -eq 0 ]; then
  echo "✅ PASS — all checks green. Your solution is correct."
else
  echo "❌ FAIL — some checks did not pass. Keep going!"
  echo "   Read the failures above; fix src/, then run ./verify.sh again."
fi
exit "$STATUS"
