package com.gronex.orders;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public final class World {
    public final RoutingConfig config;
    public final Fakes.FakeClock clock;
    public final Fakes.FakePrimary primary;
    public final Map<String, Fakes.FakeReplica> replicas;
    public final Fakes.FakeMonitor monitor;
    public final Fakes.FakeSessionStore sessions;
    public final Metrics metrics;
    public final ReadRouter router;
    public final OrdersService service;
    public final OrdersApi api;

    public World() {
        this(null);
    }

    public World(RoutingConfig config) {
        this.config = config == null ? RoutingConfig.defaults() : config;
        this.clock = new Fakes.FakeClock();
        this.primary = new Fakes.FakePrimary();
        this.replicas = new LinkedHashMap<>();
        for (String name : this.config.replicaNames()) {
            this.replicas.put(name, new Fakes.FakeReplica(name, this.primary));
        }
        this.monitor = new Fakes.FakeMonitor(new ArrayList<>(this.replicas.values()));
        this.sessions = new Fakes.FakeSessionStore();
        this.metrics = new Metrics();
        this.router = new ReadRouter(this.config, this.monitor, this.sessions, this.clock, this.metrics);
        this.service = new OrdersService(this.config, this.primary, this.replicas, this.router, this.sessions, this.clock, this.metrics);
        this.api = new OrdersApi(this.service);
    }

    public Fakes.FakeReplica replica(String name) {
        return replicas.get(name);
    }

    public void allReplicasCatchUp() {
        for (Fakes.FakeReplica replica : replicas.values()) {
            replica.catchUp();
        }
    }

    public static Order order(String orderId) {
        return order(orderId, "c-1", 2500, "PLACED");
    }

    public static Order order(String orderId, String status) {
        return order(orderId, "c-1", 2500, status);
    }

    public static Order order(String orderId, String customerId, int totalCents, String status) {
        return new Order(orderId, customerId, totalCents, status);
    }
}
