package com.gronex.orders;

import static com.gronex.orders.ReadRouter.PRIMARY;
import static com.gronex.orders.World.order;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

class OrdersApiTest {

    @Test
    void test_create_order_returns_201_with_location() {
        World w = new World();
        ApiResponse response = w.api.createOrder("s-1", "o-100", "c-1", 2500);
        assertEquals(201, response.status());
        assertEquals("/v1/orders/o-100", response.body().get("location"));
        assertEquals(order("o-100"), w.primary.getOrder("o-100"));
    }

    @Test
    void test_read_without_recent_write_goes_to_replica() {
        World w = new World();
        w.service.createOrder("s-writer", order("o-100"));
        w.allReplicasCatchUp();
        assertEquals(order("o-100"), w.service.getOrder("s-reader", "o-100"));
        assertEquals(1, w.metrics.value("reads.replica"));
        assertEquals(0, w.metrics.value("reads.primary"));
    }

    @Test
    void test_unhealthy_replica_is_never_chosen() {
        World w = new World();
        w.service.createOrder("s-writer", order("o-100"));
        w.allReplicasCatchUp();
        w.replica("replica-a").healthy = false;
        RouteDecision decision = w.router.routeRead("s-reader");
        assertEquals("replica-b", decision.target());
    }

    @Test
    void test_all_replicas_unhealthy_falls_back_to_primary() {
        World w = new World();
        w.replica("replica-a").healthy = false;
        w.replica("replica-b").healthy = false;
        w.service.createOrder("s-writer", order("o-100"));
        assertEquals(PRIMARY, w.router.routeRead("s-reader").target());
        assertEquals(order("o-100"), w.service.getOrder("s-reader", "o-100"));
        assertEquals(1, w.metrics.value("reads.primary"));
    }

    @Test
    void test_pin_expires_after_read_your_writes_window() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        w.clock.advance(5);
        RouteDecision decision = w.router.routeRead("s-1");
        assertNotEquals(PRIMARY, decision.target());
        assertNull(decision.minLsn());
    }

    @Test
    void test_read_within_window_prefers_caught_up_replica_over_primary() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        w.replica("replica-a").catchUp();
        w.replica("replica-b").lagSeconds = 0.15;
        assertEquals(order("o-100"), w.service.getOrder("s-1", "o-100"));
        assertEquals(1, w.metrics.value("reads.replica"));
        assertEquals(0, w.metrics.value("reads.primary"));
    }

    @Test
    void test_session_without_pin_is_not_affected_by_other_sessions_write() {
        World w = new World();
        w.service.createOrder("s-writer", order("o-100"));
        RouteDecision decision = w.router.routeRead("s-other");
        assertNotEquals(PRIMARY, decision.target());
        assertNull(decision.minLsn());
    }

    @Test
    void test_all_replicas_lagging_beyond_threshold_fall_back_to_primary() {
        World w = new World();
        w.replica("replica-a").lagSeconds = 0.5;
        w.replica("replica-b").lagSeconds = 0.3;
        w.service.createOrder("s-writer", order("o-100"));
        w.allReplicasCatchUp();
        assertEquals(PRIMARY, w.router.routeRead("s-reader").target());
    }

    @Test
    void test_lag_threshold_is_in_milliseconds() {
        World w = new World();
        w.replica("replica-b").healthy = false;
        w.replica("replica-a").lagSeconds = 0.25;
        assertEquals(PRIMARY, w.router.routeRead("s-reader").target());
        w.replica("replica-a").lagSeconds = 0.15;
        assertEquals("replica-a", w.router.routeRead("s-reader").target());
    }

    @Test
    void test_read_after_write_goes_to_primary_when_no_replica_caught_up() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        RouteDecision decision = w.router.routeRead("s-1");
        assertEquals(PRIMARY, decision.target());
        assertEquals(order("o-100"), w.service.getOrder("s-1", "o-100"));
        assertEquals(1, w.metrics.value("reads.primary"));
    }

    @Test
    void test_read_after_write_returns_the_new_order() {
        World w = new World();
        w.replica("replica-b").lagSeconds = 0.12;
        ApiResponse created = w.api.createOrder("s-1", "o-100", "c-1", 2500);
        assertEquals(201, created.status());
        ApiResponse fetched = w.api.getOrder("s-1", "o-100");
        assertEquals(200, fetched.status());
        assertEquals("o-100", fetched.body().get("order_id"));
    }

    @Test
    void test_read_after_write_from_replica_applied_up_to_previous_position() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        w.replica("replica-a").applyUntil(w.primary.lastCommitLsn - 1);
        w.replica("replica-b").applyUntil(w.primary.lastCommitLsn - 1);
        assertEquals(order("o-100"), w.service.getOrder("s-1", "o-100"));
        assertEquals(1, w.metrics.value("reads.primary"));
    }

    @Test
    void test_pin_uses_commit_lsn() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        SessionPin pin = w.sessions.getPin("s-1");
        assertNotNull(pin);
        assertEquals(w.primary.lastCommitLsn, pin.minLsn());
    }

    @Test
    void test_update_after_create_requires_replica_to_apply_update() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        w.allReplicasCatchUp();
        w.service.updateOrder("s-1", order("o-100", "SHIPPED"));
        Order fetched = w.service.getOrder("s-1", "o-100");
        assertEquals("SHIPPED", fetched.status());
    }

    @Test
    void test_replica_applied_exactly_at_commit_lsn_serves_the_read() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        w.replica("replica-a").applyUntil(w.primary.lastCommitLsn);
        assertEquals(order("o-100"), w.service.getOrder("s-1", "o-100"));
        assertEquals(1, w.metrics.value("reads.replica"));
        assertEquals(0, w.metrics.value("reads.primary"));
    }

    @Test
    void test_router_reports_primary_fallback_in_metrics() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        w.router.routeRead("s-1");
        assertEquals(1, w.metrics.value("route.primary"));
        assertEquals(0, w.metrics.value("route.replica"));
    }

    @Test
    void test_update_pin_uses_update_commit_lsn() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        w.allReplicasCatchUp();
        w.service.updateOrder("s-1", order("o-100", "SHIPPED"));
        SessionPin pin = w.sessions.getPin("s-1");
        assertEquals(w.primary.lastCommitLsn, pin.minLsn());
        assertTrue(pin.minLsn() > w.replica("replica-a").appliedLsn);
    }

    @Test
    void test_single_replica_setup_routes_to_primary_until_applied() {
        World w = new World(RoutingConfig.defaults().withReplicaNames(List.of("replica-a")));
        w.replica("replica-a").lagSeconds = 0.05;
        w.service.createOrder("s-1", order("o-100"));
        assertEquals(PRIMARY, w.router.routeRead("s-1").target());
        w.replica("replica-a").catchUp();
        assertEquals("replica-a", w.router.routeRead("s-1").target());
    }
}
