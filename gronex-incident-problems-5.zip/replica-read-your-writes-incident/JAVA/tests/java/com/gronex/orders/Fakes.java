package com.gronex.orders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Fakes {
    public static final long INITIAL_LSN = 0x5A3000L;
    public static final long WRITE_RECORD_SIZE = 0x80L;
    public static final long COMMIT_RECORD_SIZE = 0x40L;

    private Fakes() {
    }

    public static final class FakeClock implements Clock {
        private double now;

        public FakeClock() {
            this(1_000_000.0);
        }

        public FakeClock(double start) {
            this.now = start;
        }

        @Override
        public double now() {
            return now;
        }

        public void advance(double seconds) {
            now += seconds;
        }
    }

    public record Commit(long commitLsn, Map<String, Order> rows) {
    }

    public static final class FakePrimary implements PrimaryDatabase {
        public long lsn = INITIAL_LSN;
        public long lastCommitLsn = INITIAL_LSN;
        public final List<Commit> commits = new ArrayList<>();
        private Map<String, Order> pending = new HashMap<>();
        private boolean inTransaction = false;

        @Override
        public void begin() {
            inTransaction = true;
            pending = new HashMap<>();
        }

        @Override
        public void insertOrder(Order order) {
            pending.put(order.orderId(), order);
            lsn += WRITE_RECORD_SIZE;
        }

        @Override
        public void updateOrder(Order order) {
            pending.put(order.orderId(), order);
            lsn += WRITE_RECORD_SIZE;
        }

        @Override
        public long currentLsn() {
            return lsn;
        }

        @Override
        public long commit() {
            lsn += COMMIT_RECORD_SIZE;
            lastCommitLsn = lsn;
            commits.add(new Commit(lsn, new HashMap<>(pending)));
            pending = new HashMap<>();
            inTransaction = false;
            return lsn;
        }

        @Override
        public Order getOrder(String orderId) {
            return visibleOrder(commits, lsn, orderId);
        }
    }

    public static Order visibleOrder(List<Commit> commits, long appliedLsn, String orderId) {
        Order found = null;
        for (Commit commit : commits) {
            if (commit.commitLsn() <= appliedLsn && commit.rows().containsKey(orderId)) {
                found = commit.rows().get(orderId);
            }
        }
        return found;
    }

    public static final class FakeReplica implements ReplicaDatabase {
        private final String name;
        private final FakePrimary primary;
        public long appliedLsn;
        public double lagSeconds = 0.01;
        public boolean healthy = true;

        public FakeReplica(String name, FakePrimary primary) {
            this.name = name;
            this.primary = primary;
            this.appliedLsn = primary.lsn;
        }

        @Override
        public String name() {
            return name;
        }

        public void catchUp() {
            appliedLsn = primary.lsn;
        }

        public void applyUntil(long lsn) {
            appliedLsn = lsn;
        }

        public ReplicaStatus status() {
            return new ReplicaStatus(name, appliedLsn, lagSeconds, healthy);
        }

        @Override
        public Order getOrder(String orderId) {
            return visibleOrder(primary.commits, appliedLsn, orderId);
        }
    }

    public static final class FakeMonitor implements ReplicaMonitor {
        private final List<FakeReplica> replicas;

        public FakeMonitor(List<FakeReplica> replicas) {
            this.replicas = replicas;
        }

        @Override
        public List<ReplicaStatus> statuses() {
            List<ReplicaStatus> statuses = new ArrayList<>();
            for (FakeReplica replica : replicas) {
                statuses.add(replica.status());
            }
            return statuses;
        }
    }

    public static final class FakeSessionStore implements SessionStore {
        private final Map<String, SessionPin> pins = new HashMap<>();

        @Override
        public SessionPin getPin(String sessionId) {
            return pins.get(sessionId);
        }

        @Override
        public void setPin(String sessionId, SessionPin pin) {
            pins.put(sessionId, pin);
        }
    }
}
