# Incident Room: Read-Your-Writes Broken by Replica Routing (Java)

You are on call for `orders-api`, the service behind checkout and the order status page. It writes to a primary database and serves most reads from two streaming replicas. At 09:14 UTC today, build `2026.10.30-r2` (change ORD-2210, "LSN-aware read routing") finished rolling out. It replaced the old rule "pin a session to the primary for five seconds after a write" with routing based on replication positions, with the stated goal of taking the remaining primary reads off the primary. At 09:11, three minutes before the deploy, replica-b started lagging because of an autovacuum run and the `replica_lag` alert fired. At 09:17 the `order_not_found_after_create` alert fired: customers finish checkout, get redirected to their order page, and see "Order not found". Others see an order still marked PLACED seconds after a warehouse scan marked it SHIPPED.

The service is still serving traffic. Nobody has rolled back yet.

## What you have

| Path | Contents |
| --- | --- |
| `logs/app.log` | orders-api application log for 09:00-09:35 UTC, including route decisions |
| `logs/db.log` | primary and replica database log for the same window |
| `logs/deploy.log` | rollout controller log for build r2 |
| `metrics/*.csv` | time series for the incident window, 15 s resolution |
| `metrics/dashboard.md` | the same series as text charts with annotations |
| `docs/runbook.md` | the on-call runbook for orders-api |
| `src/main/java/com/gronex/orders/` | the code under test. This is the only place you may change |
| `tests/` | the visible test suite. Do not edit it |

## The three phases

1. **Triage.** Read the logs, metrics, runbook and code. Submit a root cause, the evidence that proves it, and a mitigation that stops the bleeding before the real fix. Tests are locked until you submit.
2. **Recover.** Fix `src/`. Your score is the share of tests passing, visible plus a hidden suite that covers edge cases of the same faults and rejects fixes that only hide the symptom.
3. **Defend.** Explain what you changed, why it is safe, and what you would watch or fix next.

## Project layout

```
src/main/java/com/gronex/orders/
  OrdersApi.java        HTTP-shaped entry point: POST create, GET read, status codes
  ApiResponse.java      record (status, body)
  OrdersService.java    write path (transaction, commit, session pin) and read path
  ReadRouter.java       chooses primary or a replica for a read; PRIMARY constant
  SessionStore.java     SessionStore interface: per-session pin (minLsn, expiresAt)
  ReplicaMonitor.java   ReplicaMonitor interface: per-replica applied LSN, lag, health
  PrimaryDatabase.java  PrimaryDatabase interface (begin, insert, update, currentLsn, commit, get)
  ReplicaDatabase.java  ReplicaDatabase interface (name, get)
  Lsn.java              LSN formatting (X/Y hex) and parsing
  RoutingConfig.java    record (maxReplicaLagMs, readYourWritesWindowS, replicaNames); defaults(), fromMap(), with...()
  Metrics.java          counters
  Clock.java            Clock interface
  Order.java            record (orderId, customerId, totalCents, status)
  ReplicaStatus.java    record (name, appliedLsn, lagSeconds, healthy)
  SessionPin.java       record (minLsn, expiresAt)
  RouteDecision.java    record (target, reason, minLsn nullable)
tests/java/com/gronex/orders/
  Fakes.java            FakeClock, FakePrimary (WAL positions, commits), FakeReplica (applied LSN, lag, health), FakeMonitor, FakeSessionStore
  World.java            wires the service with fakes; order() helper
  OrdersApiTest.java
pom.xml                 Java 17, JUnit 5; tests are read from tests/java
```

Everything is injected: the clock, the databases, the replica monitor, the session store and the config. LSNs are `long` values inside the code and are printed as `X/Y` in logs. There is no network, no sleep and no wall clock in the tests.

## How to run

```
./verify.sh
```

Requires a JDK 17+ and Maven 3.6+ on `PATH`. `verify.sh` runs `mvn test` and prints the surefire summary (`Tests run: ...`) plus any failing test lines. The first run downloads JUnit and the pinned Maven plugins; after that it works offline. Equivalent manual command: `mvn test`.

## Rules

- Change files under `src/` only. Tests, logs, metrics and docs are read-only.
- Keep the service deterministic. No wall clock, sleeps, threads or randomness.
- Counter names used by the tests: `reads.primary`, `reads.replica`, `route.primary`, `route.replica`, `orders.created`, `orders.updated`.
