#pragma once

#include <functional>
#include <iostream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

struct CheckFailure : std::runtime_error {
    using std::runtime_error::runtime_error;
};

using TestFn = std::function<void()>;

std::map<std::string, TestFn>& test_registry();

struct TestRegistrar {
    TestRegistrar(const char* name, TestFn fn) { test_registry()[name] = std::move(fn); }
};

template <typename T, typename = void>
struct check_has_ostream : std::false_type {};

template <typename T>
struct check_has_ostream<T, std::void_t<decltype(std::declval<std::ostream&>() << std::declval<const T&>())>> : std::true_type {};

template <typename T>
std::string check_repr(const T& value) {
    if constexpr (check_has_ostream<T>::value) {
        std::ostringstream out;
        out << value;
        return out.str();
    } else {
        return "<value>";
    }
}

#define TEST_CASE(name) \
    static void name(); \
    static TestRegistrar name##_registrar(#name, name); \
    static void name()

#define CHECK(cond) \
    do { \
        if (!(cond)) { \
            throw CheckFailure(std::string(__FILE__) + ":" + std::to_string(__LINE__) + " CHECK failed: " #cond); \
        } \
    } while (0)

#define CHECK_EQ(a, b) \
    do { \
        const auto check_lhs = (a); \
        const auto check_rhs = (b); \
        if (!(check_lhs == check_rhs)) { \
            throw CheckFailure(std::string(__FILE__) + ":" + std::to_string(__LINE__) + " CHECK_EQ failed: " #a " == " #b \
                               " (" + check_repr(check_lhs) + " vs " + check_repr(check_rhs) + ")"); \
        } \
    } while (0)
