#pragma once

#include <map>
#include <memory>
#include <string>
#include <vector>

#include "api.hpp"
#include "config.hpp"
#include "fakes.hpp"
#include "metrics.hpp"
#include "models.hpp"
#include "orders_service.hpp"
#include "router.hpp"

struct World {
    RoutingConfig config;
    std::shared_ptr<FakeClock> clock;
    std::shared_ptr<FakePrimary> primary;
    std::vector<std::shared_ptr<FakeReplica>> replica_list;
    std::map<std::string, ReplicaDatabase*> replicas;
    std::shared_ptr<FakeMonitor> monitor;
    std::shared_ptr<FakeSessionStore> sessions;
    std::shared_ptr<Metrics> metrics;
    std::shared_ptr<ReadRouter> router;
    std::shared_ptr<OrdersService> service;
    std::shared_ptr<OrdersApi> api;

    explicit World(const RoutingConfig& config_ = RoutingConfig{})
        : config(config_), clock(std::make_shared<FakeClock>()), primary(std::make_shared<FakePrimary>()) {
        std::vector<FakeReplica*> monitored;
        for (const auto& name : config.replica_names) {
            auto replica = std::make_shared<FakeReplica>(name, *primary);
            replica_list.push_back(replica);
            replicas[name] = replica.get();
            monitored.push_back(replica.get());
        }
        monitor = std::make_shared<FakeMonitor>(monitored);
        sessions = std::make_shared<FakeSessionStore>();
        metrics = std::make_shared<Metrics>();
        router = std::make_shared<ReadRouter>(config, *monitor, *sessions, *clock, *metrics);
        service = std::make_shared<OrdersService>(config, *primary, replicas, *router, *sessions, *clock, *metrics);
        api = std::make_shared<OrdersApi>(*service);
    }

    FakeReplica& replica(const std::string& name) {
        for (const auto& candidate : replica_list) {
            if (candidate->name() == name) {
                return *candidate;
            }
        }
        throw std::out_of_range("unknown replica: " + name);
    }

    void all_replicas_catch_up() {
        for (const auto& candidate : replica_list) {
            candidate->catch_up();
        }
    }
};

inline Order order(const std::string& order_id, const std::string& customer_id = "c-1", int total_cents = 2500,
                   const std::string& status = "PLACED") {
    return Order{order_id, customer_id, total_cents, status};
}
