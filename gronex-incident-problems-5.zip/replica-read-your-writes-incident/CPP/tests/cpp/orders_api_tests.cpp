#include <optional>
#include <string>

#include "check.hpp"
#include "config.hpp"
#include "harness.hpp"
#include "router.hpp"

TEST_CASE(test_create_order_returns_201_with_location) {
    World w;
    auto response = w.api->create_order("s-1", "o-100", "c-1", 2500);
    CHECK_EQ(response.status, 201);
    CHECK_EQ(response.body.at("location"), "/v1/orders/o-100");
    CHECK(w.primary->get_order("o-100") == order("o-100"));
}

TEST_CASE(test_read_without_recent_write_goes_to_replica) {
    World w;
    w.service->create_order("s-writer", order("o-100"));
    w.all_replicas_catch_up();
    CHECK(w.service->get_order("s-reader", "o-100") == order("o-100"));
    CHECK_EQ(w.metrics->value("reads.replica"), 1);
    CHECK_EQ(w.metrics->value("reads.primary"), 0);
}

TEST_CASE(test_unhealthy_replica_is_never_chosen) {
    World w;
    w.service->create_order("s-writer", order("o-100"));
    w.all_replicas_catch_up();
    w.replica("replica-a").healthy = false;
    auto decision = w.router->route_read("s-reader");
    CHECK_EQ(decision.target, "replica-b");
}

TEST_CASE(test_all_replicas_unhealthy_falls_back_to_primary) {
    World w;
    w.replica("replica-a").healthy = false;
    w.replica("replica-b").healthy = false;
    w.service->create_order("s-writer", order("o-100"));
    CHECK_EQ(w.router->route_read("s-reader").target, PRIMARY);
    CHECK(w.service->get_order("s-reader", "o-100") == order("o-100"));
    CHECK_EQ(w.metrics->value("reads.primary"), 1);
}

TEST_CASE(test_pin_expires_after_read_your_writes_window) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    w.clock->advance(5);
    auto decision = w.router->route_read("s-1");
    CHECK(decision.target != PRIMARY);
    CHECK(!decision.min_lsn.has_value());
}

TEST_CASE(test_read_within_window_prefers_caught_up_replica_over_primary) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    w.replica("replica-a").catch_up();
    w.replica("replica-b").lag_seconds = 0.15;
    CHECK(w.service->get_order("s-1", "o-100") == order("o-100"));
    CHECK_EQ(w.metrics->value("reads.replica"), 1);
    CHECK_EQ(w.metrics->value("reads.primary"), 0);
}

TEST_CASE(test_session_without_pin_is_not_affected_by_other_sessions_write) {
    World w;
    w.service->create_order("s-writer", order("o-100"));
    auto decision = w.router->route_read("s-other");
    CHECK(decision.target != PRIMARY);
    CHECK(!decision.min_lsn.has_value());
}

TEST_CASE(test_all_replicas_lagging_beyond_threshold_fall_back_to_primary) {
    World w;
    w.replica("replica-a").lag_seconds = 0.5;
    w.replica("replica-b").lag_seconds = 0.3;
    w.service->create_order("s-writer", order("o-100"));
    w.all_replicas_catch_up();
    CHECK_EQ(w.router->route_read("s-reader").target, PRIMARY);
}

TEST_CASE(test_lag_threshold_is_in_milliseconds) {
    World w;
    w.replica("replica-b").healthy = false;
    w.replica("replica-a").lag_seconds = 0.25;
    CHECK_EQ(w.router->route_read("s-reader").target, PRIMARY);
    w.replica("replica-a").lag_seconds = 0.15;
    CHECK_EQ(w.router->route_read("s-reader").target, "replica-a");
}

TEST_CASE(test_read_after_write_goes_to_primary_when_no_replica_caught_up) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    auto decision = w.router->route_read("s-1");
    CHECK_EQ(decision.target, PRIMARY);
    CHECK(w.service->get_order("s-1", "o-100") == order("o-100"));
    CHECK_EQ(w.metrics->value("reads.primary"), 1);
}

TEST_CASE(test_read_after_write_returns_the_new_order) {
    World w;
    w.replica("replica-b").lag_seconds = 0.12;
    auto created = w.api->create_order("s-1", "o-100", "c-1", 2500);
    CHECK_EQ(created.status, 201);
    auto fetched = w.api->get_order("s-1", "o-100");
    CHECK_EQ(fetched.status, 200);
    CHECK_EQ(fetched.body.at("order_id"), "o-100");
}

TEST_CASE(test_read_after_write_from_replica_applied_up_to_previous_position) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    w.replica("replica-a").apply_until(w.primary->last_commit_lsn - 1);
    w.replica("replica-b").apply_until(w.primary->last_commit_lsn - 1);
    CHECK(w.service->get_order("s-1", "o-100") == order("o-100"));
    CHECK_EQ(w.metrics->value("reads.primary"), 1);
}

TEST_CASE(test_pin_uses_commit_lsn) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    auto pin = w.sessions->get_pin("s-1");
    CHECK(pin.has_value());
    CHECK_EQ(pin->min_lsn, w.primary->last_commit_lsn);
}

TEST_CASE(test_update_after_create_requires_replica_to_apply_update) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    w.all_replicas_catch_up();
    w.service->update_order("s-1", order("o-100", "c-1", 2500, "SHIPPED"));
    auto fetched = w.service->get_order("s-1", "o-100");
    CHECK(fetched.has_value());
    CHECK_EQ(fetched->status, "SHIPPED");
}

TEST_CASE(test_replica_applied_exactly_at_commit_lsn_serves_the_read) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    w.replica("replica-a").apply_until(w.primary->last_commit_lsn);
    CHECK(w.service->get_order("s-1", "o-100") == order("o-100"));
    CHECK_EQ(w.metrics->value("reads.replica"), 1);
    CHECK_EQ(w.metrics->value("reads.primary"), 0);
}

TEST_CASE(test_router_reports_primary_fallback_in_metrics) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    w.router->route_read("s-1");
    CHECK_EQ(w.metrics->value("route.primary"), 1);
    CHECK_EQ(w.metrics->value("route.replica"), 0);
}

TEST_CASE(test_update_pin_uses_update_commit_lsn) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    w.all_replicas_catch_up();
    w.service->update_order("s-1", order("o-100", "c-1", 2500, "SHIPPED"));
    auto pin = w.sessions->get_pin("s-1");
    CHECK(pin.has_value());
    CHECK_EQ(pin->min_lsn, w.primary->last_commit_lsn);
    CHECK(pin->min_lsn > w.replica("replica-a").applied_lsn);
}

TEST_CASE(test_single_replica_setup_routes_to_primary_until_applied) {
    RoutingConfig config;
    config.replica_names = {"replica-a"};
    World w(config);
    w.replica("replica-a").lag_seconds = 0.05;
    w.service->create_order("s-1", order("o-100"));
    CHECK_EQ(w.router->route_read("s-1").target, PRIMARY);
    w.replica("replica-a").catch_up();
    CHECK_EQ(w.router->route_read("s-1").target, "replica-a");
}
