#include <cstring>
#include <exception>
#include <iostream>
#include <map>
#include <string>

#include "check.hpp"

std::map<std::string, TestFn>& test_registry() {
    static std::map<std::string, TestFn> registry;
    return registry;
}

namespace {

bool run_one(const std::string& name, const TestFn& fn, std::string& message) {
    try {
        fn();
        return true;
    } catch (const CheckFailure& failure) {
        message = failure.what();
    } catch (const std::exception& error) {
        message = std::string("unexpected exception: ") + error.what();
    } catch (...) {
        message = "unexpected non-standard exception";
    }
    (void)name;
    return false;
}

}

int main(int argc, char** argv) {
    auto& registry = test_registry();
    if (argc > 1 && std::strcmp(argv[1], "--list") == 0) {
        for (const auto& entry : registry) {
            std::cout << entry.first << "\n";
        }
        return 0;
    }
    if (argc > 1) {
        auto it = registry.find(argv[1]);
        if (it == registry.end()) {
            std::cerr << "unknown test: " << argv[1] << "\n";
            return 1;
        }
        std::string message;
        if (run_one(it->first, it->second, message)) {
            std::cout << "PASS: " << it->first << "\n";
            return 0;
        }
        std::cout << "FAIL: " << it->first << "  " << message << "\n";
        return 1;
    }
    int passed = 0;
    int failed = 0;
    for (const auto& entry : registry) {
        std::string message;
        if (run_one(entry.first, entry.second, message)) {
            ++passed;
            std::cout << "PASS: " << entry.first << "\n";
        } else {
            ++failed;
            std::cout << "FAIL: " << entry.first << "  " << message << "\n";
        }
    }
    std::cout << passed << " passed, " << failed << " failed\n";
    return failed == 0 ? 0 : 1;
}
