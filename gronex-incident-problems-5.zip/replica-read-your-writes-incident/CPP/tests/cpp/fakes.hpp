#pragma once

#include <map>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "clock.hpp"
#include "database.hpp"
#include "models.hpp"
#include "replica_monitor.hpp"
#include "session_store.hpp"

constexpr long long INITIAL_LSN = 0x5A3000;
constexpr long long WRITE_RECORD_SIZE = 0x80;
constexpr long long COMMIT_RECORD_SIZE = 0x40;

using CommitRecord = std::pair<long long, std::map<std::string, Order>>;

class FakeClock : public Clock {
public:
    explicit FakeClock(double start = 1000000.0) : now_(start) {}

    double now() override { return now_; }

    void advance(double seconds) { now_ += seconds; }

private:
    double now_;
};

inline std::optional<Order> visible_order(const std::vector<CommitRecord>& commits, long long applied_lsn, const std::string& order_id) {
    std::optional<Order> found;
    for (const auto& commit : commits) {
        if (commit.first <= applied_lsn) {
            auto it = commit.second.find(order_id);
            if (it != commit.second.end()) {
                found = it->second;
            }
        }
    }
    return found;
}

class FakePrimary : public PrimaryDatabase {
public:
    long long lsn = INITIAL_LSN;
    long long last_commit_lsn = INITIAL_LSN;
    std::vector<CommitRecord> commits;

    void begin() override {
        in_transaction_ = true;
        pending_.clear();
    }

    void insert_order(const Order& order) override {
        pending_[order.order_id] = order;
        lsn += WRITE_RECORD_SIZE;
    }

    void update_order(const Order& order) override {
        pending_[order.order_id] = order;
        lsn += WRITE_RECORD_SIZE;
    }

    long long current_lsn() override { return lsn; }

    long long commit() override {
        lsn += COMMIT_RECORD_SIZE;
        last_commit_lsn = lsn;
        commits.emplace_back(lsn, pending_);
        pending_.clear();
        in_transaction_ = false;
        return lsn;
    }

    std::optional<Order> get_order(const std::string& order_id) override { return visible_order(commits, lsn, order_id); }

private:
    std::map<std::string, Order> pending_;
    bool in_transaction_ = false;
};

class FakeReplica : public ReplicaDatabase {
public:
    FakeReplica(const std::string& name, FakePrimary& primary) : name_(name), primary_(primary), applied_lsn(primary.lsn) {}

    long long applied_lsn;
    double lag_seconds = 0.01;
    bool healthy = true;

    std::string name() const override { return name_; }

    void catch_up() { applied_lsn = primary_.lsn; }

    void apply_until(long long lsn) { applied_lsn = lsn; }

    ReplicaStatus status() const { return ReplicaStatus{name_, applied_lsn, lag_seconds, healthy}; }

    std::optional<Order> get_order(const std::string& order_id) override { return visible_order(primary_.commits, applied_lsn, order_id); }

private:
    std::string name_;
    FakePrimary& primary_;
};

class FakeMonitor : public ReplicaMonitor {
public:
    explicit FakeMonitor(std::vector<FakeReplica*> replicas) : replicas_(std::move(replicas)) {}

    std::vector<ReplicaStatus> statuses() override {
        std::vector<ReplicaStatus> result;
        for (const auto* replica : replicas_) {
            result.push_back(replica->status());
        }
        return result;
    }

private:
    std::vector<FakeReplica*> replicas_;
};

class FakeSessionStore : public SessionStore {
public:
    std::optional<SessionPin> get_pin(const std::string& session_id) override {
        auto it = pins_.find(session_id);
        if (it == pins_.end()) {
            return std::nullopt;
        }
        return it->second;
    }

    void set_pin(const std::string& session_id, const SessionPin& pin) override { pins_[session_id] = pin; }

private:
    std::map<std::string, SessionPin> pins_;
};
