# orders-api dashboard, 2026-10-30 09:00-09:35 UTC

Text rendering of `traffic.csv` and `routing.csv` (15 s resolution; charts sample every 30 s, one character per sample).

Markers under each chart: `L` replica-b lag begins 09:11:05, `!` alert fired (09:11:40 replica_lag, 09:17:20 order_not_found_after_create), `▲` deploy r2 started 09:14:02, `△` rollout complete 09:16:30, `l` replica-b lag ends 09:29:04.

## Timeline

| Time (UTC) | Event |
| --- | --- |
| 09:11:05 | replica-b: replay paused by a conflicting analytics query; lag climbs in a sawtooth between 0.8 s and 2.5 s |
| 09:11:40 | ALERT replica_lag replica-b above 1.0 s |
| 09:14:02 | deploy 2026.10.30-r2 (ORD-2210, LSN-aware read routing) starts, pod 1 of 6 |
| 09:16:30 | rollout complete, 6 of 6 pods on r2 |
| 09:17:20 | ALERT order_not_found_after_create above 0.010 |
| 09:29:04 | analytics query on replica-b finishes; lag back to 20 ms |
| 09:30:04 | replica_lag alert resolved |

## Panels

### Read request rate (GET /v1/orders/{id}, req/s)

```
max 186.9
▅▅▅▇▅▇▇▇▅▇█▇▅█▆▅█▇▅▆▆▇▅▅▆▃▄▃▂▃▂▄▁▂▁▃▁▄▁▁▄▄▄▄▁▅▅▂▅▄▆▅▄▄▅▅█▇▆▆▆▆█▇█▅▇█▆▆▇
                      L!    ▲    △ !                      l            
09:00                         09:17:30                       09:35
min 173.2
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 181.8 |
| 09:12:00 replica-b lagging, pre-deploy | 182.0 |
| 09:16:30 rollout complete | 175.1 |
| 09:17:15 404 alert | 175.5 |
| 09:25:00 mid-incident | 182.1 |
| 09:31:00 replica-b recovered | 186.8 |
| 09:35:00 end | 184.9 |

### Write rate (POST/PUT, req/s)

```
max 15.1
▄▆▆▅▇▇▅█▄█▇█▆█▄▅▅▄▅▆▅▄▁▄▁▃▂▂▁▁▂▂▂▁▁▃▂▃▁▃▅▄▆▃▄▅▆▇▄▆▇▆▅▆██▅▄▆▅▇▆▅▃▅▃▃▄▁▃▃
                      L!    ▲    △ !                      l            
09:00                         09:17:30                       09:35
min 13.2
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 14.3 |
| 09:12:00 replica-b lagging, pre-deploy | 13.2 |
| 09:16:30 rollout complete | 13.2 |
| 09:17:15 404 alert | 13.7 |
| 09:25:00 mid-incident | 14.8 |
| 09:31:00 replica-b recovered | 14.2 |
| 09:35:00 end | 13.7 |

### Order not found within 2 s of create (ratio of creates)

```
max 0.0598
▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▂▃▄▅██▇██▇▇█▇██▇▇█▇██▇██▇██▇██▂▂▂▂▂▂▂▂▂▂▂▂
                      L!    ▲    △ !                      l            
09:00                         09:17:30                       09:35
min 0.0000
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 0.0002 |
| 09:12:00 replica-b lagging, pre-deploy | 0.0001 |
| 09:16:30 rollout complete | 0.0533 |
| 09:17:15 404 alert | 0.0434 |
| 09:25:00 mid-incident | 0.0468 |
| 09:31:00 replica-b recovered | 0.0117 |
| 09:35:00 end | 0.0112 |

### Share of reads routed to the primary (0-1)

```
max 0.126
█████████████████████████████▇▅▄▃▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁
                      L!    ▲    △ !                      l            
09:00                         09:17:30                       09:35
min 0.003
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 0.122 |
| 09:12:00 replica-b lagging, pre-deploy | 0.115 |
| 09:16:30 rollout complete | 0.003 |
| 09:17:15 404 alert | 0.003 |
| 09:25:00 mid-incident | 0.003 |
| 09:31:00 replica-b recovered | 0.003 |
| 09:35:00 end | 0.003 |

### replica-a replication lag (s)

```
max 0.03
▇▃█▃▇▇▁▃▁▂▃▂█▁▅█▇█▂█▆▃▃▇▁▄▆▆▂▃▃▅▆▂▇▄▃▁▄▅▃▆█▇▂▃▅█▃▃▅█▄▅▁▁▇▆▃▄▃▃▃▅▅▃▇▁▅█▃
                      L!    ▲    △ !                      l            
09:00                         09:17:30                       09:35
min 0.01
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 0.02 |
| 09:12:00 replica-b lagging, pre-deploy | 0.02 |
| 09:16:30 rollout complete | 0.02 |
| 09:17:15 404 alert | 0.02 |
| 09:25:00 mid-incident | 0.02 |
| 09:31:00 replica-b recovered | 0.02 |
| 09:35:00 end | 0.02 |

### replica-b replication lag (s)

```
max 2.44
▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▅▇█▅▇█▅▇█▅▆█▅▇█▅▇█▅▇█▅▇█▅▇█▅▇█▅▆█▅▆█▁▁▁▁▁▁▁▁▁▁▁▁
                      L!    ▲    △ !                      l            
09:00                         09:17:30                       09:35
min 0.02
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 0.02 |
| 09:12:00 replica-b lagging, pre-deploy | 1.86 |
| 09:16:30 rollout complete | 1.83 |
| 09:17:15 404 alert | 1.00 |
| 09:25:00 mid-incident | 1.24 |
| 09:31:00 replica-b recovered | 0.02 |
| 09:35:00 end | 0.02 |

### Primary CPU (%)

```
max 43.8
▇▇▇▇▇█▇▇██████████████▇▇██▇▇▇▆▆▄▄▂▂▁▂▁▂▂▂▁▁▁▁▁▁▁▁▁▁▂▁▁▁▁▂▁▂▂▂▂▂▂▃▂▃▃▂▃▃
                      L!    ▲    △ !                      l            
09:00                         09:17:30                       09:35
min 30.2
```

| Checkpoint | Value |
| --- | --- |
| 09:10:00 baseline | 42.8 |
| 09:12:00 replica-b lagging, pre-deploy | 42.3 |
| 09:16:30 rollout complete | 32.5 |
| 09:17:15 404 alert | 32.6 |
| 09:25:00 mid-incident | 30.2 |
| 09:31:00 replica-b recovered | 32.3 |
| 09:35:00 end | 34.9 |

## Panel notes

- Read and write rates are flat for the whole window.
- replica-b lag started three minutes before the deploy and ended at 09:29:04. Before the deploy it produced no not-found errors.
- The share of reads served by the primary falls from about 12 percent to about 0.3 percent as the r2 pods come up, and stays there. Primary CPU drops by 8 points at the same time.
- Not-found-after-create begins with the first r2 pod and tracks the replica-b sawtooth while it lasts. After replica-b recovers at 09:29 the ratio drops but does not return to zero; it settles near 1.2 percent, which is the replica-a race.
- 5xx ratio is zero throughout. The monitor timeouts in app.log are handled.
