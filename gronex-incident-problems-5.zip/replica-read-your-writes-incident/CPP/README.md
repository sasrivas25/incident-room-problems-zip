# Incident Room: Read-Your-Writes Broken by Replica Routing (C++)

You are on call for `orders-api`, the service behind checkout and the order status page. It writes to a primary database and serves most reads from two streaming replicas. At 09:14 UTC today, build `2026.10.30-r2` (change ORD-2210, "LSN-aware read routing") finished rolling out. It replaced the old rule "pin a session to the primary for five seconds after a write" with routing based on replication positions, with the stated goal of taking the remaining primary reads off the primary. At 09:11, three minutes before the deploy, replica-b started lagging because of an autovacuum run and the `replica_lag` alert fired. At 09:17 the `order_not_found_after_create` alert fired: customers finish checkout, get redirected to their order page, and see "Order not found". Others see an order still marked PLACED seconds after a warehouse scan marked it SHIPPED.

The service is still serving traffic. Nobody has rolled back yet.

## What you have

| Path | Contents |
| --- | --- |
| `logs/app.log` | orders-api application log for 09:00-09:35 UTC, including route decisions |
| `logs/db.log` | primary and replica database log for the same window |
| `logs/deploy.log` | rollout controller log for build r2 |
| `metrics/*.csv` | time series for the incident window, 15 s resolution |
| `metrics/dashboard.md` | the same series as text charts with annotations |
| `docs/runbook.md` | the on-call runbook for orders-api |
| `src/` | the code under test. This is the only place you may change |
| `tests/` | the visible test suite. Do not edit it |

## The three phases

1. **Triage.** Read the logs, metrics, runbook and code. Submit a root cause, the evidence that proves it, and a mitigation that stops the bleeding before the real fix. Tests are locked until you submit.
2. **Recover.** Fix `src/`. Your score is the share of tests passing, visible plus a hidden suite that covers edge cases of the same faults and rejects fixes that only hide the symptom.
3. **Defend.** Explain what you changed, why it is safe, and what you would watch or fix next.

## Project layout

```
src/
  api.hpp/.cpp              HTTP-shaped entry point: POST create, GET read, status codes
  orders_service.hpp/.cpp   write path (transaction, commit, session pin) and read path
  router.hpp/.cpp           chooses primary or a replica for a read
  session_store.hpp         SessionStore interface: per-session pin (min_lsn, expires_at)
  replica_monitor.hpp       ReplicaMonitor interface: per-replica applied LSN, lag, health
  database.hpp              PrimaryDatabase and ReplicaDatabase interfaces
  lsn.hpp/.cpp              LSN formatting (X/Y hex) and parsing
  config.hpp/.cpp           RoutingConfig (max_replica_lag_ms, read_your_writes_window_s, replica names)
  metrics.hpp               counters
  clock.hpp                 Clock interface
  models.hpp                Order, ReplicaStatus, SessionPin, RouteDecision
tests/cpp/
  check.hpp                 tiny self-registering test framework (TEST_CASE, CHECK, CHECK_EQ)
  test_main.cpp             test runner (--list, <name>, or all)
  fakes.hpp                 FakeClock, FakePrimary (WAL positions, commits), FakeReplica (applied LSN, lag, health), FakeMonitor, FakeSessionStore
  harness.hpp               World: wires the service with fakes; order() helper
  orders_api_tests.cpp
CMakeLists.txt              builds one executable, incident_tests, and registers one CTest test per TEST_CASE
```

Everything is injected: the clock, the databases, the replica monitor, the session store and the config. LSNs are integers inside the code and are printed as `X/Y` in logs. There is no network, no sleep and no wall clock in the tests.

## How to run

```
./verify.sh
```

Requires CMake 3.15+ and a C++17 compiler (clang or gcc). No external dependencies. `verify.sh` configures into `build/`, builds `incident_tests` and runs `ctest`. To run a single test by name: `./build/incident_tests test_pin_uses_commit_lsn`; `./build/incident_tests --list` prints every test name.

## Rules

- Change files under `src/` only. Tests, logs, metrics and docs are read-only.
- Keep the service deterministic. No wall clock, sleeps, threads or randomness.
- Counter names used by the tests: `reads.primary`, `reads.replica`, `route.primary`, `route.replica`, `orders.created`, `orders.updated`.
