#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "=============================================="
echo " Gronex verify — Read-Your-Writes Broken by Replica Routing (Node.js)"
echo "=============================================="

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: node not found. Install Node.js 18 or newer, then re-run ./verify.sh"
  exit 2
fi

NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "ERROR: Node.js $(node --version) is too old. Node.js 18 or newer is required."
  exit 2
fi

set +e
if [ -d tests_hidden ]; then
  node --test tests tests_hidden
else
  node --test tests
fi
STATUS=$?
set -e

echo "----------------------------------------------"
if [ "$STATUS" -eq 0 ]; then
  echo "✅ PASS — all checks green. Your solution is correct."
else
  echo "❌ FAIL — some checks did not pass. Keep going!"
  echo "   Read the failures above; fix src/, then run ./verify.sh again."
fi
exit "$STATUS"
