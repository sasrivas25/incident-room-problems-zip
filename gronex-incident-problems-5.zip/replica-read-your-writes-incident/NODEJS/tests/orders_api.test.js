'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { routingConfig } = require('../src/config');
const { PRIMARY } = require('../src/router');

const { World, order } = require('./harness');

test('test_create_order_returns_201_with_location', () => {
  const w = new World();
  const response = w.api.createOrder('s-1', 'o-100', 'c-1', 2500);
  assert.equal(response.status, 201);
  assert.equal(response.body.location, '/v1/orders/o-100');
  assert.deepEqual(w.primary.getOrder('o-100'), order('o-100'));
});

test('test_read_without_recent_write_goes_to_replica', () => {
  const w = new World();
  w.service.createOrder('s-writer', order('o-100'));
  w.allReplicasCatchUp();
  assert.deepEqual(w.service.getOrder('s-reader', 'o-100'), order('o-100'));
  assert.equal(w.metrics.value('reads.replica'), 1);
  assert.equal(w.metrics.value('reads.primary'), 0);
});

test('test_unhealthy_replica_is_never_chosen', () => {
  const w = new World();
  w.service.createOrder('s-writer', order('o-100'));
  w.allReplicasCatchUp();
  w.replica('replica-a').healthy = false;
  const decision = w.router.routeRead('s-reader');
  assert.equal(decision.target, 'replica-b');
});

test('test_all_replicas_unhealthy_falls_back_to_primary', () => {
  const w = new World();
  w.replica('replica-a').healthy = false;
  w.replica('replica-b').healthy = false;
  w.service.createOrder('s-writer', order('o-100'));
  assert.equal(w.router.routeRead('s-reader').target, PRIMARY);
  assert.deepEqual(w.service.getOrder('s-reader', 'o-100'), order('o-100'));
  assert.equal(w.metrics.value('reads.primary'), 1);
});

test('test_pin_expires_after_read_your_writes_window', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  w.clock.advance(5);
  const decision = w.router.routeRead('s-1');
  assert.notEqual(decision.target, PRIMARY);
  assert.equal(decision.minLsn, null);
});

test('test_read_within_window_prefers_caught_up_replica_over_primary', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  w.replica('replica-a').catchUp();
  w.replica('replica-b').lagSeconds = 0.15;
  assert.deepEqual(w.service.getOrder('s-1', 'o-100'), order('o-100'));
  assert.equal(w.metrics.value('reads.replica'), 1);
  assert.equal(w.metrics.value('reads.primary'), 0);
});

test('test_session_without_pin_is_not_affected_by_other_sessions_write', () => {
  const w = new World();
  w.service.createOrder('s-writer', order('o-100'));
  const decision = w.router.routeRead('s-other');
  assert.notEqual(decision.target, PRIMARY);
  assert.equal(decision.minLsn, null);
});

test('test_all_replicas_lagging_beyond_threshold_fall_back_to_primary', () => {
  const w = new World();
  w.replica('replica-a').lagSeconds = 0.5;
  w.replica('replica-b').lagSeconds = 0.3;
  w.service.createOrder('s-writer', order('o-100'));
  w.allReplicasCatchUp();
  assert.equal(w.router.routeRead('s-reader').target, PRIMARY);
});

test('test_lag_threshold_is_in_milliseconds', () => {
  const w = new World();
  w.replica('replica-b').healthy = false;
  w.replica('replica-a').lagSeconds = 0.25;
  assert.equal(w.router.routeRead('s-reader').target, PRIMARY);
  w.replica('replica-a').lagSeconds = 0.15;
  assert.equal(w.router.routeRead('s-reader').target, 'replica-a');
});

test('test_read_after_write_goes_to_primary_when_no_replica_caught_up', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  const decision = w.router.routeRead('s-1');
  assert.equal(decision.target, PRIMARY);
  assert.deepEqual(w.service.getOrder('s-1', 'o-100'), order('o-100'));
  assert.equal(w.metrics.value('reads.primary'), 1);
});

test('test_read_after_write_returns_the_new_order', () => {
  const w = new World();
  w.replica('replica-b').lagSeconds = 0.12;
  const created = w.api.createOrder('s-1', 'o-100', 'c-1', 2500);
  assert.equal(created.status, 201);
  const fetched = w.api.getOrder('s-1', 'o-100');
  assert.equal(fetched.status, 200);
  assert.equal(fetched.body.order_id, 'o-100');
});

test('test_read_after_write_from_replica_applied_up_to_previous_position', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  w.replica('replica-a').applyUntil(w.primary.lastCommitLsn - 1);
  w.replica('replica-b').applyUntil(w.primary.lastCommitLsn - 1);
  assert.deepEqual(w.service.getOrder('s-1', 'o-100'), order('o-100'));
  assert.equal(w.metrics.value('reads.primary'), 1);
});

test('test_pin_uses_commit_lsn', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  const pin = w.sessions.getPin('s-1');
  assert.notEqual(pin, null);
  assert.equal(pin.minLsn, w.primary.lastCommitLsn);
});

test('test_update_after_create_requires_replica_to_apply_update', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  w.allReplicasCatchUp();
  w.service.updateOrder('s-1', order('o-100', 'c-1', 2500, 'SHIPPED'));
  const fetched = w.service.getOrder('s-1', 'o-100');
  assert.equal(fetched.status, 'SHIPPED');
});

test('test_replica_applied_exactly_at_commit_lsn_serves_the_read', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  w.replica('replica-a').applyUntil(w.primary.lastCommitLsn);
  assert.deepEqual(w.service.getOrder('s-1', 'o-100'), order('o-100'));
  assert.equal(w.metrics.value('reads.replica'), 1);
  assert.equal(w.metrics.value('reads.primary'), 0);
});

test('test_router_reports_primary_fallback_in_metrics', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  w.router.routeRead('s-1');
  assert.equal(w.metrics.value('route.primary'), 1);
  assert.equal(w.metrics.value('route.replica'), 0);
});

test('test_update_pin_uses_update_commit_lsn', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  w.allReplicasCatchUp();
  w.service.updateOrder('s-1', order('o-100', 'c-1', 2500, 'SHIPPED'));
  const pin = w.sessions.getPin('s-1');
  assert.equal(pin.minLsn, w.primary.lastCommitLsn);
  assert.ok(pin.minLsn > w.replica('replica-a').appliedLsn);
});

test('test_single_replica_setup_routes_to_primary_until_applied', () => {
  const w = new World(routingConfig({ replicaNames: ['replica-a'] }));
  w.replica('replica-a').lagSeconds = 0.05;
  w.service.createOrder('s-1', order('o-100'));
  assert.equal(w.router.routeRead('s-1').target, PRIMARY);
  w.replica('replica-a').catchUp();
  assert.equal(w.router.routeRead('s-1').target, 'replica-a');
});
