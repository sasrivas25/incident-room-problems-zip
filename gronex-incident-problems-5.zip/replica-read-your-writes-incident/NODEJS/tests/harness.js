'use strict';

const { OrdersApi } = require('../src/api');
const { routingConfig } = require('../src/config');
const { Metrics } = require('../src/metrics');
const { makeOrder } = require('../src/models');
const { OrdersService } = require('../src/orders_service');
const { ReadRouter } = require('../src/router');

const { FakeClock, FakeMonitor, FakePrimary, FakeReplica, FakeSessionStore } = require('./fakes');

class World {
  constructor(config = null) {
    this.config = config ?? routingConfig();
    this.clock = new FakeClock();
    this.primary = new FakePrimary();
    this.replicas = new Map(this.config.replicaNames.map((name) => [name, new FakeReplica(name, this.primary)]));
    this.monitor = new FakeMonitor([...this.replicas.values()]);
    this.sessions = new FakeSessionStore();
    this.metrics = new Metrics();
    this.router = new ReadRouter(this.config, this.monitor, this.sessions, this.clock, this.metrics);
    this.service = new OrdersService(this.config, this.primary, this.replicas, this.router, this.sessions, this.clock, this.metrics);
    this.api = new OrdersApi(this.service);
  }

  replica(name) {
    return this.replicas.get(name);
  }

  allReplicasCatchUp() {
    for (const replica of this.replicas.values()) {
      replica.catchUp();
    }
  }
}

function order(orderId, customerId = 'c-1', totalCents = 2500, status = 'PLACED') {
  return makeOrder(orderId, customerId, totalCents, status);
}

module.exports = { World, order };
