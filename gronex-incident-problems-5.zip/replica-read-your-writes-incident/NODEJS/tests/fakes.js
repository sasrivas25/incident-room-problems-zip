'use strict';

const { Clock } = require('../src/clock');
const { PrimaryDatabase, ReplicaDatabase } = require('../src/database');
const { makeReplicaStatus } = require('../src/models');
const { ReplicaMonitor } = require('../src/replica_monitor');
const { SessionStore } = require('../src/session_store');

const INITIAL_LSN = 0x5a3000;
const WRITE_RECORD_SIZE = 0x80;
const COMMIT_RECORD_SIZE = 0x40;

class FakeClock extends Clock {
  constructor(start = 1000000) {
    super();
    this._now = start;
  }

  now() {
    return this._now;
  }

  advance(seconds) {
    this._now += seconds;
  }
}

class FakePrimary extends PrimaryDatabase {
  constructor() {
    super();
    this.lsn = INITIAL_LSN;
    this.lastCommitLsn = INITIAL_LSN;
    this.commits = [];
    this._pending = new Map();
    this._inTransaction = false;
  }

  begin() {
    this._inTransaction = true;
    this._pending = new Map();
  }

  insertOrder(order) {
    this._pending.set(order.orderId, order);
    this.lsn += WRITE_RECORD_SIZE;
  }

  updateOrder(order) {
    this._pending.set(order.orderId, order);
    this.lsn += WRITE_RECORD_SIZE;
  }

  currentLsn() {
    return this.lsn;
  }

  commit() {
    this.lsn += COMMIT_RECORD_SIZE;
    this.lastCommitLsn = this.lsn;
    this.commits.push([this.lsn, new Map(this._pending)]);
    this._pending = new Map();
    this._inTransaction = false;
    return this.lsn;
  }

  getOrder(orderId) {
    return visibleOrder(this.commits, this.lsn, orderId);
  }
}

function visibleOrder(commits, appliedLsn, orderId) {
  let found = null;
  for (const [commitLsn, rows] of commits) {
    if (commitLsn <= appliedLsn && rows.has(orderId)) {
      found = rows.get(orderId);
    }
  }
  return found;
}

class FakeReplica extends ReplicaDatabase {
  constructor(name, primary) {
    super();
    this._name = name;
    this._primary = primary;
    this.appliedLsn = primary.lsn;
    this.lagSeconds = 0.01;
    this.healthy = true;
  }

  name() {
    return this._name;
  }

  catchUp() {
    this.appliedLsn = this._primary.lsn;
  }

  applyUntil(lsn) {
    this.appliedLsn = lsn;
  }

  status() {
    return makeReplicaStatus(this._name, this.appliedLsn, this.lagSeconds, this.healthy);
  }

  getOrder(orderId) {
    return visibleOrder(this._primary.commits, this.appliedLsn, orderId);
  }
}

class FakeMonitor extends ReplicaMonitor {
  constructor(replicas) {
    super();
    this._replicas = replicas;
  }

  statuses() {
    return this._replicas.map((replica) => replica.status());
  }
}

class FakeSessionStore extends SessionStore {
  constructor() {
    super();
    this._pins = new Map();
  }

  getPin(sessionId) {
    return this._pins.get(sessionId) ?? null;
  }

  setPin(sessionId, pin) {
    this._pins.set(sessionId, pin);
  }
}

module.exports = {
  INITIAL_LSN,
  WRITE_RECORD_SIZE,
  COMMIT_RECORD_SIZE,
  FakeClock,
  FakePrimary,
  visibleOrder,
  FakeReplica,
  FakeMonitor,
  FakeSessionStore,
};
