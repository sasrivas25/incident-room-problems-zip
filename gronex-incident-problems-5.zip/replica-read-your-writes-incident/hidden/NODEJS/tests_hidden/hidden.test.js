'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { configFromDict, routingConfig } = require('../src/config');
const { PRIMARY } = require('../src/router');

const { World, order } = require('../tests/harness');

test('test_hidden_caught_up_replica_after_update_serves_the_read', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  w.allReplicasCatchUp();
  w.service.updateOrder('s-1', order('o-100', 'c-1', 2500, 'SHIPPED'));
  w.replica('replica-b').applyUntil(w.primary.lastCommitLsn);
  const fetched = w.service.getOrder('s-1', 'o-100');
  assert.equal(fetched.status, 'SHIPPED');
  assert.equal(w.metrics.value('reads.replica'), 1);
  assert.equal(w.metrics.value('reads.primary'), 0);
});

test('test_hidden_lag_just_above_threshold_is_excluded', () => {
  const w = new World(routingConfig({ maxReplicaLagMs: 250 }));
  w.replica('replica-b').healthy = false;
  w.replica('replica-a').lagSeconds = 0.251;
  assert.equal(w.router.routeRead('s-reader').target, PRIMARY);
  w.replica('replica-a').lagSeconds = 0.25;
  assert.equal(w.router.routeRead('s-reader').target, 'replica-a');
});

test('test_hidden_unhealthy_caught_up_replica_is_not_used_within_window', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  w.replica('replica-a').catchUp();
  w.replica('replica-a').healthy = false;
  assert.equal(w.router.routeRead('s-1').target, PRIMARY);
  assert.deepEqual(w.service.getOrder('s-1', 'o-100'), order('o-100'));
});

test('test_hidden_second_write_moves_pin_forward', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  w.allReplicasCatchUp();
  w.service.updateOrder('s-1', order('o-100', 'c-1', 2500, 'SHIPPED'));
  assert.equal(w.router.routeRead('s-1').target, PRIMARY);
  w.allReplicasCatchUp();
  assert.notEqual(w.router.routeRead('s-1').target, PRIMARY);
  assert.equal(w.service.getOrder('s-1', 'o-100').status, 'SHIPPED');
});

test('test_hidden_other_session_reads_replica_while_writer_is_pinned', () => {
  const w = new World();
  w.service.createOrder('s-writer', order('o-100'));
  assert.equal(w.router.routeRead('s-writer').target, PRIMARY);
  assert.notEqual(w.router.routeRead('s-other').target, PRIMARY);
});

test('test_hidden_api_read_after_write_returns_200_under_replica_lag', () => {
  const w = new World();
  w.replica('replica-b').lagSeconds = 1.8;
  w.api.createOrder('s-1', 'o-100', 'c-1', 2500);
  const response = w.api.getOrder('s-1', 'o-100');
  assert.equal(response.status, 200);
  assert.equal(response.body.status, 'PLACED');
});

test('test_hidden_no_primary_read_when_a_replica_has_the_commit', () => {
  const w = new World();
  w.replica('replica-a').healthy = false;
  w.service.createOrder('s-1', order('o-100'));
  w.replica('replica-b').applyUntil(w.primary.lastCommitLsn);
  assert.deepEqual(w.service.getOrder('s-1', 'o-100'), order('o-100'));
  assert.equal(w.metrics.value('reads.replica'), 1);
  assert.equal(w.metrics.value('reads.primary'), 0);
});

test('test_hidden_lag_threshold_from_config_dict', () => {
  const w = new World(configFromDict({ max_replica_lag_ms: 100 }));
  w.replica('replica-b').healthy = false;
  w.replica('replica-a').lagSeconds = 0.15;
  assert.equal(w.router.routeRead('s-reader').target, PRIMARY);
});

test('test_hidden_only_caught_up_replica_beyond_lag_threshold_is_not_used', () => {
  const w = new World(routingConfig({ replicaNames: ['replica-a', 'replica-b', 'replica-c'] }));
  w.service.createOrder('s-1', order('o-100'));
  w.replica('replica-c').catchUp();
  w.replica('replica-c').lagSeconds = 0.3;
  const decision = w.router.routeRead('s-1');
  assert.equal(decision.target, PRIMARY);
});

test('test_hidden_route_decision_carries_commit_lsn', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  const decision = w.router.routeRead('s-1');
  assert.equal(decision.minLsn, w.primary.lastCommitLsn);
});

test('test_hidden_update_under_lag_reads_updated_status', () => {
  const w = new World();
  w.replica('replica-a').lagSeconds = 0.12;
  w.replica('replica-b').lagSeconds = 0.9;
  w.api.createOrder('s-1', 'o-100', 'c-1', 2500);
  w.allReplicasCatchUp();
  w.service.updateOrder('s-1', order('o-100', 'c-1', 2500, 'SHIPPED'));
  const response = w.api.getOrder('s-1', 'o-100');
  assert.equal(response.status, 200);
  assert.equal(response.body.status, 'SHIPPED');
});

test('test_hidden_pin_min_lsn_increases_across_writes', () => {
  const w = new World();
  w.service.createOrder('s-1', order('o-100'));
  const first = w.sessions.getPin('s-1').minLsn;
  assert.equal(first, w.primary.lastCommitLsn);
  w.service.createOrder('s-1', order('o-101'));
  const second = w.sessions.getPin('s-1').minLsn;
  assert.equal(second, w.primary.lastCommitLsn);
  assert.ok(second > first);
});
