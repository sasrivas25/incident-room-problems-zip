package com.gronex.orders;

import static com.gronex.orders.ReadRouter.PRIMARY;
import static com.gronex.orders.World.order;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

class HiddenIncidentTest {

    @Test
    void test_hidden_caught_up_replica_after_update_serves_the_read() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        w.allReplicasCatchUp();
        w.service.updateOrder("s-1", order("o-100", "SHIPPED"));
        w.replica("replica-b").applyUntil(w.primary.lastCommitLsn);
        Order fetched = w.service.getOrder("s-1", "o-100");
        assertEquals("SHIPPED", fetched.status());
        assertEquals(1, w.metrics.value("reads.replica"));
        assertEquals(0, w.metrics.value("reads.primary"));
    }

    @Test
    void test_hidden_lag_just_above_threshold_is_excluded() {
        World w = new World(RoutingConfig.defaults().withMaxReplicaLagMs(250));
        w.replica("replica-b").healthy = false;
        w.replica("replica-a").lagSeconds = 0.251;
        assertEquals(PRIMARY, w.router.routeRead("s-reader").target());
        w.replica("replica-a").lagSeconds = 0.25;
        assertEquals("replica-a", w.router.routeRead("s-reader").target());
    }

    @Test
    void test_hidden_unhealthy_caught_up_replica_is_not_used_within_window() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        w.replica("replica-a").catchUp();
        w.replica("replica-a").healthy = false;
        assertEquals(PRIMARY, w.router.routeRead("s-1").target());
        assertEquals(order("o-100"), w.service.getOrder("s-1", "o-100"));
    }

    @Test
    void test_hidden_second_write_moves_pin_forward() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        w.allReplicasCatchUp();
        w.service.updateOrder("s-1", order("o-100", "SHIPPED"));
        assertEquals(PRIMARY, w.router.routeRead("s-1").target());
        w.allReplicasCatchUp();
        assertNotEquals(PRIMARY, w.router.routeRead("s-1").target());
        assertEquals("SHIPPED", w.service.getOrder("s-1", "o-100").status());
    }

    @Test
    void test_hidden_other_session_reads_replica_while_writer_is_pinned() {
        World w = new World();
        w.service.createOrder("s-writer", order("o-100"));
        assertEquals(PRIMARY, w.router.routeRead("s-writer").target());
        assertNotEquals(PRIMARY, w.router.routeRead("s-other").target());
    }

    @Test
    void test_hidden_api_read_after_write_returns_200_under_replica_lag() {
        World w = new World();
        w.replica("replica-b").lagSeconds = 1.8;
        w.api.createOrder("s-1", "o-100", "c-1", 2500);
        ApiResponse response = w.api.getOrder("s-1", "o-100");
        assertEquals(200, response.status());
        assertEquals("PLACED", response.body().get("status"));
    }

    @Test
    void test_hidden_no_primary_read_when_a_replica_has_the_commit() {
        World w = new World();
        w.replica("replica-a").healthy = false;
        w.service.createOrder("s-1", order("o-100"));
        w.replica("replica-b").applyUntil(w.primary.lastCommitLsn);
        assertEquals(order("o-100"), w.service.getOrder("s-1", "o-100"));
        assertEquals(1, w.metrics.value("reads.replica"));
        assertEquals(0, w.metrics.value("reads.primary"));
    }

    @Test
    void test_hidden_lag_threshold_from_config_dict() {
        World w = new World(RoutingConfig.fromMap(Map.of("max_replica_lag_ms", 100)));
        w.replica("replica-b").healthy = false;
        w.replica("replica-a").lagSeconds = 0.15;
        assertEquals(PRIMARY, w.router.routeRead("s-reader").target());
    }

    @Test
    void test_hidden_only_caught_up_replica_beyond_lag_threshold_is_not_used() {
        World w = new World(RoutingConfig.defaults().withReplicaNames(List.of("replica-a", "replica-b", "replica-c")));
        w.service.createOrder("s-1", order("o-100"));
        w.replica("replica-c").catchUp();
        w.replica("replica-c").lagSeconds = 0.3;
        RouteDecision decision = w.router.routeRead("s-1");
        assertEquals(PRIMARY, decision.target());
    }

    @Test
    void test_hidden_route_decision_carries_commit_lsn() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        RouteDecision decision = w.router.routeRead("s-1");
        assertEquals(w.primary.lastCommitLsn, decision.minLsn());
    }

    @Test
    void test_hidden_update_under_lag_reads_updated_status() {
        World w = new World();
        w.replica("replica-a").lagSeconds = 0.12;
        w.replica("replica-b").lagSeconds = 0.9;
        w.api.createOrder("s-1", "o-100", "c-1", 2500);
        w.allReplicasCatchUp();
        w.service.updateOrder("s-1", order("o-100", "SHIPPED"));
        ApiResponse response = w.api.getOrder("s-1", "o-100");
        assertEquals(200, response.status());
        assertEquals("SHIPPED", response.body().get("status"));
    }

    @Test
    void test_hidden_pin_min_lsn_increases_across_writes() {
        World w = new World();
        w.service.createOrder("s-1", order("o-100"));
        long first = w.sessions.getPin("s-1").minLsn();
        assertEquals(w.primary.lastCommitLsn, first);
        w.service.createOrder("s-1", order("o-101"));
        long second = w.sessions.getPin("s-1").minLsn();
        assertEquals(w.primary.lastCommitLsn, second);
        assertTrue(second > first);
    }
}
