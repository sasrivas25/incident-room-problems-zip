from orders_api.config import RoutingConfig
from orders_api.router import PRIMARY

from harness import World, order


def test_hidden_caught_up_replica_after_update_serves_the_read():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    w.all_replicas_catch_up()
    w.service.update_order("s-1", order("o-100", status="SHIPPED"))
    w.replica("replica-b").apply_until(w.primary.last_commit_lsn)
    fetched = w.service.get_order("s-1", "o-100")
    assert fetched.status == "SHIPPED"
    assert w.metrics.value("reads.replica") == 1
    assert w.metrics.value("reads.primary") == 0


def test_hidden_lag_just_above_threshold_is_excluded():
    w = World(RoutingConfig(max_replica_lag_ms=250))
    w.replica("replica-b").healthy = False
    w.replica("replica-a").lag_seconds = 0.251
    assert w.router.route_read("s-reader").target == PRIMARY
    w.replica("replica-a").lag_seconds = 0.25
    assert w.router.route_read("s-reader").target == "replica-a"


def test_hidden_unhealthy_caught_up_replica_is_not_used_within_window():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    w.replica("replica-a").catch_up()
    w.replica("replica-a").healthy = False
    assert w.router.route_read("s-1").target == PRIMARY
    assert w.service.get_order("s-1", "o-100") == order("o-100")


def test_hidden_second_write_moves_pin_forward():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    w.all_replicas_catch_up()
    w.service.update_order("s-1", order("o-100", status="SHIPPED"))
    assert w.router.route_read("s-1").target == PRIMARY
    w.all_replicas_catch_up()
    assert w.router.route_read("s-1").target != PRIMARY
    assert w.service.get_order("s-1", "o-100").status == "SHIPPED"


def test_hidden_other_session_reads_replica_while_writer_is_pinned():
    w = World()
    w.service.create_order("s-writer", order("o-100"))
    assert w.router.route_read("s-writer").target == PRIMARY
    assert w.router.route_read("s-other").target != PRIMARY


def test_hidden_api_read_after_write_returns_200_under_replica_lag():
    w = World()
    w.replica("replica-b").lag_seconds = 1.8
    w.api.create_order("s-1", "o-100", "c-1", 2500)
    response = w.api.get_order("s-1", "o-100")
    assert response.status == 200
    assert response.body["status"] == "PLACED"


def test_hidden_no_primary_read_when_a_replica_has_the_commit():
    w = World()
    w.replica("replica-a").healthy = False
    w.service.create_order("s-1", order("o-100"))
    w.replica("replica-b").apply_until(w.primary.last_commit_lsn)
    assert w.service.get_order("s-1", "o-100") == order("o-100")
    assert w.metrics.value("reads.replica") == 1
    assert w.metrics.value("reads.primary") == 0


def test_hidden_lag_threshold_from_config_dict():
    w = World(RoutingConfig.from_dict({"max_replica_lag_ms": 100}))
    w.replica("replica-b").healthy = False
    w.replica("replica-a").lag_seconds = 0.15
    assert w.router.route_read("s-reader").target == PRIMARY


def test_hidden_only_caught_up_replica_beyond_lag_threshold_is_not_used():
    w = World(RoutingConfig(replica_names=("replica-a", "replica-b", "replica-c")))
    w.service.create_order("s-1", order("o-100"))
    w.replica("replica-c").catch_up()
    w.replica("replica-c").lag_seconds = 0.3
    decision = w.router.route_read("s-1")
    assert decision.target == PRIMARY


def test_hidden_route_decision_carries_commit_lsn():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    decision = w.router.route_read("s-1")
    assert decision.min_lsn == w.primary.last_commit_lsn


def test_hidden_update_under_lag_reads_updated_status():
    w = World()
    w.replica("replica-a").lag_seconds = 0.12
    w.replica("replica-b").lag_seconds = 0.9
    w.api.create_order("s-1", "o-100", "c-1", 2500)
    w.all_replicas_catch_up()
    w.service.update_order("s-1", order("o-100", status="SHIPPED"))
    response = w.api.get_order("s-1", "o-100")
    assert response.status == 200
    assert response.body["status"] == "SHIPPED"


def test_hidden_pin_min_lsn_increases_across_writes():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    first = w.sessions.get_pin("s-1").min_lsn
    assert first == w.primary.last_commit_lsn
    w.service.create_order("s-1", order("o-101"))
    second = w.sessions.get_pin("s-1").min_lsn
    assert second == w.primary.last_commit_lsn
    assert second > first
