#include <optional>
#include <string>

#include "check.hpp"
#include "config.hpp"
#include "harness.hpp"
#include "router.hpp"

TEST_CASE(test_hidden_caught_up_replica_after_update_serves_the_read) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    w.all_replicas_catch_up();
    w.service->update_order("s-1", order("o-100", "c-1", 2500, "SHIPPED"));
    w.replica("replica-b").apply_until(w.primary->last_commit_lsn);
    auto fetched = w.service->get_order("s-1", "o-100");
    CHECK(fetched.has_value());
    CHECK_EQ(fetched->status, "SHIPPED");
    CHECK_EQ(w.metrics->value("reads.replica"), 1);
    CHECK_EQ(w.metrics->value("reads.primary"), 0);
}

TEST_CASE(test_hidden_lag_just_above_threshold_is_excluded) {
    RoutingConfig config;
    config.max_replica_lag_ms = 250;
    World w(config);
    w.replica("replica-b").healthy = false;
    w.replica("replica-a").lag_seconds = 0.251;
    CHECK_EQ(w.router->route_read("s-reader").target, PRIMARY);
    w.replica("replica-a").lag_seconds = 0.25;
    CHECK_EQ(w.router->route_read("s-reader").target, "replica-a");
}

TEST_CASE(test_hidden_unhealthy_caught_up_replica_is_not_used_within_window) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    w.replica("replica-a").catch_up();
    w.replica("replica-a").healthy = false;
    CHECK_EQ(w.router->route_read("s-1").target, PRIMARY);
    CHECK(w.service->get_order("s-1", "o-100") == order("o-100"));
}

TEST_CASE(test_hidden_second_write_moves_pin_forward) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    w.all_replicas_catch_up();
    w.service->update_order("s-1", order("o-100", "c-1", 2500, "SHIPPED"));
    CHECK_EQ(w.router->route_read("s-1").target, PRIMARY);
    w.all_replicas_catch_up();
    CHECK(w.router->route_read("s-1").target != PRIMARY);
    auto fetched = w.service->get_order("s-1", "o-100");
    CHECK(fetched.has_value());
    CHECK_EQ(fetched->status, "SHIPPED");
}

TEST_CASE(test_hidden_other_session_reads_replica_while_writer_is_pinned) {
    World w;
    w.service->create_order("s-writer", order("o-100"));
    CHECK_EQ(w.router->route_read("s-writer").target, PRIMARY);
    CHECK(w.router->route_read("s-other").target != PRIMARY);
}

TEST_CASE(test_hidden_api_read_after_write_returns_200_under_replica_lag) {
    World w;
    w.replica("replica-b").lag_seconds = 1.8;
    w.api->create_order("s-1", "o-100", "c-1", 2500);
    auto response = w.api->get_order("s-1", "o-100");
    CHECK_EQ(response.status, 200);
    CHECK_EQ(response.body.at("status"), "PLACED");
}

TEST_CASE(test_hidden_no_primary_read_when_a_replica_has_the_commit) {
    World w;
    w.replica("replica-a").healthy = false;
    w.service->create_order("s-1", order("o-100"));
    w.replica("replica-b").apply_until(w.primary->last_commit_lsn);
    CHECK(w.service->get_order("s-1", "o-100") == order("o-100"));
    CHECK_EQ(w.metrics->value("reads.replica"), 1);
    CHECK_EQ(w.metrics->value("reads.primary"), 0);
}

TEST_CASE(test_hidden_lag_threshold_from_config_dict) {
    World w(RoutingConfig::from_map({{"max_replica_lag_ms", "100"}}));
    w.replica("replica-b").healthy = false;
    w.replica("replica-a").lag_seconds = 0.15;
    CHECK_EQ(w.router->route_read("s-reader").target, PRIMARY);
}

TEST_CASE(test_hidden_only_caught_up_replica_beyond_lag_threshold_is_not_used) {
    RoutingConfig config;
    config.replica_names = {"replica-a", "replica-b", "replica-c"};
    World w(config);
    w.service->create_order("s-1", order("o-100"));
    w.replica("replica-c").catch_up();
    w.replica("replica-c").lag_seconds = 0.3;
    auto decision = w.router->route_read("s-1");
    CHECK_EQ(decision.target, PRIMARY);
}

TEST_CASE(test_hidden_route_decision_carries_commit_lsn) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    auto decision = w.router->route_read("s-1");
    CHECK(decision.min_lsn.has_value());
    CHECK_EQ(*decision.min_lsn, w.primary->last_commit_lsn);
}

TEST_CASE(test_hidden_update_under_lag_reads_updated_status) {
    World w;
    w.replica("replica-a").lag_seconds = 0.12;
    w.replica("replica-b").lag_seconds = 0.9;
    w.api->create_order("s-1", "o-100", "c-1", 2500);
    w.all_replicas_catch_up();
    w.service->update_order("s-1", order("o-100", "c-1", 2500, "SHIPPED"));
    auto response = w.api->get_order("s-1", "o-100");
    CHECK_EQ(response.status, 200);
    CHECK_EQ(response.body.at("status"), "SHIPPED");
}

TEST_CASE(test_hidden_pin_min_lsn_increases_across_writes) {
    World w;
    w.service->create_order("s-1", order("o-100"));
    auto first_pin = w.sessions->get_pin("s-1");
    CHECK(first_pin.has_value());
    const long long first = first_pin->min_lsn;
    CHECK_EQ(first, w.primary->last_commit_lsn);
    w.service->create_order("s-1", order("o-101"));
    auto second_pin = w.sessions->get_pin("s-1");
    CHECK(second_pin.has_value());
    const long long second = second_pin->min_lsn;
    CHECK_EQ(second, w.primary->last_commit_lsn);
    CHECK(second > first);
}
