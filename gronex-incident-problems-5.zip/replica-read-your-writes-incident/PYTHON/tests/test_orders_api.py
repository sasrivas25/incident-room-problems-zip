from orders_api.config import RoutingConfig
from orders_api.router import PRIMARY

from harness import World, order


def test_create_order_returns_201_with_location():
    w = World()
    response = w.api.create_order("s-1", "o-100", "c-1", 2500)
    assert response.status == 201
    assert response.body["location"] == "/v1/orders/o-100"
    assert w.primary.get_order("o-100") == order("o-100")


def test_read_without_recent_write_goes_to_replica():
    w = World()
    w.service.create_order("s-writer", order("o-100"))
    w.all_replicas_catch_up()
    assert w.service.get_order("s-reader", "o-100") == order("o-100")
    assert w.metrics.value("reads.replica") == 1
    assert w.metrics.value("reads.primary") == 0


def test_unhealthy_replica_is_never_chosen():
    w = World()
    w.service.create_order("s-writer", order("o-100"))
    w.all_replicas_catch_up()
    w.replica("replica-a").healthy = False
    decision = w.router.route_read("s-reader")
    assert decision.target == "replica-b"


def test_all_replicas_unhealthy_falls_back_to_primary():
    w = World()
    w.replica("replica-a").healthy = False
    w.replica("replica-b").healthy = False
    w.service.create_order("s-writer", order("o-100"))
    assert w.router.route_read("s-reader").target == PRIMARY
    assert w.service.get_order("s-reader", "o-100") == order("o-100")
    assert w.metrics.value("reads.primary") == 1


def test_pin_expires_after_read_your_writes_window():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    w.clock.advance(5)
    decision = w.router.route_read("s-1")
    assert decision.target != PRIMARY
    assert decision.min_lsn is None


def test_read_within_window_prefers_caught_up_replica_over_primary():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    w.replica("replica-a").catch_up()
    w.replica("replica-b").lag_seconds = 0.15
    assert w.service.get_order("s-1", "o-100") == order("o-100")
    assert w.metrics.value("reads.replica") == 1
    assert w.metrics.value("reads.primary") == 0


def test_session_without_pin_is_not_affected_by_other_sessions_write():
    w = World()
    w.service.create_order("s-writer", order("o-100"))
    decision = w.router.route_read("s-other")
    assert decision.target != PRIMARY
    assert decision.min_lsn is None


def test_all_replicas_lagging_beyond_threshold_fall_back_to_primary():
    w = World()
    w.replica("replica-a").lag_seconds = 0.5
    w.replica("replica-b").lag_seconds = 0.3
    w.service.create_order("s-writer", order("o-100"))
    w.all_replicas_catch_up()
    assert w.router.route_read("s-reader").target == PRIMARY


def test_lag_threshold_is_in_milliseconds():
    w = World()
    w.replica("replica-b").healthy = False
    w.replica("replica-a").lag_seconds = 0.25
    assert w.router.route_read("s-reader").target == PRIMARY
    w.replica("replica-a").lag_seconds = 0.15
    assert w.router.route_read("s-reader").target == "replica-a"


def test_read_after_write_goes_to_primary_when_no_replica_caught_up():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    decision = w.router.route_read("s-1")
    assert decision.target == PRIMARY
    assert w.service.get_order("s-1", "o-100") == order("o-100")
    assert w.metrics.value("reads.primary") == 1


def test_read_after_write_returns_the_new_order():
    w = World()
    w.replica("replica-b").lag_seconds = 0.12
    created = w.api.create_order("s-1", "o-100", "c-1", 2500)
    assert created.status == 201
    fetched = w.api.get_order("s-1", "o-100")
    assert fetched.status == 200
    assert fetched.body["order_id"] == "o-100"


def test_read_after_write_from_replica_applied_up_to_previous_position():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    w.replica("replica-a").apply_until(w.primary.last_commit_lsn - 1)
    w.replica("replica-b").apply_until(w.primary.last_commit_lsn - 1)
    assert w.service.get_order("s-1", "o-100") == order("o-100")
    assert w.metrics.value("reads.primary") == 1


def test_pin_uses_commit_lsn():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    pin = w.sessions.get_pin("s-1")
    assert pin is not None
    assert pin.min_lsn == w.primary.last_commit_lsn


def test_update_after_create_requires_replica_to_apply_update():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    w.all_replicas_catch_up()
    w.service.update_order("s-1", order("o-100", status="SHIPPED"))
    fetched = w.service.get_order("s-1", "o-100")
    assert fetched.status == "SHIPPED"


def test_replica_applied_exactly_at_commit_lsn_serves_the_read():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    w.replica("replica-a").apply_until(w.primary.last_commit_lsn)
    assert w.service.get_order("s-1", "o-100") == order("o-100")
    assert w.metrics.value("reads.replica") == 1
    assert w.metrics.value("reads.primary") == 0


def test_router_reports_primary_fallback_in_metrics():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    w.router.route_read("s-1")
    assert w.metrics.value("route.primary") == 1
    assert w.metrics.value("route.replica") == 0


def test_update_pin_uses_update_commit_lsn():
    w = World()
    w.service.create_order("s-1", order("o-100"))
    w.all_replicas_catch_up()
    w.service.update_order("s-1", order("o-100", status="SHIPPED"))
    pin = w.sessions.get_pin("s-1")
    assert pin.min_lsn == w.primary.last_commit_lsn
    assert pin.min_lsn > w.replica("replica-a").applied_lsn


def test_single_replica_setup_routes_to_primary_until_applied():
    w = World(RoutingConfig(replica_names=("replica-a",)))
    w.replica("replica-a").lag_seconds = 0.05
    w.service.create_order("s-1", order("o-100"))
    assert w.router.route_read("s-1").target == PRIMARY
    w.replica("replica-a").catch_up()
    assert w.router.route_read("s-1").target == "replica-a"
