from orders_api.api import OrdersApi
from orders_api.config import RoutingConfig
from orders_api.metrics import Metrics
from orders_api.models import Order
from orders_api.orders_service import OrdersService
from orders_api.router import ReadRouter

from fakes import FakeClock, FakeMonitor, FakePrimary, FakeReplica, FakeSessionStore


class World:
    def __init__(self, config: RoutingConfig = None) -> None:
        self.config = config or RoutingConfig()
        self.clock = FakeClock()
        self.primary = FakePrimary()
        self.replicas = {name: FakeReplica(name, self.primary) for name in self.config.replica_names}
        self.monitor = FakeMonitor(list(self.replicas.values()))
        self.sessions = FakeSessionStore()
        self.metrics = Metrics()
        self.router = ReadRouter(self.config, self.monitor, self.sessions, self.clock, self.metrics)
        self.service = OrdersService(self.config, self.primary, self.replicas, self.router, self.sessions, self.clock, self.metrics)
        self.api = OrdersApi(self.service)

    def replica(self, name: str) -> FakeReplica:
        return self.replicas[name]

    def all_replicas_catch_up(self) -> None:
        for replica in self.replicas.values():
            replica.catch_up()


def order(order_id: str, customer_id: str = "c-1", total_cents: int = 2500, status: str = "PLACED") -> Order:
    return Order(order_id, customer_id, total_cents, status)
