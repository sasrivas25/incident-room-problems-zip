from typing import Dict, List, Optional, Tuple

from orders_api.clock import Clock
from orders_api.database import PrimaryDatabase, ReplicaDatabase
from orders_api.models import Order, ReplicaStatus, SessionPin
from orders_api.replica_monitor import ReplicaMonitor
from orders_api.session_store import SessionStore

INITIAL_LSN = 0x5A3000
WRITE_RECORD_SIZE = 0x80
COMMIT_RECORD_SIZE = 0x40


class FakeClock(Clock):
    def __init__(self, start: float = 1_000_000.0) -> None:
        self._now = start

    def now(self) -> float:
        return self._now

    def advance(self, seconds: float) -> None:
        self._now += seconds


class FakePrimary(PrimaryDatabase):
    def __init__(self) -> None:
        self.lsn = INITIAL_LSN
        self.last_commit_lsn = INITIAL_LSN
        self.commits: List[Tuple[int, Dict[str, Order]]] = []
        self._pending: Dict[str, Order] = {}
        self._in_transaction = False

    def begin(self) -> None:
        self._in_transaction = True
        self._pending = {}

    def insert_order(self, order: Order) -> None:
        self._pending[order.order_id] = order
        self.lsn += WRITE_RECORD_SIZE

    def update_order(self, order: Order) -> None:
        self._pending[order.order_id] = order
        self.lsn += WRITE_RECORD_SIZE

    def current_lsn(self) -> int:
        return self.lsn

    def commit(self) -> int:
        self.lsn += COMMIT_RECORD_SIZE
        self.last_commit_lsn = self.lsn
        self.commits.append((self.lsn, dict(self._pending)))
        self._pending = {}
        self._in_transaction = False
        return self.lsn

    def get_order(self, order_id: str) -> Optional[Order]:
        return visible_order(self.commits, self.lsn, order_id)


def visible_order(commits: List[Tuple[int, Dict[str, Order]]], applied_lsn: int, order_id: str) -> Optional[Order]:
    found = None
    for commit_lsn, rows in commits:
        if commit_lsn <= applied_lsn and order_id in rows:
            found = rows[order_id]
    return found


class FakeReplica(ReplicaDatabase):
    def __init__(self, name: str, primary: FakePrimary) -> None:
        self._name = name
        self._primary = primary
        self.applied_lsn = primary.lsn
        self.lag_seconds = 0.01
        self.healthy = True

    def name(self) -> str:
        return self._name

    def catch_up(self) -> None:
        self.applied_lsn = self._primary.lsn

    def apply_until(self, lsn: int) -> None:
        self.applied_lsn = lsn

    def status(self) -> ReplicaStatus:
        return ReplicaStatus(self._name, self.applied_lsn, self.lag_seconds, self.healthy)

    def get_order(self, order_id: str) -> Optional[Order]:
        return visible_order(self._primary.commits, self.applied_lsn, order_id)


class FakeMonitor(ReplicaMonitor):
    def __init__(self, replicas: List[FakeReplica]) -> None:
        self._replicas = replicas

    def statuses(self) -> List[ReplicaStatus]:
        return [replica.status() for replica in self._replicas]


class FakeSessionStore(SessionStore):
    def __init__(self) -> None:
        self._pins: Dict[str, SessionPin] = {}

    def get_pin(self, session_id: str) -> Optional[SessionPin]:
        return self._pins.get(session_id)

    def set_pin(self, session_id: str, pin: SessionPin) -> None:
        self._pins[session_id] = pin
