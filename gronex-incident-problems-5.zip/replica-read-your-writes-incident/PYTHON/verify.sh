#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "=============================================="
echo " Gronex verify — Read-Your-Writes Broken by Replica Routing (Python)"
echo "=============================================="

PY="${PYTHON:-}"
if [ -z "$PY" ]; then
  if command -v python3 >/dev/null 2>&1; then PY=python3
  elif command -v python >/dev/null 2>&1; then PY=python
  else
    echo "ERROR: Python 3 not found. Install it, then re-run ./verify.sh"
    exit 2
  fi
fi

if ! "$PY" -c "import pytest" >/dev/null 2>&1; then
  echo "pytest not found — installing it locally..."
  "$PY" -m pip install --quiet --user pytest || {
    echo "ERROR: could not install pytest. Run: $PY -m pip install pytest"
    exit 2
  }
fi

set +e
"$PY" -m pytest tests -q
STATUS=$?
set -e

echo "----------------------------------------------"
if [ "$STATUS" -eq 0 ]; then
  echo "✅ PASS — all checks green. Your solution is correct."
else
  echo "❌ FAIL — some checks did not pass. Keep going!"
  echo "   Read the failures above; fix src/, then run ./verify.sh again."
fi
exit "$STATUS"
