# Scoring report: replica-read-your-writes-incident

30 tests per language: 18 visible (`tests/`) plus 12 hidden (overlaid from `hidden/<LANG>/`). Score is the share passing out of 30. Measured with `scoring_runs.sh`; the four states are:

- **main**: the broken code contestants receive.
- **partial, lag units only**: the most obvious fault fixed in isolation. The lag comparison converts seconds to milliseconds; the pin position and the primary fallback are untouched.
- **naive, symptom only**: the lag units fixed plus the old behaviour restored by brute force: every read from a pinned session goes to the primary, regardless of what the replicas have applied. The pin still carries the pre-commit position. This makes the 404 alert disappear in production.
- **solution**: the `solution` branch.

| Language | main | partial, lag units only | naive, always primary | solution |
| --- | --- | --- | --- | --- |
| Python | 10 / 30 (8 visible + 2 hidden) | 14 / 30 | 20 / 30 | 30 / 30 |
| Java | 10 / 30 (8 visible + 2 hidden) | 14 / 30 | 20 / 30 | 30 / 30 |
| Node.js | 10 / 30 (8 visible + 2 hidden) | 14 / 30 | 20 / 30 | 30 / 30 |
| C++ | 10 / 30 (8 visible + 2 hidden) | 14 / 30 | 20 / 30 | 30 / 30 |

Percent of 100: main 33, lag units only 47, naive always-primary 67, solution 100. Identical across languages because test names and assertions are identical and the pass/fail sets were diffed per language.

## What each state still fails

**main (20 failing)**: every threshold test, every pinned-read fallback test, every commit-LSN test and the end-to-end read-after-write tests. The 10 passing tests are the behaviours that must not regress: create returns 201, unpinned reads go to replicas, unhealthy replicas are skipped, all-unhealthy falls back to the primary, the pin expires, caught-up replicas are preferred over the primary (visible and two hidden variants), and other sessions are unaffected.

**partial, lag units only (16 failing)**: excluding lagging replicas correctly fixes `test_all_replicas_lagging_beyond_threshold_fall_back_to_primary`, `test_lag_threshold_is_in_milliseconds`, `test_hidden_lag_just_above_threshold_is_excluded` and `test_hidden_lag_threshold_from_config_dict`. Every read-after-write test still fails because a pinned read with no caught-up replica is still served by replica-a.

**naive, always primary (10 failing)**: read-after-write is restored, so the production alert would clear. Still failing: the four tests that require a caught-up replica to serve a pinned read (`test_read_within_window_prefers_caught_up_replica_over_primary`, `test_replica_applied_exactly_at_commit_lsn_serves_the_read`, `test_hidden_caught_up_replica_after_update_serves_the_read`, `test_hidden_no_primary_read_when_a_replica_has_the_commit`, `test_hidden_second_write_moves_pin_forward`, `test_single_replica_setup_routes_to_primary_until_applied`), and the commit-LSN tests (`test_pin_uses_commit_lsn`, `test_update_pin_uses_update_commit_lsn`, `test_hidden_route_decision_carries_commit_lsn`, `test_hidden_pin_min_lsn_increases_across_writes`). Note that this state fails two tests that pass on main, because it stops using replicas that have the data.

## Score movement

- Fixing fault 1 (lag units): +4 tests.
- Fixing fault 3 (primary fallback for pinned reads with no caught-up replica) on top: +9 tests.
- Fixing fault 2 (pin the commit LSN) on top: +7 tests, reaching 30.
