# Defend rubric: Read-Your-Writes Broken by Replica Routing

## What a strong answer says

1. **Three fixes and why each is necessary.** Lag compared in milliseconds (with equality eligible); the pin carries the LSN returned by commit, for create and update; a pinned read with no caught-up replica goes to the primary and is counted as `route.primary`. The answer should connect each fix to a log line.
2. **Why it is safe mid-incident.** The change only moves reads that would otherwise be wrong onto the primary. Expected primary read share returns to its 10 to 15 percent band (the runbook's I4), far below the 30 percent saturation point. Replica-b is excluded automatically while it lags, so replica-a carries unpinned reads as it did before the deploy. No data migration, no config change, pods restart one at a time.
3. **The trade-off named explicitly.** Consistency for the writing session versus primary load. Time-based pinning is simplest and correct but spends primary capacity on reads a replica could serve; LSN-aware routing with primary fallback keeps the primary at its budget and gives the same guarantee, at the price of depending on fresh monitor data. The strong answer says which they chose and what makes the dependency acceptable (window plus lag threshold as a second guard).
4. **Residual risk.** Monitor sample staleness; the race for the warehouse flow (write then immediate read on the same session is fine, but a different session reading the same order has no pin and may see the old status); sessions spanning multiple pods share the pin store, so the store must be shared, not per-pod.

## Trade-offs the answer should name

- Primary fallback (correct, costs primary capacity) versus least-lagging replica (cheap, wrong).
- Pin by commit LSN (exact) versus pin by time (simple, over-routes to primary).
- Strict lag threshold (fewer replicas, more primary load) versus loose (more stale risk) and why the unit matters.
- Waiting for a replica to catch up (less primary load, more latency) as a follow-up rather than a hotfix.

## Risks a good engineer flags

- Primary CPU during rollout of the fix; watch it against the 80 percent alert.
- Monitor staleness: a cached applied position up to 5 s old can qualify a replica that has since fallen behind only if positions move backwards, which they do not; staleness therefore errs safe, but a monitor outage must not default replicas to eligible.
- The 09:21 warehouse case: a confirmation read by the same session is fixed; a dashboard refreshed by another user still sees PLACED for up to the replica lag. That is expected and should be stated.
- Deploy process: the success check used the metric the change was meant to improve; add the correctness metric.

## Follow-up questions for finalists

1. **Why fall back to the primary instead of waiting for a replica?** Good answer: a bounded wait trades latency for primary load; with 20 ms replica lag a 50 ms wait would catch most cases, but under the 2 s lag seen today the wait always expires; keep fallback, consider wait as an optimisation later.
2. **Where did the pin position come from before your fix and why was it wrong?** Good answer: read inside the transaction, before the commit record; a replica at exactly that position lacks the commit; the position returned by commit is the first safe one.
3. **The monitor reports lag in seconds. What else could you change so this unit mistake cannot recur?** Good answer: a typed duration, or normalise at the boundary (monitor adapter converts to ms), plus a unit test at the threshold.
4. **How much extra primary load does your fix add compared with r2, and compared with r1?** Good answer: compared with r2 the pinned reads with no caught-up replica, roughly the 12 percent band under lag and much less when replicas are fresh; compared with r1 it is lower because caught-up replicas still serve pinned reads.
5. **What happens if the monitor is down entirely?** Good answer: with no statuses there are no eligible replicas and everything goes to the primary; acceptable for a short time, must alert; never default to eligible.
6. **A customer in two browser tabs: the order is created in one, the other refreshes. Same session, different pods. Does read-your-writes hold?** Good answer: only if the pin store is shared across pods and the second request carries the same session id; a per-pod pin would fail.
7. **The not-found ratio settled at 1.2 percent after replica-b recovered. Explain that number.** Good answer: replica-a at about 20 ms lag versus reads 400 to 900 ms after the write should almost always be caught up; the floor comes from pins carrying the pre-commit position and the least-lagging fallback when replica-a is a record or two behind; both fixed.
8. **What would you add to the rollout check?** Good answer: `order_not_found_after_create` must stay at zero for the window, and primary read share must stay inside its band, not merely below a ceiling.
