# Solution review: Read-Your-Writes Broken by Replica Routing

Post-contest walkthrough: the incident reconstructed from the artifacts, each fault, the fix, the trade-off, and what would have caught it earlier.

## Timeline reconstructed from the logs

| Time (UTC) | Source | What happened |
| --- | --- | --- |
| 09:11:05 | db.log | A late analytics rollup on replica-b conflicts with replay (`recovery conflict on snapshot, delaying replay`). Lag saw-tooths between 0.8 s and 2.5 s in 90 s cycles as the query is cancelled and retried. |
| 09:11:08 to 09:11:46 | app.log | r1 pods log `replica-b excluded from read pool: lag=... above max_replica_lag_ms=200`. The old router handled the lag correctly. |
| 09:11:40 | app.log | `replica_lag` alert. The runbook calls it routine. |
| 09:12:31 | app.log | Replica monitor poll times out against the slow replica-b; stack trace through the router; cached statuses used. Harmless. |
| 09:14:02 to 09:16:30 | deploy.log, app.log | Build 2026.10.30-r2 (ORD-2210) rolls out. New pods log `routing=lsn_aware`. Route decision lines now show `lag=1.82s ... eligible=true`. |
| 09:16:35 | deploy.log | Rollout marked SUCCESS: error rate zero, p99 fine, primary read share 0.4 percent. |
| 09:16:41 | app.log, db.log | Session s-7f3a creates o-88213 (`pin_lsn=0/8342C0`; db.log `commit_lsn=0/834300`). 490 ms later the read is routed to replica-a with `caught_up=false reason=least_lagging_replica` and returns 404. |
| 09:17:20 | app.log | `order_not_found_after_create` alert. |
| 09:18:12 | app.log, db.log | Session s-c04e creates o-88301 (`pin_lsn=0/86FA80`, `commit_lsn=0/86FAC0`). replica-a is at exactly `0/86FA80`, is marked `caught_up=true`, and returns 404. |
| 09:21:10 | app.log | Warehouse session marks o-88150 SHIPPED; the confirming read is routed to replica-a as `least_lagging_replica` and returns `body.status=PLACED`. |
| 09:23:03 | app.log | replica-a health probe fails for 10 s; a pinned read goes to replica-b at 1.91 s lag, `eligible=true`, 404. |
| 09:29:04 | db.log | The analytics query finishes; replica-b lag back to 20 ms. The not-found ratio drops to about 1.2 percent and stays there. |
| 09:30:50, 09:33:10 | app.log | 404s continue with both replicas at 20 ms lag: replica-a is one or two records behind the write. |

## Root cause and faults

### Fault 1: lag threshold compared in the wrong unit (`router`)

The monitor reports lag in seconds. `max_replica_lag_ms` is milliseconds. The eligibility check compares them directly, so `1.82 <= 200` and replica-b is never excluded. Fix: multiply by 1000 before comparing, with equality allowed (I2, I3 in the runbook).

### Fault 2: the pin records a position before the commit record (`orders_service`)

The write path reads `current_lsn()` inside the transaction and then commits. The pin therefore carries the position of the row's WAL record, 0x40 short of the commit LSN. A replica that has applied exactly up to that position has not applied the commit and does not see the row, yet the router judges it caught up. Fix: pin the LSN returned by `commit()`. The db.log shows the gap on every order: `wal=0/86FA80` then `commit_lsn=0/86FAC0`.

### Fault 3: no caught-up replica falls back to the least-lagging replica instead of the primary (`router`)

r2's goal was to take reads off the primary. When a pinned session finds no replica that has applied its position, the router picks the least-lagging eligible replica anyway (`reason=least_lagging_replica`). This is the direct cause of most 404s, and it is why the problem persisted after replica-b recovered: replica-a at 20 ms lag is still behind a write made 400 ms ago often enough to produce the 1.2 percent floor. Fix: fall back to the primary with `reason=no_replica_caught_up`.

### Why all three are needed

Fixing fault 1 removes replica-b from the pool but replica-a still serves pinned reads it cannot satisfy. Fixing fault 3 alone sends those reads to the primary but a replica standing exactly at the pre-commit position still passes the caught-up check. Fixing fault 2 alone changes which replicas pass the check but not what happens when none do. The hidden suite exercises each gap separately.

## Why the replica lag is a red herring

The `replica_lag` alert fired three minutes before the deploy and was the loudest line in the window, with a stack trace to go with it. But the r1 pods excluded replica-b correctly and no user saw an error until the first r2 pod started. The lag ended at 09:29:04 and the 404s continued. Lag is an input the router exists to handle; the router stopped handling it.

## The trade-off

The naive recovery is to restore the five-second primary pin: every read in the window goes to the primary. It is correct and simple, and it throws away the deploy's purpose; primary read share returns to 12 percent, and under lag it goes higher. The fix keeps LSN-aware routing: a replica that has applied the commit position serves the read, the primary serves only reads no replica can satisfy. That keeps the primary read share near its budget while restoring I1. The cost is a dependency on fresh monitor data; a stale applied position can wrongly qualify a replica, which is why the window and lag threshold remain as a second guard.

Alternatives rejected:

- Time-based pin only: correct but burns primary capacity, and the hidden tests require a caught-up replica to serve pinned reads.
- Wait-for-replica (block up to N ms for a replica to catch up): lowers primary load further but adds tail latency to checkout; reasonable follow-up, not a hotfix.
- Exclude replica-b permanently: fixes nothing about replica-a races and halves read capacity.

## Key files in the fix

- `router`: unit conversion in eligibility; primary fallback when no replica has the commit position; `route.primary` counted.
- `orders_service`: pin the LSN returned by commit, for both create and update.

## What would have caught it sooner

- A deploy check on `order_not_found_after_create`, not only on error rate, latency and the metric the change was meant to improve.
- A unit test asserting that a replica with lag 0.25 s is excluded at a 200 ms threshold, and one asserting the pin equals the commit LSN.
- An alert when primary read share falls below the expected band while pinned sessions exist; a share near zero means pinned reads are being served by replicas.
- Typed units in config and monitor data (milliseconds everywhere, or a Duration type).
