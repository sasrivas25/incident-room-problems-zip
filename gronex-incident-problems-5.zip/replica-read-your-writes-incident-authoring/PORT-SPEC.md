# Port spec: replica-read-your-writes-incident (Gronex Incident Room problem)

You are porting ONE language of a four-language incident problem. The Python tree is the executable specification. Translate it; do not redesign it.

Repo root: `/Users/ssrivastav2/Documents/Repo/replica-read-your-writes-incident/`

## Inputs (read all of them first)
- Broken (main-branch) Python source: `PYTHON/src/orders_api/*.py`
- Fixed (solution-branch) Python source: `/Users/ssrivastav2/Documents/Repo/replica-read-your-writes-incident-authoring/solution/PYTHON/src/orders_api/*.py`
- Visible tests + fakes + harness: `PYTHON/tests/{conftest.py,fakes.py,harness.py,test_orders_api.py}`
- Hidden tests: `hidden/PYTHON/tests/test_hidden.py`
- `PYTHON/README.md` and `PYTHON/verify.sh` (copy and adapt for your language).

## Deliverables for your language `<LANG>` (JAVA, NODEJS or CPP)
1. `<LANG>/` project at the repo root with the BROKEN source (faithful port of `PYTHON/src`, same faults, same behaviour, same metric names, same constants, same reason strings).
2. `/Users/ssrivastav2/Documents/Repo/replica-read-your-writes-incident-authoring/solution/<LANG>/src/...` : the FIXED source files only (same file names as your broken `src/`), a faithful port of the Python solution. Every file in your broken `src/` must have a counterpart here, even if identical (copy it).
3. Visible tests under `<LANG>/tests...` with EXACTLY the same 18 test names as `PYTHON/tests/test_orders_api.py` (identical spelling) and the same assertions.
4. Hidden tests with EXACTLY the same 12 test names as `hidden/PYTHON/tests/test_hidden.py`, at the path given below. They must compile/run when overlaid and the build must still work when they are absent.
5. `<LANG>/verify.sh` (chmod +x) following the contract below.
6. `<LANG>/README.md`: copy `PYTHON/README.md` and adapt only the title suffix, the `src/...` row of the "What you have" table, "Project layout" and "How to run".

Do NOT create logs/, metrics/, docs/ or problem.json; I generate those.

## Expected results (must match exactly)
- Broken source, visible tests only: 8 pass, 10 fail.
- Broken source + hidden overlay: 10 pass, 20 fail (30 total).
- Fixed source + hidden overlay: 30 pass, 0 fail.
The passing set on broken code must be the same tests as in Python. Run Python yourself to see which ones:
`PYTHON=/Users/ssrivastav2/Documents/Repo/_gronex-tools/venv/bin/python; cd PYTHON && $PYTHON -m pytest tests -v`.
If your counts differ, your port is wrong. Do not change assertions to match your output.

## Hard rules
- No comments of any kind in files under `src/`, `tests/`, `tests_hidden/` or `hidden/`. (Build files, verify.sh and README may have comments.)
- Standard library only. No external dependencies (Java: JUnit 5 only, cached locally; Node: `node:test` + `node:assert/strict`; C++: no gtest, use the tiny registry header described below).
- Deterministic: no wall clock, no sleep, no randomness, no network, no threads. The FakeClock is the only time source.
- Same file-per-concept structure as Python: models, clock, config, lsn, database, replica_monitor, session_store, metrics, router, orders_service, api. Use idiomatic names (e.g. `ReadRouter.java`, `router.js`, `router.hpp/.cpp`).
- The stack-trace points must exist as real lines of code in your broken source, because the incident logs quote them. After you finish, report the exact file path and 1-based line number (in your BROKEN source) of each of these statements:
  T1. in `router`: the line inside the eligibility loop that compares `lag_seconds` against `max_replica_lag_ms` (Python `router.py` `if status.lag_seconds > self._config.max_replica_lag_ms:`).
  T2. in `router`: the line in the eligibility helper that calls `monitor.statuses()` (Python `for status in self._monitor.statuses():`).
  T3. in `router`: the line in `route_read` that calls the eligibility helper (Python `candidates = self._eligible_replicas()`).
  T4. in `orders_service`: the line in `get_order` that calls `router.route_read(session_id)`.
  T5. in `api`: the line that calls `service.get_order(...)` inside the try.
  T6. in `orders_service`: the line in `create_order` that reads `current_lsn()` before commit (the bug).
  T7. in `router`: the line in `route_read` that returns the least-lagging replica when no replica is caught up (Python `return self._pick_replica(candidates, pin.min_lsn, "least_lagging_replica")`).
  Also report the natural exception type your language would use for a replica monitor timeout (we only need the type name for a log line; nothing in src throws it).

## verify.sh contract (all languages)
Prints a banner, runs tests, prints exactly one of these two lines, exits with the test runner status:
```
✅ PASS — all checks green. Your solution is correct.
❌ FAIL — some checks did not pass. Keep going!
```
Banner: `==============================================` / ` Gronex verify — Read-Your-Writes Broken by Replica Routing (<Language>)` / `==============================================`.
Then after the run: `----------------------------------------------` then the PASS or FAIL line; on FAIL also print `   Read the failures above; fix src/, then run ./verify.sh again.`
Fully local, no network except dependency install. It must work from any cwd (`cd "$(dirname "$0")"`).

### JAVA
- Layout: `JAVA/pom.xml`, `JAVA/src/main/java/com/gronex/orders/*.java`, visible tests `JAVA/tests/java/com/gronex/orders/{Fakes.java,World.java,OrdersApiTest.java}`, hidden test file `hidden/JAVA/tests/java/com/gronex/orders/HiddenIncidentTest.java` (it lands at `JAVA/tests/java/com/gronex/orders/HiddenIncidentTest.java` when overlaid).
- pom: Java 17 (`maven.compiler.release` 17), `junit-jupiter` 5.10.2 test scope, `testSourceDirectory` = `tests/java`, plugins pinned: maven-resources-plugin 3.3.1, maven-compiler-plugin 3.13.0, maven-surefire-plugin 3.2.5. groupId `com.gronex`, artifactId `replica-read-your-writes-incident`.
- Test method names = the Python test names verbatim (e.g. `void test_cache_hit_skips_origin()`), annotated `@Test`.
- verify.sh runs `mvn -q test`; exit status from mvn. Print the surefire summary line(s) (`Tests run: ...`) so the contestant sees counts: run `mvn test` to a temp log and grep `Tests run:|FAIL|ERROR` lines, or run it unquiet. Keep output readable.
- Build environment quirks ON THIS MACHINE ONLY (do not bake into verify.sh): before running mvn, `source /Users/ssrivastav2/Documents/Repo/_gronex-tools/env.sh` (sets JAVA_TOOL_OPTIONS tmpdir and MAVEN_ARGS pointing at a writable local repo + settings). Run mvn offline (`mvn -o ...`) via that env; the required plugins/deps are cached. If an artifact is missing, run `/Users/ssrivastav2/Documents/Repo/_gronex-tools/mvn-fetch-missing.sh <JAVA project dir> test`.
- Model types: `Order`, `ReplicaStatus`, `SessionPin`, `RouteDecision` as records; `RoutingConfig` record with `defaults()`, `fromMap(Map<String,Object>)` and `with...` helpers; `ApiResponse(int status, Map<String,Object> body)`. `RouteDecision.minLsn` is a nullable `Long` (Python `Optional[int]`). LSNs are `long`.
- Metrics counter names are the same strings as Python (`reads.primary`, `reads.replica`, `route.primary`, `route.replica`, `orders.created`, `orders.updated`).

### NODEJS
- Layout: `NODEJS/package.json` (`"type": "commonjs"`, scripts.test = `node --test tests`, no dependencies), `NODEJS/src/*.js` (one file per concept, CommonJS `module.exports`), visible tests `NODEJS/tests/{fakes.js,harness.js,orders_api.test.js}`, hidden `hidden/NODEJS/tests_hidden/hidden.test.js` (lands at `NODEJS/tests_hidden/hidden.test.js`; it requires `../tests/harness.js` and `../src/...`).
- Use `const test = require('node:test'); const assert = require('node:assert/strict');` and `test('test_cache_hit_skips_origin', () => {...})` with the Python names verbatim.
- verify.sh: `if [ -d tests_hidden ]; then node --test tests tests_hidden; else node --test tests; fi` (node >= 18; `node --test <dir>` runs *.test.js files in the directory).
- Orders, statuses, pins and decisions as frozen plain objects (`{ orderId, customerId, totalCents, status }`, `{ name, appliedLsn, lagSeconds, healthy }`, `{ minLsn, expiresAt }`, `{ target, reason, minLsn }` with `minLsn: null` when absent); compare with `assert.deepEqual`. Config as a frozen object built by `routingConfig({...overrides})` with the same defaults; also export `configFromDict(obj)`. LSNs are plain numbers (they stay far below 2^53).

### CPP
- Layout: `CPP/CMakeLists.txt`, `CPP/src/*.hpp` and `*.cpp` (header per concept; implementation .cpp for cache_keys, codec, service, api, identifiers, config), visible tests `CPP/tests/cpp/{check.hpp,fakes.hpp,harness.hpp,test_main.cpp,orders_api_tests.cpp}`, hidden `hidden/CPP/tests/cpp/hidden_tests.cpp` (lands at `CPP/tests/cpp/hidden_tests.cpp`).
- C++17, no external deps. `check.hpp` is a tiny self-registering test framework:
  ```cpp
  #pragma once
  #include <functional> <map> <stdexcept> <string> <vector> <iostream> <sstream>
  struct CheckFailure : std::runtime_error { using std::runtime_error::runtime_error; };
  using TestFn = std::function<void()>;
  std::map<std::string, TestFn>& test_registry();   // defined in test_main.cpp
  struct TestRegistrar { TestRegistrar(const char* name, TestFn fn) { test_registry()[name] = std::move(fn); } };
  #define TEST_CASE(name) static void name(); static TestRegistrar name##_registrar(#name, name); static void name()
  #define CHECK(cond) do { if (!(cond)) throw CheckFailure(std::string(__FILE__) + ":" + std::to_string(__LINE__) + " CHECK failed: " #cond); } while (0)
  #define CHECK_EQ(a, b) ... (stringify both sides with operator<< via a helper; for types without <<, use CHECK((a) == (b)))
  ```
  `test_main.cpp` defines `test_registry()` and `main(argc, argv)`: with `--list` prints one test name per line; with a test name runs only that test (exit 0 pass / 1 fail, printing the failure message); with no args runs all and prints `PASS: name` / `FAIL: name  <msg>` lines and a `N passed, M failed` summary, exit 1 if any failed.
- CMakeLists.txt: globs `src/*.cpp` and `tests/cpp/*.cpp` into one executable `incident_tests`; `enable_testing()`; then registers ONE CTest test per TEST_CASE by scanning the test sources at configure time:
  ```cmake
  file(GLOB TEST_SOURCES ${CMAKE_SOURCE_DIR}/tests/cpp/*.cpp)
  foreach(src ${TEST_SOURCES})
    file(STRINGS ${src} lines REGEX "^TEST_CASE\\(")
    foreach(line ${lines})
      string(REGEX REPLACE "^TEST_CASE\\(([A-Za-z0-9_]+)\\).*" "\\1" name "${line}")
      add_test(NAME ${name} COMMAND incident_tests ${name})
    endforeach()
  endforeach()
  ```
  Each TEST_CASE must therefore start at column 0 on its own line: `TEST_CASE(test_cache_hit_skips_origin) {`.
- verify.sh: `cmake -S . -B build -DCMAKE_BUILD_TYPE=Release` && `cmake --build build` && `(cd build && ctest --output-on-failure)`; exit with ctest status; print the ctest summary.
- Types: `struct Order { std::string order_id, customer_id; int total_cents; std::string status; bool operator== }`, `struct ReplicaStatus { std::string name; long long applied_lsn; double lag_seconds; bool healthy; }`, `struct SessionPin { long long min_lsn; double expires_at; }`, `struct RouteDecision { std::string target; std::string reason; std::optional<long long> min_lsn; }`, `struct RoutingConfig { int max_replica_lag_ms = 200; int read_your_writes_window_s = 5; std::vector<std::string> replica_names = {"replica-a", "replica-b"}; static RoutingConfig from_map(const std::map<std::string,std::string>&); }` (from_map parses replica_names from a comma-separated string), `struct ApiResponse { int status; std::map<std::string,std::string> body; }` (total_cents rendered via std::to_string), interfaces as abstract classes with virtual methods (`PrimaryDatabase`, `ReplicaDatabase`, `ReplicaMonitor`, `SessionStore`, `Clock`). The service holds references to the injected collaborators; the test `World` owns them (shared_ptr). `World` exposes `replica(name)` returning a `FakeReplica&` and `all_replicas_catch_up()`.

## Semantics that must be preserved exactly
- FakePrimary: `lsn` starts at 0x5A3000; `insert_order`/`update_order` add 0x80 to `lsn`; `current_lsn()` returns `lsn`; `commit()` adds 0x40, sets `last_commit_lsn`, appends `(commit_lsn, pending rows)` to `commits`, returns the commit lsn. `get_order` on the primary sees everything committed. `visible_order(commits, applied_lsn, id)` returns the latest version of the row among commits with `commit_lsn <= applied_lsn`.
- FakeReplica(name, primary): `applied_lsn` starts at the primary's current lsn at construction; `lag_seconds` 0.01; `healthy` true; `catch_up()` sets applied_lsn to the primary's current lsn; `apply_until(lsn)` sets it; `status()`; `get_order` uses `visible_order` with its own applied_lsn.
- FakeMonitor returns the statuses of the replicas in construction order. FakeSessionStore is a map.
- World: config (defaults), clock, primary, replicas built from `config.replica_names` in order, monitor, sessions, metrics, router, service, api; `replica(name)`; `all_replicas_catch_up()`. `order(order_id, customer_id="c-1", total_cents=2500, status="PLACED")` helper.
- Broken router: eligibility = healthy and `lag_seconds <= max_replica_lag_ms` (unit bug: seconds compared to milliseconds); with an active pin and no caught-up replica it still picks the least-lagging eligible replica (reason "least_lagging_replica"); only an empty candidate list falls back to primary (reason "no_eligible_replica"), incrementing `route.primary`; replica picks increment `route.replica`. Least-lagging = min by (lag_seconds, name).
- Fixed router: eligibility uses `lag_seconds * 1000.0 > max_replica_lag_ms` to exclude; with an active pin and no caught-up replica it returns primary with reason "no_replica_caught_up" and increments `route.primary`.
- Pin active iff `clock.now() < expires_at`. Broken service pins `current_lsn()` read before `commit()`; fixed service pins the value returned by `commit()`. `expires_at = now + read_your_writes_window_s`.
- Api: `create_order(session_id, order_id, customer_id, total_cents)` returns 400 `{"error":"invalid_order"}` if total_cents <= 0 or either id is empty; otherwise creates with status "PLACED" and returns 201 `{"order_id":..., "location":"/v1/orders/<id>"}`. `get_order(session_id, order_id)`: 500 `{"error":"internal"}` if the service throws, 404 `{"error":"not_found"}` if absent, else 200 with order_id, customer_id, total_cents, status.

## When done
Run your verify.sh in all three states (broken, broken+hidden, fixed+hidden) and report the three result lines, plus the T1-T7 file:line table. Remove any hidden overlay files you copied into `<LANG>/` before finishing (the hidden files must only live under `hidden/`), and remove build outputs (`build/`, `target/`); do not leave stray files elsewhere in the repo. Keep the repo free of comments in src/tests.
