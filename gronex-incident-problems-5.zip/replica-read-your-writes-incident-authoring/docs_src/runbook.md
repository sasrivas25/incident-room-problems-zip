# orders-api on-call runbook

Owner: Commerce Platform team. Pager: `#commerce-oncall`. Last reviewed 2026-09-02.

## Service summary

`orders-api` owns `POST /v1/orders`, `PUT /v1/orders/{id}` and `GET /v1/orders/{id}`. Writes go to the primary database. Reads are served by two streaming replicas, `replica-a` and `replica-b`, with the primary as fallback. The checkout flow issues a `POST`, receives a `201` with a `Location`, and the browser follows it with a `GET` within a few hundred milliseconds. The warehouse scanner issues a `PUT` and immediately re-reads the order to confirm the status change.

Traffic: about 180 reads/s and 14 writes/s. The primary is sized for the write load plus at most 15 percent of reads; above 30 percent of reads its CPU saturates.

## Read routing

Every read passes through the router, which decides between the primary and a replica:

1. A session that wrote recently is pinned. The pin records the write's commit position (LSN) and expires `read_your_writes_window_s` (5 s) after the write.
2. A replica is eligible when the monitor reports it healthy and its replication lag is at or below `max_replica_lag_ms` (200 ms). Lag is reported by the monitor in seconds.
3. A pinned session may read from a replica only if that replica has applied the session's commit position. Otherwise the read goes to the primary.
4. Sessions without a pin read from the least-lagging eligible replica. If no replica is eligible, reads go to the primary.

Positions: the commit LSN is the position after the commit record. Positions observed inside a transaction, before commit, are lower than the commit LSN. Replicas report the position they have applied; a replica at or beyond a commit LSN has that commit.

## Invariants

| Id | Invariant |
| --- | --- |
| I1 | A session reads its own writes while its pin is active, whatever the replicas are doing. |
| I2 | A read never goes to a replica whose lag exceeds `max_replica_lag_ms`. The config value is milliseconds. |
| I3 | A pinned read goes to a replica only when that replica has applied the session's commit position; a replica that has applied exactly that position qualifies. |
| I4 | The primary serves only what the replicas cannot: pinned reads with no caught-up replica, and reads with no eligible replica. In steady state that is 10 to 15 percent of reads. |
| I5 | A session's pin never affects another session. |

## Configuration

| Key | Default | Effect |
| --- | --- | --- |
| `max_replica_lag_ms` | `200` | Replicas lagging more than this are excluded from the read pool. |
| `read_your_writes_window_s` | `5` | How long after a write a session stays pinned. |
| `replica_names` | `replica-a,replica-b` | Replicas in the read pool. |

Config is injected at pod start; a change needs a rolling restart (about 30 s per pod).

## Alerts

| Alert | Threshold | Usual cause |
| --- | --- | --- |
| `replica_lag` | above 1.0 s for 30 s | A long query on the replica conflicting with replay (`max_standby_streaming_delay` is 30 s). The router excludes the replica; no user impact expected. Resolves when the query finishes or is cancelled. |
| `order_not_found_after_create` | above 0.010 for 60 s | A read after a write was served by a replica that had not applied the write. Should be zero. |
| `primary_cpu` | above 80 percent | Too many reads on the primary, usually because every replica is excluded. |

## Known failure modes

### Replica lag from analytics queries

`replica-b` also serves the analytics team's rollups. When a rollup runs late into the morning, replay on replica-b is delayed in 30 s steps as the conflict resolution cancels and the client retries. Expected behaviour: the router drops replica-b, replica-a takes all unpinned reads, pinned reads go to replica-a when it has caught up or the primary otherwise. No action needed. If it lasts more than 30 minutes, cancel the query (`pg_cancel_backend` on replica-b) and tell `#analytics`.

### Replica monitor timeouts

The status endpoint on a lagging replica is slow. The monitor client times out after 250 ms and the router uses the last known statuses (up to 5 s old). Logged as a WARN with a stack trace; harmless by itself.

### Primary overload

Every replica unhealthy, or a config change that excludes them, pushes all reads to the primary. Watch `primary_cpu`. Re-adding a replica is faster than scaling the primary.

## Mitigation levers, fastest first

1. Rollback the deploy if the symptom correlates with a rollout (`rollout undo orders-api`, about 3 minutes).
2. Cancel the conflicting query on the lagging replica. Removes the lag, not a routing bug.
3. Lower `max_replica_lag_ms` to exclude a slow replica sooner. Rolling restart required.
4. Removing a replica from `replica_names` sends its share of reads to the other replica; removing both sends everything to the primary. Check `primary_cpu` before doing this during peak.

## Verification after a fix

- `order_not_found_after_create` back to zero, including after replica lag has recovered.
- Primary read share back in the 10 to 15 percent band. A share near zero with pinned sessions present means pinned reads are being served by replicas that may not have the write.
- Route decision logs: every `reason=least_lagging_replica` or `reason=replica_caught_up` decision for a pinned session must show `caught_up=true` for the chosen replica.

## Escalation

- Commerce Platform lead: `#commerce-platform`.
- Database on-call for replication issues: `#dba-oncall`.
