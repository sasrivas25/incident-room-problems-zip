from typing import List, Optional

from .clock import Clock
from .config import RoutingConfig
from .metrics import Metrics
from .models import ReplicaStatus, RouteDecision, SessionPin
from .replica_monitor import ReplicaMonitor
from .session_store import SessionStore

PRIMARY = "primary"
MILLIS_PER_SECOND = 1000.0


class ReadRouter:
    def __init__(self, config: RoutingConfig, monitor: ReplicaMonitor, sessions: SessionStore, clock: Clock, metrics: Metrics) -> None:
        self._config = config
        self._monitor = monitor
        self._sessions = sessions
        self._clock = clock
        self._metrics = metrics

    def route_read(self, session_id: str) -> RouteDecision:
        pin = self._active_pin(session_id)
        candidates = self._eligible_replicas()
        if pin is None:
            return self._pick_replica(candidates, None, "no_recent_write")
        caught_up = [status for status in candidates if status.applied_lsn >= pin.min_lsn]
        if caught_up:
            return self._pick_replica(caught_up, pin.min_lsn, "replica_caught_up")
        return self._primary(pin.min_lsn, "no_replica_caught_up")

    def _active_pin(self, session_id: str) -> Optional[SessionPin]:
        pin = self._sessions.get_pin(session_id)
        if pin is None:
            return None
        if self._clock.now() >= pin.expires_at:
            return None
        return pin

    def _eligible_replicas(self) -> List[ReplicaStatus]:
        eligible = []
        for status in self._monitor.statuses():
            if not status.healthy:
                continue
            if status.lag_seconds * MILLIS_PER_SECOND > self._config.max_replica_lag_ms:
                continue
            eligible.append(status)
        return eligible

    def _pick_replica(self, candidates: List[ReplicaStatus], min_lsn: Optional[int], reason: str) -> RouteDecision:
        if not candidates:
            return self._primary(min_lsn, "no_eligible_replica")
        best = min(candidates, key=lambda status: (status.lag_seconds, status.name))
        self._metrics.increment("route.replica")
        return RouteDecision(best.name, reason, min_lsn)

    def _primary(self, min_lsn: Optional[int], reason: str) -> RouteDecision:
        self._metrics.increment("route.primary")
        return RouteDecision(PRIMARY, reason, min_lsn)
