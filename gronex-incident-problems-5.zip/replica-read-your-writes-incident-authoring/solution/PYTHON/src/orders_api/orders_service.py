from typing import Dict, Optional

from .clock import Clock
from .config import RoutingConfig
from .database import PrimaryDatabase, ReplicaDatabase
from .metrics import Metrics
from .models import Order, RouteDecision, SessionPin
from .router import PRIMARY, ReadRouter
from .session_store import SessionStore


class OrdersService:
    def __init__(self, config: RoutingConfig, primary: PrimaryDatabase, replicas: Dict[str, ReplicaDatabase], router: ReadRouter, sessions: SessionStore, clock: Clock, metrics: Metrics) -> None:
        self._config = config
        self._primary = primary
        self._replicas = replicas
        self._router = router
        self._sessions = sessions
        self._clock = clock
        self._metrics = metrics

    def create_order(self, session_id: str, order: Order) -> Order:
        self._primary.begin()
        self._primary.insert_order(order)
        commit_lsn = self._primary.commit()
        self._pin_session(session_id, commit_lsn)
        self._metrics.increment("orders.created")
        return order

    def update_order(self, session_id: str, order: Order) -> Order:
        self._primary.begin()
        self._primary.update_order(order)
        commit_lsn = self._primary.commit()
        self._pin_session(session_id, commit_lsn)
        self._metrics.increment("orders.updated")
        return order

    def get_order(self, session_id: str, order_id: str) -> Optional[Order]:
        decision = self._router.route_read(session_id)
        return self._read_from(decision, order_id)

    def _read_from(self, decision: RouteDecision, order_id: str) -> Optional[Order]:
        if decision.target == PRIMARY:
            self._metrics.increment("reads.primary")
            return self._primary.get_order(order_id)
        self._metrics.increment("reads.replica")
        return self._replicas[decision.target].get_order(order_id)

    def _pin_session(self, session_id: str, min_lsn: int) -> None:
        expires_at = self._clock.now() + self._config.read_your_writes_window_s
        self._sessions.set_pin(session_id, SessionPin(min_lsn, expires_at))
