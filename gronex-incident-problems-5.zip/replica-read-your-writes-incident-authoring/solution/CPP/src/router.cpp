#include "router.hpp"

#include <algorithm>
#include <tuple>

ReadRouter::ReadRouter(const RoutingConfig& config, ReplicaMonitor& monitor, SessionStore& sessions, Clock& clock, Metrics& metrics)
    : config_(config), monitor_(monitor), sessions_(sessions), clock_(clock), metrics_(metrics) {}

RouteDecision ReadRouter::route_read(const std::string& session_id) {
    const std::optional<SessionPin> pin = active_pin(session_id);
    const std::vector<ReplicaStatus> candidates = eligible_replicas();
    if (!pin.has_value()) {
        return pick_replica(candidates, std::nullopt, "no_recent_write");
    }
    std::vector<ReplicaStatus> caught_up;
    for (const auto& status : candidates) {
        if (status.applied_lsn >= pin->min_lsn) {
            caught_up.push_back(status);
        }
    }
    if (!caught_up.empty()) {
        return pick_replica(caught_up, pin->min_lsn, "replica_caught_up");
    }
    return primary(pin->min_lsn, "no_replica_caught_up");
}

std::optional<SessionPin> ReadRouter::active_pin(const std::string& session_id) {
    const std::optional<SessionPin> pin = sessions_.get_pin(session_id);
    if (!pin.has_value()) {
        return std::nullopt;
    }
    if (clock_.now() >= pin->expires_at) {
        return std::nullopt;
    }
    return pin;
}

std::vector<ReplicaStatus> ReadRouter::eligible_replicas() {
    std::vector<ReplicaStatus> eligible;
    for (const auto& status : monitor_.statuses()) {
        if (!status.healthy) {
            continue;
        }
        if (status.lag_seconds * MILLIS_PER_SECOND > config_.max_replica_lag_ms) {
            continue;
        }
        eligible.push_back(status);
    }
    return eligible;
}

RouteDecision ReadRouter::pick_replica(const std::vector<ReplicaStatus>& candidates, std::optional<long long> min_lsn, const std::string& reason) {
    if (candidates.empty()) {
        return primary(min_lsn, "no_eligible_replica");
    }
    const auto best = std::min_element(candidates.begin(), candidates.end(), [](const ReplicaStatus& a, const ReplicaStatus& b) {
        return std::tie(a.lag_seconds, a.name) < std::tie(b.lag_seconds, b.name);
    });
    metrics_.increment("route.replica");
    return RouteDecision{best->name, reason, min_lsn};
}

RouteDecision ReadRouter::primary(std::optional<long long> min_lsn, const std::string& reason) {
    metrics_.increment("route.primary");
    return RouteDecision{PRIMARY, reason, min_lsn};
}
