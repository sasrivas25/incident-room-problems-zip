#pragma once

#include <optional>
#include <string>
#include <vector>

#include "clock.hpp"
#include "config.hpp"
#include "metrics.hpp"
#include "models.hpp"
#include "replica_monitor.hpp"
#include "session_store.hpp"

inline const std::string PRIMARY = "primary";
constexpr double MILLIS_PER_SECOND = 1000.0;

class ReadRouter {
public:
    ReadRouter(const RoutingConfig& config, ReplicaMonitor& monitor, SessionStore& sessions, Clock& clock, Metrics& metrics);

    RouteDecision route_read(const std::string& session_id);

private:
    std::optional<SessionPin> active_pin(const std::string& session_id);
    std::vector<ReplicaStatus> eligible_replicas();
    RouteDecision pick_replica(const std::vector<ReplicaStatus>& candidates, std::optional<long long> min_lsn, const std::string& reason);
    RouteDecision primary(std::optional<long long> min_lsn, const std::string& reason);

    RoutingConfig config_;
    ReplicaMonitor& monitor_;
    SessionStore& sessions_;
    Clock& clock_;
    Metrics& metrics_;
};
