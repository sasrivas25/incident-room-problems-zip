package com.gronex.orders;

import java.util.Map;

public class OrdersService {
    private final RoutingConfig config;
    private final PrimaryDatabase primary;
    private final Map<String, ? extends ReplicaDatabase> replicas;
    private final ReadRouter router;
    private final SessionStore sessions;
    private final Clock clock;
    private final Metrics metrics;

    public OrdersService(RoutingConfig config, PrimaryDatabase primary, Map<String, ? extends ReplicaDatabase> replicas, ReadRouter router, SessionStore sessions, Clock clock, Metrics metrics) {
        this.config = config;
        this.primary = primary;
        this.replicas = replicas;
        this.router = router;
        this.sessions = sessions;
        this.clock = clock;
        this.metrics = metrics;
    }

    public Order createOrder(String sessionId, Order order) {
        primary.begin();
        primary.insertOrder(order);
        long commitLsn = primary.commit();
        pinSession(sessionId, commitLsn);
        metrics.increment("orders.created");
        return order;
    }

    public Order updateOrder(String sessionId, Order order) {
        primary.begin();
        primary.updateOrder(order);
        long commitLsn = primary.commit();
        pinSession(sessionId, commitLsn);
        metrics.increment("orders.updated");
        return order;
    }

    public Order getOrder(String sessionId, String orderId) {
        RouteDecision decision = router.routeRead(sessionId);
        return readFrom(decision, orderId);
    }

    private Order readFrom(RouteDecision decision, String orderId) {
        if (ReadRouter.PRIMARY.equals(decision.target())) {
            metrics.increment("reads.primary");
            return primary.getOrder(orderId);
        }
        metrics.increment("reads.replica");
        return replicas.get(decision.target()).getOrder(orderId);
    }

    private void pinSession(String sessionId, long minLsn) {
        double expiresAt = clock.now() + config.readYourWritesWindowS();
        sessions.setPin(sessionId, new SessionPin(minLsn, expiresAt));
    }
}
