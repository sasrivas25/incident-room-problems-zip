'use strict';

const { makeRouteDecision } = require('./models');

const PRIMARY = 'primary';
const MILLIS_PER_SECOND = 1000.0;

class ReadRouter {
  constructor(config, monitor, sessions, clock, metrics) {
    this._config = config;
    this._monitor = monitor;
    this._sessions = sessions;
    this._clock = clock;
    this._metrics = metrics;
  }

  routeRead(sessionId) {
    const pin = this._activePin(sessionId);
    const candidates = this._eligibleReplicas();
    if (pin === null) {
      return this._pickReplica(candidates, null, 'no_recent_write');
    }
    const caughtUp = candidates.filter((status) => status.appliedLsn >= pin.minLsn);
    if (caughtUp.length > 0) {
      return this._pickReplica(caughtUp, pin.minLsn, 'replica_caught_up');
    }
    return this._primary(pin.minLsn, 'no_replica_caught_up');
  }

  _activePin(sessionId) {
    const pin = this._sessions.getPin(sessionId);
    if (pin === null) {
      return null;
    }
    if (this._clock.now() >= pin.expiresAt) {
      return null;
    }
    return pin;
  }

  _eligibleReplicas() {
    const eligible = [];
    for (const status of this._monitor.statuses()) {
      if (!status.healthy) {
        continue;
      }
      if (status.lagSeconds * MILLIS_PER_SECOND > this._config.maxReplicaLagMs) {
        continue;
      }
      eligible.push(status);
    }
    return eligible;
  }

  _pickReplica(candidates, minLsn, reason) {
    if (candidates.length === 0) {
      return this._primary(minLsn, 'no_eligible_replica');
    }
    const best = candidates.reduce((current, status) => (compareByLag(status, current) < 0 ? status : current));
    this._metrics.increment('route.replica');
    return makeRouteDecision(best.name, reason, minLsn);
  }

  _primary(minLsn, reason) {
    this._metrics.increment('route.primary');
    return makeRouteDecision(PRIMARY, reason, minLsn);
  }
}

function compareByLag(a, b) {
  if (a.lagSeconds !== b.lagSeconds) {
    return a.lagSeconds - b.lagSeconds;
  }
  if (a.name < b.name) {
    return -1;
  }
  if (a.name > b.name) {
    return 1;
  }
  return 0;
}

module.exports = { PRIMARY, MILLIS_PER_SECOND, ReadRouter };
