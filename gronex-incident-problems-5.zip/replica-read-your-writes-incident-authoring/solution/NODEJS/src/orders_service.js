'use strict';

const { makeSessionPin } = require('./models');
const { PRIMARY } = require('./router');

class OrdersService {
  constructor(config, primary, replicas, router, sessions, clock, metrics) {
    this._config = config;
    this._primary = primary;
    this._replicas = replicas;
    this._router = router;
    this._sessions = sessions;
    this._clock = clock;
    this._metrics = metrics;
  }

  createOrder(sessionId, order) {
    this._primary.begin();
    this._primary.insertOrder(order);
    const commitLsn = this._primary.commit();
    this._pinSession(sessionId, commitLsn);
    this._metrics.increment('orders.created');
    return order;
  }

  updateOrder(sessionId, order) {
    this._primary.begin();
    this._primary.updateOrder(order);
    const commitLsn = this._primary.commit();
    this._pinSession(sessionId, commitLsn);
    this._metrics.increment('orders.updated');
    return order;
  }

  getOrder(sessionId, orderId) {
    const decision = this._router.routeRead(sessionId);
    return this._readFrom(decision, orderId);
  }

  _readFrom(decision, orderId) {
    if (decision.target === PRIMARY) {
      this._metrics.increment('reads.primary');
      return this._primary.getOrder(orderId);
    }
    this._metrics.increment('reads.replica');
    return this._replicas.get(decision.target).getOrder(orderId);
  }

  _pinSession(sessionId, minLsn) {
    const expiresAt = this._clock.now() + this._config.readYourWritesWindowS;
    this._sessions.setPin(sessionId, makeSessionPin(minLsn, expiresAt));
  }
}

module.exports = { OrdersService };
