#!/usr/bin/env python3
"""Render Grafana-styled PNG dashboards from the generated CSVs."""
import csv
import os
from datetime import datetime

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
METRICS = os.path.join(os.path.dirname(HERE), "replica-read-your-writes-incident", "PYTHON", "metrics")
OUT = os.path.join(HERE, "images")
os.makedirs(OUT, exist_ok=True)


def load(name):
    with open(os.path.join(METRICS, name)) as f:
        rows = list(csv.DictReader(f))
    times = [datetime.strptime(r["timestamp"], "%Y-%m-%dT%H:%M:%S.%fZ") for r in rows]
    return times, rows


EVENTS = [
    ("2026-10-30T09:11:05", "replica-b lag begins", "#9aa0a6", ":"),
    ("2026-10-30T09:11:40", "alert replica_lag", "#f2495c", ":"),
    ("2026-10-30T09:14:02", "deploy r2 start", "#ff9830", "-"),
    ("2026-10-30T09:16:30", "rollout complete", "#ff9830", "--"),
    ("2026-10-30T09:17:20", "alert order_not_found_after_create", "#f2495c", "-"),
    ("2026-10-30T09:29:04", "replica-b recovered", "#9aa0a6", "--"),
]


def style(ax, title, unit=""):
    ax.set_facecolor("#181b1f")
    ax.set_title(title, loc="left", fontsize=11, color="#d8d9da", pad=6)
    ax.grid(color="#2c3235", linewidth=0.6)
    ax.tick_params(colors="#9aa0a6", labelsize=8)
    for s in ax.spines.values():
        s.set_color("#2c3235")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    ax.xaxis.set_major_locator(mdates.MinuteLocator(interval=5))
    if unit:
        ax.set_ylabel(unit, color="#9aa0a6", fontsize=8)


def annotate(ax):
    for when, label, color, ls in EVENTS:
        ax.axvline(datetime.strptime(when, "%Y-%m-%dT%H:%M:%S"), color=color, linestyle=ls, linewidth=1.1, alpha=0.9)


def legend_events(fig):
    handles = [plt.Line2D([0], [0], color=c, linestyle=ls, label=l) for _, l, c, ls in EVENTS]
    fig.legend(handles=handles, loc="lower center", ncol=3, fontsize=8, frameon=False, labelcolor="#d8d9da")


def fig_traffic():
    times, rows = load("traffic.csv")
    _, rrows = load("routing.csv")
    fig, axes = plt.subplots(4, 1, figsize=(13, 10), sharex=True)
    fig.patch.set_facecolor("#111217")
    fig.suptitle("orders-api  |  2026-10-30 09:00-09:35 UTC  |  traffic and routing", color="#d8d9da", fontsize=13, x=0.02, ha="left")
    ax = axes[0]; style(ax, "Read and write rate", "req/s")
    ax.plot(times, [float(r["requests_per_s"]) for r in rows], color="#73bf69", linewidth=1.4, label="reads")
    ax.plot(times, [float(r["writes_per_s"]) for r in rows], color="#5794f2", linewidth=1.2, label="writes")
    ax.set_yscale("log"); ax.legend(fontsize=8, frameon=False, labelcolor="#d8d9da", loc="center left"); annotate(ax)
    ax = axes[1]; style(ax, "Order not found within 2 s of create (ratio of creates)", "ratio")
    ax.plot(times, [float(r["not_found_after_create_ratio"]) for r in rows], color="#fade2a", linewidth=1.4)
    ax.axhline(0.010, color="#f2495c", linewidth=0.8, linestyle="--"); annotate(ax)
    ax = axes[2]; style(ax, "Share of reads routed to the primary", "ratio")
    ax.plot(times, [float(r["primary_read_share"]) for r in rrows], color="#b877d9", linewidth=1.4)
    ax.axhspan(0.10, 0.15, color="#73bf69", alpha=0.12); ax.text(times[2], 0.155, "expected band 10-15%", color="#73bf69", fontsize=8); annotate(ax)
    ax = axes[3]; style(ax, "HTTP 5xx ratio", "ratio")
    ax.plot(times, [float(r["http_5xx_ratio"]) for r in rows], color="#f2495c", linewidth=1.2); ax.set_ylim(-0.001, 0.01); annotate(ax)
    legend_events(fig)
    fig.tight_layout(rect=(0, 0.06, 1, 0.96))
    fig.savefig(os.path.join(OUT, "dashboard-traffic.png"), dpi=130, facecolor=fig.get_facecolor())


def fig_db():
    times, rows = load("routing.csv")
    fig, axes = plt.subplots(2, 1, figsize=(13, 7), sharex=True)
    fig.patch.set_facecolor("#111217")
    fig.suptitle("orders-api database  |  2026-10-30 09:00-09:35 UTC", color="#d8d9da", fontsize=13, x=0.02, ha="left")
    ax = axes[0]; style(ax, "Replication lag", "seconds")
    ax.plot(times, [float(r["replica_a_lag_s"]) for r in rows], color="#73bf69", linewidth=1.4, label="replica-a")
    ax.plot(times, [float(r["replica_b_lag_s"]) for r in rows], color="#ff9830", linewidth=1.4, label="replica-b")
    ax.axhline(1.0, color="#f2495c", linewidth=0.8, linestyle="--"); ax.axhline(0.2, color="#9aa0a6", linewidth=0.8, linestyle=":")
    ax.text(times[2], 0.23, "max_replica_lag_ms = 200", color="#9aa0a6", fontsize=8)
    ax.legend(fontsize=8, frameon=False, labelcolor="#d8d9da", loc="upper left"); annotate(ax)
    ax = axes[1]; style(ax, "Primary CPU", "%")
    ax.plot(times, [float(r["primary_cpu_pct"]) for r in rows], color="#5794f2", linewidth=1.4); ax.set_ylim(0, 100); annotate(ax)
    legend_events(fig)
    fig.tight_layout(rect=(0, 0.08, 1, 0.95))
    fig.savefig(os.path.join(OUT, "dashboard-database.png"), dpi=130, facecolor=fig.get_facecolor())


if __name__ == "__main__":
    fig_traffic()
    fig_db()
    print("wrote", sorted(os.listdir(OUT)))
