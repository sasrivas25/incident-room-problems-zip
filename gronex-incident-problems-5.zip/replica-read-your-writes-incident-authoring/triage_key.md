# Triage marking key: Read-Your-Writes Broken by Replica Routing (30 points)

## Canonical root cause

Deploy `2026.10.30-r2` (ORD-2210) replaced the five-second primary pin with LSN-aware read routing, and the new router violates read-your-writes in three ways that compound: it compares replica lag in seconds against a threshold in milliseconds, so lagging replicas stay eligible; when no replica has applied the session's commit position it still routes the read to the least-lagging replica instead of the primary; and the position it pins is read before the commit record, so a replica standing exactly at that position is wrongly judged caught up. The result is reads served by replicas that do not yet have the write: 404 after checkout and stale status after a warehouse update.

Full credit requires naming the routing fallback (reads for pinned sessions go to a replica that has not applied the write) as the mechanism. Naming only the unit bug, or only "the deploy changed routing", is partial.

## Evidence that proves it

Quote any two for full evidence credit, at least one from app.log.

1. `logs/app.log` 09:16:41.907: `route session=s-7f3a pin=min_lsn=0/8342C0 ... replica-a[lsn=0/834180 lag=0.02s ... caught_up=false] replica-b[lsn=0/833040 lag=1.82s ... eligible=true caught_up=false] -> replica-a reason=least_lagging_replica` followed by `GET /v1/orders/o-88213 status=404 route=replica-a`. Shows a pinned read sent to a replica that has not caught up, and a 1.82 s replica marked eligible against a 200 ms threshold.
2. `logs/app.log` 09:18:12.427: replica-a `lsn=0/86FA80` equals `pin_lsn=0/86FA80`, `caught_up=true`, `reason=replica_caught_up`, then `status=404`. With `logs/db.log` 09:18:12.021 `COMMIT ... commit_lsn=0/86FAC0`: the pin is one commit record short of the real commit position.
3. `logs/app.log` 09:11:08 to 09:11:46: r1 pods log `replica-b excluded from read pool: lag=... above max_replica_lag_ms=200`; after 09:14:02 no r2 pod ever excludes it and every route line shows `lag=1.8s ... eligible=true`.
4. `logs/app.log` 09:21:10: `PUT ... body.status=SHIPPED` then the same session's `GET ... status=200 body.status=PLACED route=replica-a`. Stale read, not only not-found.
5. `metrics/routing.csv`, `dashboard.md`: primary read share falls from 0.12 to about 0.003 as r2 pods come up and never recovers, while pinned sessions exist. This clue is only in the metrics.
6. `metrics/traffic.csv`: `not_found_after_create_ratio` is zero before 09:14:02 despite replica-b lagging since 09:11:05; it rises with the first r2 pod; after replica-b recovers at 09:29:04 it falls to about 0.012, not zero.
7. `logs/deploy.log` 09:16:35: the rollout controller marks SUCCESS on `primary_read_share=0.004 (target <0.01)`, the very number that proves pinned reads are no longer protected.

## Red herring

The replica-b lag: `recovery conflict ... delaying replay` in db.log, the `replica_lag` alert at 09:11:40, and the monitor timeout stack trace at 09:12:31 that passes through the router. Why it is wrong: the lag started three minutes before the deploy with zero not-found errors; the r1 router excluded the replica; the lag ended at 09:29:04 and the 404s continued; a stale replica can only hurt if the router sends it reads it cannot serve. The stack trace is a handled timeout and the request completed with cached statuses.

## Acceptable mitigations (first action)

- Roll back to r1 (restores the five-second primary pin; about 3 minutes). Best answer; the contestant should note the primary read share returns to 12 percent, which is within budget.
- Remove both replicas from `replica_names` or set `max_replica_lag_ms` to a value that excludes everything, so reads go to the primary. Acceptable with the caveat that primary CPU must be watched; full credit only if the primary capacity (sized for 15 percent of reads, saturates at 30) is mentioned.
- Cancel the analytics query on replica-b: partial credit at most. It removes the loud symptom, not the routing fault; the 404 floor remains.
- Scale the primary or add replicas: zero.

## Rubric

| Component | Points | Full credit | Partial | Zero |
| --- | --- | --- | --- | --- |
| Root cause | 15 | r2 routes pinned reads to replicas that have not applied the write (fallback to least-lagging replica), with the unit mismatch and/or the pre-commit pin position as aggravators. (15) | Names the deploy and "replicas serving stale reads" without the fallback mechanism, or names only the unit bug. (7-9) | Blames replica-b lag, the analytics query, or the monitor timeout. (0-2) |
| Evidence | 10 | Two or more concrete items from the list, including a route decision line showing a pinned read sent to a replica with `caught_up=false` or the pin/commit LSN gap. (10) | One correct item, or only symptom-level evidence (the 404 alert, the support complaint). (4-6) | Only the lag alert, the db.log recovery conflict or the stack trace. (0) |
| Mitigation | 5 | Rollback, with the primary read share consequence stated. (5) | Routing every read to the primary via config without mentioning capacity, or cancelling the analytics query. (2-3) | Scaling, restarting replicas, raising the lag alert threshold. (0) |

### Worked examples

- Full credit (30): "r2 broke read-your-writes: when no replica has the session's commit LSN it still picks the least-lagging replica (09:16:41 route line, caught_up=false, then 404), the lag check compares seconds to milliseconds so replica-b at 1.82 s is eligible, and the pin uses the pre-commit position (09:18:12: replica-a at 0/86FA80 equals pin, db.log commit 0/86FAC0, still 404). Lag started at 09:11 with no 404s and ended at 09:29 with 404s continuing. Roll back to r1; primary share goes back to 12 percent, within budget."
- Partial (about 17): "The deploy's LSN routing is sending reads to lagging replicas. Evidence: 404 alert at 09:17 and the replica_lag alert. Mitigation: cancel the analytics query and roll back." Root cause 9, evidence 4, mitigation 4.
- Correct symptom, wrong cause (about 4): "replica-b is lagging because of a conflicting query, so reads hit a stale replica and 404. Evidence: db.log recovery conflicts, the lag alert, the monitor timeout trace. Mitigation: cancel the query." Root cause 2, evidence 0, mitigation 2.
- Named only the red herring (0-2): "Replication lag on replica-b caused by autovacuum or the analytics job." Root cause 0, evidence 0, mitigation 0-2.
