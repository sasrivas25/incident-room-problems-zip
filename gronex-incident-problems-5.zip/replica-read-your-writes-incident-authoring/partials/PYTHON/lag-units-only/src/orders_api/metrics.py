class Metrics:
    def __init__(self) -> None:
        self._counters: dict = {}

    def increment(self, name: str, amount: int = 1) -> None:
        self._counters[name] = self._counters.get(name, 0) + amount

    def value(self, name: str) -> int:
        return self._counters.get(name, 0)
