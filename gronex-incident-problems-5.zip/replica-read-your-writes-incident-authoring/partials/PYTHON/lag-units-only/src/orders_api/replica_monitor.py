from typing import List

from .models import ReplicaStatus


class ReplicaMonitor:
    def statuses(self) -> List[ReplicaStatus]:
        raise NotImplementedError
