from dataclasses import dataclass

from .models import Order
from .orders_service import OrdersService


@dataclass(frozen=True)
class ApiResponse:
    status: int
    body: dict


class OrdersApi:
    def __init__(self, service: OrdersService) -> None:
        self._service = service

    def create_order(self, session_id: str, order_id: str, customer_id: str, total_cents: int) -> ApiResponse:
        if total_cents <= 0 or not order_id or not customer_id:
            return ApiResponse(400, {"error": "invalid_order"})
        order = self._service.create_order(session_id, Order(order_id, customer_id, total_cents, "PLACED"))
        return ApiResponse(201, {"order_id": order.order_id, "location": f"/v1/orders/{order.order_id}"})

    def get_order(self, session_id: str, order_id: str) -> ApiResponse:
        try:
            order = self._service.get_order(session_id, order_id)
        except Exception:
            return ApiResponse(500, {"error": "internal"})
        if order is None:
            return ApiResponse(404, {"error": "not_found"})
        return ApiResponse(200, {"order_id": order.order_id, "customer_id": order.customer_id, "total_cents": order.total_cents, "status": order.status})
