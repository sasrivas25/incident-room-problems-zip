from dataclasses import dataclass


@dataclass(frozen=True)
class RoutingConfig:
    max_replica_lag_ms: int = 200
    read_your_writes_window_s: int = 5
    replica_names: tuple = ("replica-a", "replica-b")

    @staticmethod
    def from_dict(values: dict) -> "RoutingConfig":
        return RoutingConfig(
            max_replica_lag_ms=int(values.get("max_replica_lag_ms", 200)),
            read_your_writes_window_s=int(values.get("read_your_writes_window_s", 5)),
            replica_names=tuple(values.get("replica_names", ("replica-a", "replica-b"))),
        )
