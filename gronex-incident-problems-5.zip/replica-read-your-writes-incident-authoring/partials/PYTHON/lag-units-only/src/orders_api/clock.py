class Clock:
    def now(self) -> float:
        raise NotImplementedError
