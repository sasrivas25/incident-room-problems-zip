from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Order:
    order_id: str
    customer_id: str
    total_cents: int
    status: str


@dataclass(frozen=True)
class ReplicaStatus:
    name: str
    applied_lsn: int
    lag_seconds: float
    healthy: bool


@dataclass(frozen=True)
class SessionPin:
    min_lsn: int
    expires_at: float


@dataclass(frozen=True)
class RouteDecision:
    target: str
    reason: str
    min_lsn: Optional[int]
