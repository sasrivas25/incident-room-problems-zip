from typing import Optional

from .models import Order


class PrimaryDatabase:
    def begin(self) -> None:
        raise NotImplementedError

    def insert_order(self, order: Order) -> None:
        raise NotImplementedError

    def update_order(self, order: Order) -> None:
        raise NotImplementedError

    def current_lsn(self) -> int:
        raise NotImplementedError

    def commit(self) -> int:
        raise NotImplementedError

    def get_order(self, order_id: str) -> Optional[Order]:
        raise NotImplementedError


class ReplicaDatabase:
    def name(self) -> str:
        raise NotImplementedError

    def get_order(self, order_id: str) -> Optional[Order]:
        raise NotImplementedError
