LSN_SEGMENT_SIZE = 0x100000000


def format_lsn(value: int) -> str:
    return f"{value // LSN_SEGMENT_SIZE:X}/{value % LSN_SEGMENT_SIZE:X}"


def parse_lsn(text: str) -> int:
    high, low = text.split("/")
    return int(high, 16) * LSN_SEGMENT_SIZE + int(low, 16)
