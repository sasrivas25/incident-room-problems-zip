from typing import Optional

from .models import SessionPin


class SessionStore:
    def get_pin(self, session_id: str) -> Optional[SessionPin]:
        raise NotImplementedError

    def set_pin(self, session_id: str, pin: SessionPin) -> None:
        raise NotImplementedError
