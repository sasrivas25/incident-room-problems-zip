#pragma once

#include <map>
#include <string>
#include <vector>

struct RoutingConfig {
    int max_replica_lag_ms = 200;
    int read_your_writes_window_s = 5;
    std::vector<std::string> replica_names = {"replica-a", "replica-b"};

    static RoutingConfig from_map(const std::map<std::string, std::string>& values);
};
