#pragma once

#include <string>

constexpr long long LSN_SEGMENT_SIZE = 0x100000000LL;

std::string format_lsn(long long value);

long long parse_lsn(const std::string& text);
