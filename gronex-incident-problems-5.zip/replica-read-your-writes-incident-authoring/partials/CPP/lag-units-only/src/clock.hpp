#pragma once

class Clock {
public:
    virtual ~Clock() = default;
    virtual double now() = 0;
};
