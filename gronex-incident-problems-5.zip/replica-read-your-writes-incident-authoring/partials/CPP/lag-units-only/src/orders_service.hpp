#pragma once

#include <map>
#include <optional>
#include <string>

#include "clock.hpp"
#include "config.hpp"
#include "database.hpp"
#include "metrics.hpp"
#include "models.hpp"
#include "router.hpp"
#include "session_store.hpp"

class OrdersService {
public:
    OrdersService(const RoutingConfig& config, PrimaryDatabase& primary, const std::map<std::string, ReplicaDatabase*>& replicas,
                  ReadRouter& router, SessionStore& sessions, Clock& clock, Metrics& metrics);

    Order create_order(const std::string& session_id, const Order& order);
    Order update_order(const std::string& session_id, const Order& order);
    std::optional<Order> get_order(const std::string& session_id, const std::string& order_id);

private:
    std::optional<Order> read_from(const RouteDecision& decision, const std::string& order_id);
    void pin_session(const std::string& session_id, long long min_lsn);

    RoutingConfig config_;
    PrimaryDatabase& primary_;
    std::map<std::string, ReplicaDatabase*> replicas_;
    ReadRouter& router_;
    SessionStore& sessions_;
    Clock& clock_;
    Metrics& metrics_;
};
