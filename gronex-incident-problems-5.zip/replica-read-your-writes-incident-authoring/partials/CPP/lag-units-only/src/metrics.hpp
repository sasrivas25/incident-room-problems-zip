#pragma once

#include <map>
#include <string>

class Metrics {
public:
    void increment(const std::string& name, int amount = 1) { counters_[name] += amount; }

    int value(const std::string& name) const {
        auto it = counters_.find(name);
        return it == counters_.end() ? 0 : it->second;
    }

private:
    std::map<std::string, int> counters_;
};
