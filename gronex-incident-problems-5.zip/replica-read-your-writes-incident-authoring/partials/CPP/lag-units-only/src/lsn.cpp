#include "lsn.hpp"

#include <sstream>

std::string format_lsn(long long value) {
    std::ostringstream out;
    out << std::hex << std::uppercase << (value / LSN_SEGMENT_SIZE) << "/" << (value % LSN_SEGMENT_SIZE);
    return out.str();
}

long long parse_lsn(const std::string& text) {
    const auto slash = text.find('/');
    const std::string high = text.substr(0, slash);
    const std::string low = text.substr(slash + 1);
    return std::stoll(high, nullptr, 16) * LSN_SEGMENT_SIZE + std::stoll(low, nullptr, 16);
}
