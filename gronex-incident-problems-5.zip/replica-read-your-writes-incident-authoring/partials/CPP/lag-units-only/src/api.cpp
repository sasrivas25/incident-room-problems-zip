#include "api.hpp"

#include <exception>
#include <optional>

OrdersApi::OrdersApi(OrdersService& service) : service_(service) {}

ApiResponse OrdersApi::create_order(const std::string& session_id, const std::string& order_id, const std::string& customer_id, int total_cents) {
    if (total_cents <= 0 || order_id.empty() || customer_id.empty()) {
        return ApiResponse{400, {{"error", "invalid_order"}}};
    }
    const Order order = service_.create_order(session_id, Order{order_id, customer_id, total_cents, "PLACED"});
    return ApiResponse{201, {{"order_id", order.order_id}, {"location", "/v1/orders/" + order.order_id}}};
}

ApiResponse OrdersApi::get_order(const std::string& session_id, const std::string& order_id) {
    std::optional<Order> order;
    try {
        order = service_.get_order(session_id, order_id);
    } catch (const std::exception&) {
        return ApiResponse{500, {{"error", "internal"}}};
    }
    if (!order.has_value()) {
        return ApiResponse{404, {{"error", "not_found"}}};
    }
    return ApiResponse{200, {
        {"order_id", order->order_id},
        {"customer_id", order->customer_id},
        {"total_cents", std::to_string(order->total_cents)},
        {"status", order->status},
    }};
}
