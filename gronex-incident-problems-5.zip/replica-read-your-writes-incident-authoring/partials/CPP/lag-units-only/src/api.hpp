#pragma once

#include <map>
#include <string>

#include "orders_service.hpp"

struct ApiResponse {
    int status;
    std::map<std::string, std::string> body;
};

class OrdersApi {
public:
    explicit OrdersApi(OrdersService& service);

    ApiResponse create_order(const std::string& session_id, const std::string& order_id, const std::string& customer_id, int total_cents);
    ApiResponse get_order(const std::string& session_id, const std::string& order_id);

private:
    OrdersService& service_;
};
