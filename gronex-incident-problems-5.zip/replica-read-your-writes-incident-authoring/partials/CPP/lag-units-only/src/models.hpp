#pragma once

#include <optional>
#include <string>

struct Order {
    std::string order_id;
    std::string customer_id;
    int total_cents;
    std::string status;

    bool operator==(const Order& other) const {
        return order_id == other.order_id && customer_id == other.customer_id && total_cents == other.total_cents &&
               status == other.status;
    }

    bool operator!=(const Order& other) const { return !(*this == other); }
};

struct ReplicaStatus {
    std::string name;
    long long applied_lsn;
    double lag_seconds;
    bool healthy;
};

struct SessionPin {
    long long min_lsn;
    double expires_at;
};

struct RouteDecision {
    std::string target;
    std::string reason;
    std::optional<long long> min_lsn;
};
