#pragma once

#include <optional>
#include <string>

#include "models.hpp"

class PrimaryDatabase {
public:
    virtual ~PrimaryDatabase() = default;
    virtual void begin() = 0;
    virtual void insert_order(const Order& order) = 0;
    virtual void update_order(const Order& order) = 0;
    virtual long long current_lsn() = 0;
    virtual long long commit() = 0;
    virtual std::optional<Order> get_order(const std::string& order_id) = 0;
};

class ReplicaDatabase {
public:
    virtual ~ReplicaDatabase() = default;
    virtual std::string name() const = 0;
    virtual std::optional<Order> get_order(const std::string& order_id) = 0;
};
