#pragma once

#include <vector>

#include "models.hpp"

class ReplicaMonitor {
public:
    virtual ~ReplicaMonitor() = default;
    virtual std::vector<ReplicaStatus> statuses() = 0;
};
