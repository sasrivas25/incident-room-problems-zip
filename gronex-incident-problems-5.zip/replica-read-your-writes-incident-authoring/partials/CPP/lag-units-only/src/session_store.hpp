#pragma once

#include <optional>
#include <string>

#include "models.hpp"

class SessionStore {
public:
    virtual ~SessionStore() = default;
    virtual std::optional<SessionPin> get_pin(const std::string& session_id) = 0;
    virtual void set_pin(const std::string& session_id, const SessionPin& pin) = 0;
};
