#include "orders_service.hpp"

OrdersService::OrdersService(const RoutingConfig& config, PrimaryDatabase& primary, const std::map<std::string, ReplicaDatabase*>& replicas,
                             ReadRouter& router, SessionStore& sessions, Clock& clock, Metrics& metrics)
    : config_(config), primary_(primary), replicas_(replicas), router_(router), sessions_(sessions), clock_(clock), metrics_(metrics) {}

Order OrdersService::create_order(const std::string& session_id, const Order& order) {
    primary_.begin();
    primary_.insert_order(order);
    const long long commit_lsn = primary_.current_lsn();
    primary_.commit();
    pin_session(session_id, commit_lsn);
    metrics_.increment("orders.created");
    return order;
}

Order OrdersService::update_order(const std::string& session_id, const Order& order) {
    primary_.begin();
    primary_.update_order(order);
    const long long commit_lsn = primary_.current_lsn();
    primary_.commit();
    pin_session(session_id, commit_lsn);
    metrics_.increment("orders.updated");
    return order;
}

std::optional<Order> OrdersService::get_order(const std::string& session_id, const std::string& order_id) {
    const RouteDecision decision = router_.route_read(session_id);
    return read_from(decision, order_id);
}

std::optional<Order> OrdersService::read_from(const RouteDecision& decision, const std::string& order_id) {
    if (decision.target == PRIMARY) {
        metrics_.increment("reads.primary");
        return primary_.get_order(order_id);
    }
    metrics_.increment("reads.replica");
    return replicas_.at(decision.target)->get_order(order_id);
}

void OrdersService::pin_session(const std::string& session_id, long long min_lsn) {
    const double expires_at = clock_.now() + config_.read_your_writes_window_s;
    sessions_.set_pin(session_id, SessionPin{min_lsn, expires_at});
}
