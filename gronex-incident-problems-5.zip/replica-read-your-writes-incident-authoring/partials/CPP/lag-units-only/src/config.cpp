#include "config.hpp"

#include <sstream>

namespace {

std::string get_or(const std::map<std::string, std::string>& values, const std::string& key, const std::string& fallback) {
    auto it = values.find(key);
    return it == values.end() ? fallback : it->second;
}

std::vector<std::string> split_names(const std::string& text) {
    std::vector<std::string> names;
    std::istringstream in(text);
    std::string part;
    while (std::getline(in, part, ',')) {
        if (!part.empty()) {
            names.push_back(part);
        }
    }
    return names;
}

}

RoutingConfig RoutingConfig::from_map(const std::map<std::string, std::string>& values) {
    RoutingConfig config;
    config.max_replica_lag_ms = std::stoi(get_or(values, "max_replica_lag_ms", "200"));
    config.read_your_writes_window_s = std::stoi(get_or(values, "read_your_writes_window_s", "5"));
    config.replica_names = split_names(get_or(values, "replica_names", "replica-a,replica-b"));
    return config;
}
