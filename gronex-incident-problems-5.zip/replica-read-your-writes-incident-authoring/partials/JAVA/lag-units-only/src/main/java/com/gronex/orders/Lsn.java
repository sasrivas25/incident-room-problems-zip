package com.gronex.orders;

public final class Lsn {
    public static final long LSN_SEGMENT_SIZE = 0x100000000L;

    private Lsn() {
    }

    public static String formatLsn(long value) {
        return Long.toHexString(value / LSN_SEGMENT_SIZE).toUpperCase() + "/" + Long.toHexString(value % LSN_SEGMENT_SIZE).toUpperCase();
    }

    public static long parseLsn(String text) {
        String[] parts = text.split("/");
        return Long.parseLong(parts[0], 16) * LSN_SEGMENT_SIZE + Long.parseLong(parts[1], 16);
    }
}
