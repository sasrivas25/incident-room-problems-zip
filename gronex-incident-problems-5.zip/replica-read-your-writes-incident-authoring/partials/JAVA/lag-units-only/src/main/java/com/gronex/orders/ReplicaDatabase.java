package com.gronex.orders;

public interface ReplicaDatabase {
    String name();

    Order getOrder(String orderId);
}
