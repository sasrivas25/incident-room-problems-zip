package com.gronex.orders;

public interface Clock {
    double now();
}
