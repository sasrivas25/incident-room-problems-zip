package com.gronex.orders;

public record SessionPin(long minLsn, double expiresAt) {
}
