package com.gronex.orders;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ReadRouter {
    public static final String PRIMARY = "primary";

    private final RoutingConfig config;
    private final ReplicaMonitor monitor;
    private final SessionStore sessions;
    private final Clock clock;
    private final Metrics metrics;

    public ReadRouter(RoutingConfig config, ReplicaMonitor monitor, SessionStore sessions, Clock clock, Metrics metrics) {
        this.config = config;
        this.monitor = monitor;
        this.sessions = sessions;
        this.clock = clock;
        this.metrics = metrics;
    }

    public RouteDecision routeRead(String sessionId) {
        SessionPin pin = activePin(sessionId);
        List<ReplicaStatus> candidates = eligibleReplicas();
        if (pin == null) {
            return pickReplica(candidates, null, "no_recent_write");
        }
        List<ReplicaStatus> caughtUp = new ArrayList<>();
        for (ReplicaStatus status : candidates) {
            if (status.appliedLsn() >= pin.minLsn()) {
                caughtUp.add(status);
            }
        }
        if (!caughtUp.isEmpty()) {
            return pickReplica(caughtUp, pin.minLsn(), "replica_caught_up");
        }
        return pickReplica(candidates, pin.minLsn(), "least_lagging_replica");
    }

    private SessionPin activePin(String sessionId) {
        SessionPin pin = sessions.getPin(sessionId);
        if (pin == null) {
            return null;
        }
        if (clock.now() >= pin.expiresAt()) {
            return null;
        }
        return pin;
    }

    private List<ReplicaStatus> eligibleReplicas() {
        List<ReplicaStatus> eligible = new ArrayList<>();
        for (ReplicaStatus status : monitor.statuses()) {
            if (!status.healthy()) {
                continue;
            }
            if (status.lagSeconds() * 1000.0 > config.maxReplicaLagMs()) {
                continue;
            }
            eligible.add(status);
        }
        return eligible;
    }

    private RouteDecision pickReplica(List<ReplicaStatus> candidates, Long minLsn, String reason) {
        if (candidates.isEmpty()) {
            metrics.increment("route.primary");
            return new RouteDecision(PRIMARY, "no_eligible_replica", minLsn);
        }
        ReplicaStatus best = Collections.min(candidates, Comparator.comparingDouble(ReplicaStatus::lagSeconds).thenComparing(ReplicaStatus::name));
        metrics.increment("route.replica");
        return new RouteDecision(best.name(), reason, minLsn);
    }
}
