package com.gronex.orders;

public record RouteDecision(String target, String reason, Long minLsn) {
}
