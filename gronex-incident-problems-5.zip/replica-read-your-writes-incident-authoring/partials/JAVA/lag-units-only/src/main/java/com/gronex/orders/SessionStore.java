package com.gronex.orders;

public interface SessionStore {
    SessionPin getPin(String sessionId);

    void setPin(String sessionId, SessionPin pin);
}
