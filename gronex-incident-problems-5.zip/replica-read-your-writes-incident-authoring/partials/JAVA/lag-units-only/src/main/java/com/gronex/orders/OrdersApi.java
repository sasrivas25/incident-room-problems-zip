package com.gronex.orders;

import java.util.Map;

public class OrdersApi {
    private final OrdersService service;

    public OrdersApi(OrdersService service) {
        this.service = service;
    }

    public ApiResponse createOrder(String sessionId, String orderId, String customerId, int totalCents) {
        if (totalCents <= 0 || orderId == null || orderId.isEmpty() || customerId == null || customerId.isEmpty()) {
            return new ApiResponse(400, Map.of("error", "invalid_order"));
        }
        Order order = service.createOrder(sessionId, new Order(orderId, customerId, totalCents, "PLACED"));
        return new ApiResponse(201, Map.of("order_id", order.orderId(), "location", "/v1/orders/" + order.orderId()));
    }

    public ApiResponse getOrder(String sessionId, String orderId) {
        Order order;
        try {
            order = service.getOrder(sessionId, orderId);
        } catch (Exception e) {
            return new ApiResponse(500, Map.of("error", "internal"));
        }
        if (order == null) {
            return new ApiResponse(404, Map.of("error", "not_found"));
        }
        return new ApiResponse(200, Map.of("order_id", order.orderId(), "customer_id", order.customerId(), "total_cents", order.totalCents(), "status", order.status()));
    }
}
