package com.gronex.orders;

import java.util.List;

public interface ReplicaMonitor {
    List<ReplicaStatus> statuses();
}
