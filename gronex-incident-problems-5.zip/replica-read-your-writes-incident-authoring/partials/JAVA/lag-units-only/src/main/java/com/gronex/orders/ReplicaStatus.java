package com.gronex.orders;

public record ReplicaStatus(String name, long appliedLsn, double lagSeconds, boolean healthy) {
}
