package com.gronex.orders;

import java.util.Map;

public record ApiResponse(int status, Map<String, Object> body) {
}
