package com.gronex.orders;

public record Order(String orderId, String customerId, int totalCents, String status) {
}
