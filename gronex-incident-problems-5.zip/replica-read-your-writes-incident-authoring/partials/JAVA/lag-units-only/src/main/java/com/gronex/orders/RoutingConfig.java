package com.gronex.orders;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public record RoutingConfig(int maxReplicaLagMs, int readYourWritesWindowS, List<String> replicaNames) {

    public RoutingConfig {
        replicaNames = List.copyOf(replicaNames);
    }

    public static RoutingConfig defaults() {
        return new RoutingConfig(200, 5, List.of("replica-a", "replica-b"));
    }

    public static RoutingConfig fromMap(Map<String, Object> values) {
        return new RoutingConfig(
                toInt(values.getOrDefault("max_replica_lag_ms", 200)),
                toInt(values.getOrDefault("read_your_writes_window_s", 5)),
                toNames(values.getOrDefault("replica_names", List.of("replica-a", "replica-b"))));
    }

    public RoutingConfig withMaxReplicaLagMs(int value) {
        return new RoutingConfig(value, readYourWritesWindowS, replicaNames);
    }

    public RoutingConfig withReadYourWritesWindowS(int value) {
        return new RoutingConfig(maxReplicaLagMs, value, replicaNames);
    }

    public RoutingConfig withReplicaNames(List<String> value) {
        return new RoutingConfig(maxReplicaLagMs, readYourWritesWindowS, value);
    }

    private static int toInt(Object value) {
        if (value instanceof Number number) {
            return number.intValue();
        }
        return Integer.parseInt(String.valueOf(value));
    }

    private static List<String> toNames(Object value) {
        List<String> names = new ArrayList<>();
        if (value instanceof Collection<?> items) {
            for (Object item : items) {
                names.add(String.valueOf(item));
            }
            return names;
        }
        for (String item : String.valueOf(value).split(",")) {
            if (!item.isBlank()) {
                names.add(item.trim());
            }
        }
        return names;
    }
}
