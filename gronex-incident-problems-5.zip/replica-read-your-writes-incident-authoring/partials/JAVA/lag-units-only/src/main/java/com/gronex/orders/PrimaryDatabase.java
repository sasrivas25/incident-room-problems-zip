package com.gronex.orders;

public interface PrimaryDatabase {
    void begin();

    void insertOrder(Order order);

    void updateOrder(Order order);

    long currentLsn();

    long commit();

    Order getOrder(String orderId);
}
