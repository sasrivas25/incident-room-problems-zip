'use strict';

class ReplicaMonitor {
  statuses() {
    throw new Error('not implemented');
  }
}

module.exports = { ReplicaMonitor };
