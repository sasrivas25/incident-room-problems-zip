'use strict';

const { makeOrder } = require('./models');

function apiResponse(status, body) {
  return Object.freeze({ status, body: Object.freeze({ ...body }) });
}

class OrdersApi {
  constructor(service) {
    this._service = service;
  }

  createOrder(sessionId, orderId, customerId, totalCents) {
    if (totalCents <= 0 || !orderId || !customerId) {
      return apiResponse(400, { error: 'invalid_order' });
    }
    const order = this._service.createOrder(sessionId, makeOrder(orderId, customerId, totalCents, 'PLACED'));
    return apiResponse(201, { order_id: order.orderId, location: `/v1/orders/${order.orderId}` });
  }

  getOrder(sessionId, orderId) {
    let order;
    try {
      order = this._service.getOrder(sessionId, orderId);
    } catch (err) {
      return apiResponse(500, { error: 'internal' });
    }
    if (order === null) {
      return apiResponse(404, { error: 'not_found' });
    }
    return apiResponse(200, {
      order_id: order.orderId,
      customer_id: order.customerId,
      total_cents: order.totalCents,
      status: order.status,
    });
  }
}

module.exports = { apiResponse, OrdersApi };
