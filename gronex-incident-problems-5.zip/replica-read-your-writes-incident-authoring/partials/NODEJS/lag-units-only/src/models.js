'use strict';

function makeOrder(orderId, customerId, totalCents, status) {
  return Object.freeze({ orderId, customerId, totalCents, status });
}

function makeReplicaStatus(name, appliedLsn, lagSeconds, healthy) {
  return Object.freeze({ name, appliedLsn, lagSeconds, healthy });
}

function makeSessionPin(minLsn, expiresAt) {
  return Object.freeze({ minLsn, expiresAt });
}

function makeRouteDecision(target, reason, minLsn = null) {
  return Object.freeze({ target, reason, minLsn });
}

module.exports = { makeOrder, makeReplicaStatus, makeSessionPin, makeRouteDecision };
