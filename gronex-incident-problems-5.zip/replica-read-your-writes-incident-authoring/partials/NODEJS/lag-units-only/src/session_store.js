'use strict';

class SessionStore {
  getPin(sessionId) {
    throw new Error('not implemented');
  }

  setPin(sessionId, pin) {
    throw new Error('not implemented');
  }
}

module.exports = { SessionStore };
