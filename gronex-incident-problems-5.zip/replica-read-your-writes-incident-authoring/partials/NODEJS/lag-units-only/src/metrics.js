'use strict';

class Metrics {
  constructor() {
    this._counters = new Map();
  }

  increment(name, amount = 1) {
    this._counters.set(name, (this._counters.get(name) ?? 0) + amount);
  }

  value(name) {
    return this._counters.get(name) ?? 0;
  }
}

module.exports = { Metrics };
