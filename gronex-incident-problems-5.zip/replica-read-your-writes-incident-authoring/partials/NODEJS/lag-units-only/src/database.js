'use strict';

class PrimaryDatabase {
  begin() {
    throw new Error('not implemented');
  }

  insertOrder(order) {
    throw new Error('not implemented');
  }

  updateOrder(order) {
    throw new Error('not implemented');
  }

  currentLsn() {
    throw new Error('not implemented');
  }

  commit() {
    throw new Error('not implemented');
  }

  getOrder(orderId) {
    throw new Error('not implemented');
  }
}

class ReplicaDatabase {
  name() {
    throw new Error('not implemented');
  }

  getOrder(orderId) {
    throw new Error('not implemented');
  }
}

module.exports = { PrimaryDatabase, ReplicaDatabase };
