'use strict';

class Clock {
  now() {
    throw new Error('not implemented');
  }
}

module.exports = { Clock };
