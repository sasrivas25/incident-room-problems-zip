'use strict';

const LSN_SEGMENT_SIZE = 0x100000000;

function formatLsn(value) {
  const high = Math.floor(value / LSN_SEGMENT_SIZE).toString(16).toUpperCase();
  const low = (value % LSN_SEGMENT_SIZE).toString(16).toUpperCase();
  return `${high}/${low}`;
}

function parseLsn(text) {
  const [high, low] = text.split('/');
  return Number.parseInt(high, 16) * LSN_SEGMENT_SIZE + Number.parseInt(low, 16);
}

module.exports = { LSN_SEGMENT_SIZE, formatLsn, parseLsn };
