'use strict';

const DEFAULTS = Object.freeze({
  maxReplicaLagMs: 200,
  readYourWritesWindowS: 5,
  replicaNames: Object.freeze(['replica-a', 'replica-b']),
});

function routingConfig(overrides = {}) {
  return Object.freeze({ ...DEFAULTS, ...overrides });
}

function configFromDict(values = {}) {
  return routingConfig({
    maxReplicaLagMs: Number.parseInt(values.max_replica_lag_ms ?? DEFAULTS.maxReplicaLagMs, 10),
    readYourWritesWindowS: Number.parseInt(values.read_your_writes_window_s ?? DEFAULTS.readYourWritesWindowS, 10),
    replicaNames: Object.freeze([...(values.replica_names ?? DEFAULTS.replicaNames)]),
  });
}

module.exports = { DEFAULTS, routingConfig, configFromDict };
