#!/usr/bin/env python3
"""Generate logs, metrics CSVs and dashboard.md for replica-read-your-writes-incident.

Single source of truth for timestamps, request ids, LSNs and spikes. Writes identical
copies into every language folder; only the stack trace frames differ (trace_lines.json).
"""
import csv
import json
import math
import os
import random
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.join(os.path.dirname(HERE), "replica-read-your-writes-incident")
LANGS = ["PYTHON", "JAVA", "NODEJS", "CPP"]
T0 = datetime(2026, 10, 30, 9, 0, 0, tzinfo=timezone.utc)
END = 35 * 60

B_LAG_START = 11 * 60 + 5
B_LAG_END = 29 * 60 + 4
LAG_ALERT_FIRE = 11 * 60 + 40
LAG_ALERT_RESOLVE = 30 * 60 + 4
DEPLOY_START = 14 * 60 + 2
POD_SWITCH = [DEPLOY_START + 30 * k for k in range(5)] + [DEPLOY_START + 148]
DEPLOY_DONE = POD_SWITCH[-1]
NOTFOUND_ALERT = 17 * 60 + 20
MONITOR_TIMEOUTS = [12 * 60 + 31.408, 20 * 60 + 15.772]
INITIAL_LSN = 0x5A3000
WRITES_PER_S = 14
WRITE_RECORD = 0x80
COMMIT_RECORD = 0x40

rng = random.Random(20261030)


def ts(seconds):
    return (T0 + timedelta(seconds=seconds)).strftime("%Y-%m-%dT%H:%M:%S.") + f"{int(round((seconds % 1) * 1000)) % 1000:03d}Z"


def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def smooth(x):
    x = clamp(x)
    return x * x * (3 - 2 * x)


def r2_fraction(t):
    return sum(1 for s in POD_SWITCH if t >= s) / len(POD_SWITCH)


def lsn_at(t):
    return INITIAL_LSN + int(WRITES_PER_S * t) * (WRITE_RECORD + COMMIT_RECORD)


def fmt_lsn(v):
    return f"{v // 0x100000000:X}/{v % 0x100000000:X}"


def replica_b_lag(t):
    if B_LAG_START <= t < B_LAG_END:
        phase = ((t - B_LAG_START) % 90) / 90.0
        return round(0.8 + 1.7 * phase + rng.uniform(-0.05, 0.05), 2)
    return round(0.02 + rng.uniform(-0.004, 0.004), 3)


def replica_a_lag(t):
    return round(0.02 + rng.uniform(-0.005, 0.006), 3)


def metric_rps(t):
    return round(180 + 4 * math.sin(t / 240.0) + rng.uniform(-3, 3), 1)


def metric_wps(t):
    return round(14 + 0.6 * math.sin(t / 200.0) + rng.uniform(-0.5, 0.5), 1)


def primary_share(t):
    base = 0.12 + rng.uniform(-0.006, 0.006)
    if t < DEPLOY_START:
        return round(base, 3)
    return round(base * (1 - r2_fraction(t)) + 0.003 * r2_fraction(t) + rng.uniform(-0.0005, 0.0005), 3)


def notfound_ratio(t):
    if t < DEPLOY_START:
        return round(0.0 + rng.uniform(0, 0.0004), 4)
    f = r2_fraction(t)
    lagging = 1.0 if B_LAG_START <= t < B_LAG_END else 0.0
    level = f * (0.012 + 0.048 * lagging * (0.6 + 0.4 * ((t - B_LAG_START) % 90) / 90.0))
    return round(level + rng.uniform(-0.001, 0.001), 4)


def metric_5xx(t):
    return 0.0


def primary_cpu(t):
    base = 41 + 2 * math.sin(t / 300.0) + rng.uniform(-1, 1)
    return round(base - 8 * r2_fraction(t), 1)


def build_metrics():
    rows = []
    for t in range(0, END + 1, 15):
        rows.append({
            "timestamp": ts(t), "t": t,
            "requests_per_s": metric_rps(t),
            "writes_per_s": metric_wps(t),
            "not_found_after_create_ratio": notfound_ratio(t),
            "http_5xx_ratio": metric_5xx(t),
            "primary_read_share": primary_share(t),
            "replica_a_lag_s": replica_a_lag(t),
            "replica_b_lag_s": replica_b_lag(t),
            "primary_cpu_pct": primary_cpu(t),
        })
    return rows


def write_csvs(rows, out_dir):
    traffic_cols = ["timestamp", "requests_per_s", "writes_per_s", "not_found_after_create_ratio", "http_5xx_ratio"]
    routing_cols = ["timestamp", "primary_read_share", "replica_a_lag_s", "replica_b_lag_s", "primary_cpu_pct"]
    for name, cols in (("traffic.csv", traffic_cols), ("routing.csv", routing_cols)):
        with open(os.path.join(out_dir, name), "w", newline="") as f:
            w = csv.writer(f, lineterminator="\n")
            w.writerow(cols)
            for r in rows:
                w.writerow([r[c] for c in cols])


SPARK = "▁▂▃▄▅▆▇█"


def sparkline(values):
    lo, hi = min(values), max(values)
    span = hi - lo if hi > lo else 1.0
    return "".join(SPARK[min(7, int((v - lo) / span * 7.999))] for v in values)


def marker_row(times, events):
    row = [" "] * len(times)
    for t_ev, ch in events:
        idx = min(range(len(times)), key=lambda i: abs(times[i] - t_ev))
        row[idx] = ch
    return "".join(row)


def fmt(v, kind):
    if kind == "ratio":
        return f"{v:.3f}"
    if kind == "ratio4":
        return f"{v:.4f}"
    return f"{v:.2f}" if kind == "sec" else f"{v:.1f}"


def write_dashboard(rows, out_dir):
    sampled = rows[::2]
    times = [r["t"] for r in sampled]
    events = [(B_LAG_START, "L"), (DEPLOY_START, "▲"), (DEPLOY_DONE, "△"), (LAG_ALERT_FIRE, "!"), (NOTFOUND_ALERT, "!"), (B_LAG_END, "l")]
    marks = marker_row(times, events)
    axis = "09:00" + " " * (len(times) // 2 - 10) + "09:17:30" + " " * (len(times) - len(times) // 2 - 13) + "09:35"
    panels = [
        ("requests_per_s", "Read request rate (GET /v1/orders/{id}, req/s)", "num"),
        ("writes_per_s", "Write rate (POST/PUT, req/s)", "num"),
        ("not_found_after_create_ratio", "Order not found within 2 s of create (ratio of creates)", "ratio4"),
        ("primary_read_share", "Share of reads routed to the primary (0-1)", "ratio"),
        ("replica_a_lag_s", "replica-a replication lag (s)", "sec"),
        ("replica_b_lag_s", "replica-b replication lag (s)", "sec"),
        ("primary_cpu_pct", "Primary CPU (%)", "num"),
    ]
    checkpoints = [(600, "09:10:00 baseline"), (720, "09:12:00 replica-b lagging, pre-deploy"), (DEPLOY_DONE, "09:16:30 rollout complete"),
                   (1035, "09:17:15 404 alert"), (1500, "09:25:00 mid-incident"), (1860, "09:31:00 replica-b recovered"), (END, "09:35:00 end")]
    by_t = {r["t"]: r for r in rows}
    L = []
    L.append("# orders-api dashboard, 2026-10-30 09:00-09:35 UTC")
    L.append("")
    L.append("Text rendering of `traffic.csv` and `routing.csv` (15 s resolution; charts sample every 30 s, one character per sample).")
    L.append("")
    L.append("Markers under each chart: `L` replica-b lag begins 09:11:05, `!` alert fired (09:11:40 replica_lag, 09:17:20 order_not_found_after_create), `▲` deploy r2 started 09:14:02, `△` rollout complete 09:16:30, `l` replica-b lag ends 09:29:04.")
    L.append("")
    L.append("## Timeline")
    L.append("")
    L.append("| Time (UTC) | Event |")
    L.append("| --- | --- |")
    L.append("| 09:11:05 | replica-b: replay paused by a conflicting analytics query; lag climbs in a sawtooth between 0.8 s and 2.5 s |")
    L.append("| 09:11:40 | ALERT replica_lag replica-b above 1.0 s |")
    L.append("| 09:14:02 | deploy 2026.10.30-r2 (ORD-2210, LSN-aware read routing) starts, pod 1 of 6 |")
    L.append("| 09:16:30 | rollout complete, 6 of 6 pods on r2 |")
    L.append("| 09:17:20 | ALERT order_not_found_after_create above 0.010 |")
    L.append("| 09:29:04 | analytics query on replica-b finishes; lag back to 20 ms |")
    L.append("| 09:30:04 | replica_lag alert resolved |")
    L.append("")
    L.append("## Panels")
    L.append("")
    for col, title, kind in panels:
        vals = [r[col] for r in sampled]
        L.append(f"### {title}")
        L.append("")
        L.append("```")
        L.append(f"max {fmt(max(vals), kind)}")
        L.append(sparkline(vals))
        L.append(marks)
        L.append(axis)
        L.append(f"min {fmt(min(vals), kind)}")
        L.append("```")
        L.append("")
        L.append("| Checkpoint | Value |")
        L.append("| --- | --- |")
        for t_cp, label in checkpoints:
            L.append(f"| {label} | {fmt(by_t[t_cp][col], kind)} |")
        L.append("")
    L.append("## Panel notes")
    L.append("")
    L.append("- Read and write rates are flat for the whole window.")
    L.append("- replica-b lag started three minutes before the deploy and ended at 09:29:04. Before the deploy it produced no not-found errors.")
    L.append("- The share of reads served by the primary falls from about 12 percent to about 0.3 percent as the r2 pods come up, and stays there. Primary CPU drops by 8 points at the same time.")
    L.append("- Not-found-after-create begins with the first r2 pod and tracks the replica-b sawtooth while it lasts. After replica-b recovers at 09:29 the ratio drops but does not return to zero; it settles near 1.2 percent, which is the replica-a race.")
    L.append("- 5xx ratio is zero throughout. The monitor timeouts in app.log are handled.")
    with open(os.path.join(out_dir, "dashboard.md"), "w") as f:
        f.write("\n".join(L) + "\n")


def req_id():
    return f"{rng.getrandbits(32):08x}"


R1_PODS = [f"oa-3b1c-{k}" for k in range(1, 7)]
R2_PODS = [f"oa-9e4d-{k}" for k in range(1, 7)]


def pod_at(t):
    k = rng.randrange(6)
    return R2_PODS[k] if t >= POD_SWITCH[k] else R1_PODS[k]


def is_r2(pod):
    return pod.startswith("oa-9e4d")


def app_line(t, level, pod, req, msg):
    return (t, f"{ts(t)} {level:<5} [orders-api] pod={pod} req={req} {msg}")


def render_trace(cfg):
    style = cfg["style"]
    frames = [cfg["api"], cfg["service_get"], cfg["router_route"], cfg["router_statuses"]]
    error = cfg["timeout_error"]
    out = []
    if style == "python":
        out.append("Traceback (most recent call last):")
        out.append("  File \"/srv/orders-api/lib/httpd/dispatcher.py\", line 88, in handle")
        out.append("    response = route(request)")
        for fr in frames:
            out.append(f"  File \"{cfg['root']}{fr['file']}\", line {fr['line']}, in {fr['func']}")
            out.append(f"    {fr['code']}")
        out.append("  File \"/srv/orders-api/lib/monitor/client.py\", line 143, in statuses")
        out.append("    raise ReplicaMonitorTimeout(f\"{name} status endpoint timed out after {self.timeout_ms}ms\")")
        out.append(error)
    elif style == "java":
        pkg = cfg["package"]
        out.append(error)
        out.append(f"\tat {pkg}.monitor.MonitorClient.statuses(MonitorClient.java:143)")
        for fr in reversed(frames):
            cls = fr["file"].replace(".java", "")
            out.append(f"\tat {pkg}.{cls}.{fr['func']}({fr['file']}:{fr['line']})")
        out.append(f"\tat {pkg}.httpd.Dispatcher.handle(Dispatcher.java:88)")
        out.append("\tat java.base/java.lang.Thread.run(Thread.java:1583)")
    elif style == "node":
        out.append(error)
        out.append("    at MonitorClient.statuses (/srv/orders-api/lib/monitor/client.js:143:11)")
        for fr in reversed(frames):
            out.append(f"    at {fr['func']} ({cfg['root']}{fr['file']}:{fr['line']}:{fr['col']})")
        out.append("    at Dispatcher.handle (/srv/orders-api/lib/httpd/dispatcher.js:88:17)")
        out.append("    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)")
    elif style == "cpp":
        out.append(f"exception caught in request handler: {error}")
        out.append("  #0 monitor::MonitorClient::statuses() at lib/monitor/client.cpp:143")
        idx = 1
        for fr in reversed(frames):
            out.append(f"  #{idx} {fr['func']} at {cfg['root']}{fr['file']}:{fr['line']}")
            idx += 1
        out.append(f"  #{idx} httpd::Dispatcher::handle(httpd::Request const&) at lib/httpd/dispatcher.cpp:88")
    return out


def route_line(pod, sid, pin, a_lsn, a_lag, b_lsn, b_lag, a_ok, b_ok, chosen, reason, min_lsn=None, a_healthy=True, b_healthy=True):
    pin_txt = "none" if pin is None else f"min_lsn={fmt_lsn(pin[0])} expires_in={pin[1]:.1f}s"
    a_cu = "-" if min_lsn is None else str(a_lsn >= min_lsn).lower()
    b_cu = "-" if min_lsn is None else str(b_lsn >= min_lsn).lower()
    return (f"route session={sid} pin={pin_txt} "
            f"replica-a[lsn={fmt_lsn(a_lsn)} lag={a_lag:.2f}s healthy={str(a_healthy).lower()} eligible={str(a_ok).lower()} caught_up={a_cu}] "
            f"replica-b[lsn={fmt_lsn(b_lsn)} lag={b_lag:.2f}s healthy={str(b_healthy).lower()} eligible={str(b_ok).lower()} caught_up={b_cu}] "
            f"-> {chosen} reason={reason}")


def build_app_log(cfg):
    L = []
    t = 4.0
    sessions = [f"s-{rng.getrandbits(16):04x}" for _ in range(40)]
    while t < END:
        pod = pod_at(t)
        sid = rng.choice(sessions)
        oid = f"o-{rng.randrange(80000, 89999)}"
        lsn = lsn_at(t)
        b_lag = replica_b_lag(t)
        a_lag = replica_a_lag(t)
        a_lsn = lsn - int(a_lag * WRITES_PER_S) * (WRITE_RECORD + COMMIT_RECORD)
        b_lsn = lsn - int(b_lag * WRITES_PER_S) * (WRITE_RECORD + COMMIT_RECORD)
        r = req_id()
        if is_r2(pod):
            b_ok = True
            chosen = "replica-a" if a_lag <= b_lag else "replica-b"
            L.append(app_line(t, "DEBUG", pod, r, route_line(pod, sid, None, a_lsn, a_lag, b_lsn, b_lag, True, b_ok, chosen, "no_recent_write")))
            L.append(app_line(t + 0.003, "INFO", pod, r, f"GET /v1/orders/{oid} status=200 route={chosen} dur_ms={rng.randrange(2, 6)}"))
        else:
            b_ok = b_lag * 1000 <= 200
            chosen = "replica-a" if (a_lag <= b_lag or not b_ok) else "replica-b"
            L.append(app_line(t, "DEBUG", pod, r, f"route session={sid} pin=none replica-a[lag={a_lag:.2f}s eligible=true] replica-b[lag={b_lag:.2f}s eligible={str(b_ok).lower()}] -> {chosen} reason=no_recent_write"))
            L.append(app_line(t + 0.003, "INFO", pod, r, f"GET /v1/orders/{oid} status=200 route={chosen} dur_ms={rng.randrange(2, 6)}"))
        t += rng.uniform(26, 40)

    def write_then_read(t_write, pod_idx, sid, oid, a_lag, b_lag, a_applied_offset, outcome, extra=None, verb="POST", body_status=None):
        pod = R2_PODS[pod_idx] if t_write >= POD_SWITCH[pod_idx] else R1_PODS[pod_idx]
        r = req_id()
        pre = lsn_at(t_write) + WRITE_RECORD
        commit = pre + COMMIT_RECORD
        if verb == "POST":
            L.append(app_line(t_write, "INFO", pod, r, f"POST /v1/orders {oid} status=201 session={sid} pin_lsn={fmt_lsn(pre)} window=5s dur_ms={rng.randrange(9, 16)}"))
        else:
            L.append(app_line(t_write, "INFO", pod, r, f"PUT /v1/orders/{oid} status=200 session={sid} body.status={body_status} pin_lsn={fmt_lsn(pre)} window=5s dur_ms={rng.randrange(9, 16)}"))
        t_read = t_write + rng.uniform(0.35, 0.9)
        pod2 = R2_PODS[rng.randrange(6)]
        r2 = req_id()
        a_lsn = commit + a_applied_offset
        b_lsn = commit - int(b_lag * WRITES_PER_S) * (WRITE_RECORD + COMMIT_RECORD)
        min_lsn = pre
        a_cu = a_lsn >= min_lsn
        b_cu = b_lsn >= min_lsn
        if extra == "a_unhealthy":
            chosen, reason = "replica-b", ("replica_caught_up" if b_cu else "least_lagging_replica")
            L.append(app_line(t_read, "DEBUG", pod2, r2, route_line(pod2, sid, (min_lsn, 5 - (t_read - t_write)), a_lsn, a_lag, b_lsn, b_lag, False, True, chosen, reason, min_lsn, a_healthy=False)))
        else:
            chosen = "replica-a"
            reason = "replica_caught_up" if a_cu else "least_lagging_replica"
            L.append(app_line(t_read, "DEBUG", pod2, r2, route_line(pod2, sid, (min_lsn, 5 - (t_read - t_write)), a_lsn, a_lag, b_lsn, b_lag, True, True, chosen, reason, min_lsn)))
        L.append(app_line(t_read + 0.003, "INFO", pod2, r2, f"GET /v1/orders/{oid} {outcome} route={chosen} dur_ms={rng.randrange(2, 6)}"))
        return commit

    for i, dt in enumerate([3.2, 9.8, 17.1, 26.4, 33.9, 41.0]):
        tt = B_LAG_START + dt
        pod = R1_PODS[i]
        L.append(app_line(tt, "WARN", pod, "-", f"replica-b excluded from read pool: lag={replica_b_lag(tt):.2f}s above max_replica_lag_ms=200"))
    L.append(app_line(LAG_ALERT_FIRE + 0.002, "ALERT", "-", "-", "[monitor] replica_lag replica-b=1.82s above threshold 1.0s for 30s (runbook: replica lag, routine)"))

    for i, e in enumerate(MONITOR_TIMEOUTS):
        pod = R1_PODS[2] if e < POD_SWITCH[2] else R2_PODS[2]
        r = req_id()
        L.append(app_line(e, "WARN", pod, r, "replica monitor poll failed for replica-b, using cached statuses age=2.9s"))
        if i == 0:
            for tl in render_trace(cfg):
                L.append((e + 0.0001, tl))
        else:
            L.append((e + 0.0001, f"{cfg['timeout_error']} (see trace at {ts(MONITOR_TIMEOUTS[0])})"))

    for k, s in enumerate(POD_SWITCH):
        L.append(app_line(s - 1.4, "INFO", R1_PODS[k], "-", "shutting down: SIGTERM from rollout controller, draining in-flight requests"))
        L.append(app_line(s + 0.117, "INFO", R2_PODS[k], "-", "starting build=2026.10.30-r2 commit=c41d2a7 change=ORD-2210 routing=lsn_aware config max_replica_lag_ms=200 read_your_writes_window_s=5 replicas=replica-a,replica-b"))
        L.append(app_line(s + 2.903, "INFO", R2_PODS[k], "-", "ready: health=ok primary=ok replicas=2/2 monitor=ok"))

    write_then_read(1001.420, 0, "s-7f3a", "o-88213", 0.02, 1.82, -(WRITE_RECORD + COMMIT_RECORD) * 2, "status=404")
    write_then_read(1092.015, 3, "s-c04e", "o-88301", 0.03, 2.31, -COMMIT_RECORD, "status=404")
    write_then_read(1142.772, 1, "s-91b2", "o-88377", 0.02, 1.04, 0, "status=200")
    L.append(app_line(NOTFOUND_ALERT + 0.002, "ALERT", "-", "-", "[monitor] order_not_found_after_create=0.013 above threshold 0.010 for 60s"))
    write_then_read(1270.306, 4, "s-wh1", "o-88150", 0.02, 1.55, -(WRITE_RECORD + COMMIT_RECORD), "status=200 body.status=PLACED", verb="PUT", body_status="SHIPPED")
    L.append(app_line(1381.0, "WARN", R2_PODS[5], "-", "replica-a health probe failed (connect timeout), marking unhealthy for 10s"))
    write_then_read(1383.511, 5, "s-2ac8", "o-88522", 0.02, 1.91, -(WRITE_RECORD + COMMIT_RECORD) * 3, "status=404", extra="a_unhealthy")
    L.append(app_line(1391.2, "INFO", R2_PODS[5], "-", "replica-a health probe ok, marking healthy"))
    write_then_read(1561.907, 2, "s-5e77", "o-88690", 0.02, 0.96, -COMMIT_RECORD, "status=404")
    L.append(app_line(B_LAG_END + 0.4, "INFO", R2_PODS[1], "-", f"replica-b lag back to {replica_b_lag(B_LAG_END + 1):.2f}s"))
    L.append(app_line(LAG_ALERT_RESOLVE + 0.002, "ALERT", "-", "-", "[monitor] RESOLVED replica_lag replica-b=0.02s"))
    write_then_read(1850.233, 0, "s-0d19", "o-88944", 0.03, 0.02, -(WRITE_RECORD + COMMIT_RECORD), "status=404")
    write_then_read(1990.648, 4, "s-b3f0", "o-89011", 0.02, 0.02, -COMMIT_RECORD, "status=404")

    L.sort(key=lambda x: x[0])
    return [l for _, l in L]


def build_db_log():
    L = []
    for t in range(20, END, 60):
        a = replica_a_lag(t)
        b = replica_b_lag(t + 0.5)
        lsn = lsn_at(t)
        L.append((t, f"{ts(t)} primary   LOG: wal position {fmt_lsn(lsn)} xacts/s={WRITES_PER_S} active_conns={rng.randrange(28, 41)}"))
        L.append((t + 0.3, f"{ts(t + 0.3)} replica-a LOG: replay position {fmt_lsn(lsn - int(a * WRITES_PER_S) * 0xC0)} lag={a:.3f}s state=streaming"))
        L.append((t + 0.5, f"{ts(t + 0.5)} replica-b LOG: replay position {fmt_lsn(lsn - int(b * WRITES_PER_S) * 0xC0)} lag={b:.3f}s state={'streaming' if b < 0.5 else 'streaming (replay delayed)'}"))
    L.append((B_LAG_START - 0.8, f"{ts(B_LAG_START - 0.8)} replica-b LOG: statement: SELECT customer_id, sum(total_cents) FROM orders WHERE created_at > now() - interval '30 days' GROUP BY 1 (user=analytics app=nightly-rollup)"))
    L.append((B_LAG_START, f"{ts(B_LAG_START)} replica-b LOG: recovery conflict on snapshot, delaying replay (max_standby_streaming_delay=30s) pid=48213 user=analytics"))
    for k in range(1, 12):
        tt = B_LAG_START + 90 * k
        if tt >= B_LAG_END:
            break
        L.append((tt - 0.2, f"{ts(tt - 0.2)} replica-b LOG: canceling statement due to conflict with recovery pid=48213 user=analytics"))
        L.append((tt + 0.1, f"{ts(tt + 0.1)} replica-b LOG: replay resumed, catching up from {fmt_lsn(lsn_at(tt) - 0xC0 * 35)}"))
        L.append((tt + 2.4, f"{ts(tt + 2.4)} replica-b LOG: statement: SELECT customer_id, sum(total_cents) FROM orders WHERE created_at > now() - interval '30 days' GROUP BY 1 (user=analytics app=nightly-rollup, retry {k})"))
        L.append((tt + 2.6, f"{ts(tt + 2.6)} replica-b LOG: recovery conflict on snapshot, delaying replay (max_standby_streaming_delay=30s) pid={48213 + k}"))
    L.append((B_LAG_END, f"{ts(B_LAG_END)} replica-b LOG: statement finished duration=1079.2s rows=18233 user=analytics app=nightly-rollup"))
    L.append((B_LAG_END + 0.9, f"{ts(B_LAG_END + 0.9)} replica-b LOG: replay caught up, lag=0.021s"))
    for t_write, oid, kind in ((1001.420, "o-88213", "INSERT"), (1092.015, "o-88301", "INSERT"), (1142.772, "o-88377", "INSERT"), (1270.306, "o-88150", "UPDATE"), (1383.511, "o-88522", "INSERT"), (1561.907, "o-88690", "INSERT"), (1850.233, "o-88944", "INSERT"), (1990.648, "o-89011", "INSERT")):
        pre = lsn_at(t_write) + WRITE_RECORD
        commit = pre + COMMIT_RECORD
        L.append((t_write + 0.004, f"{ts(t_write + 0.004)} primary   LOG: {kind} orders {oid} wal={fmt_lsn(pre)}"))
        L.append((t_write + 0.006, f"{ts(t_write + 0.006)} primary   LOG: COMMIT xid={rng.randrange(7000000, 7999999)} commit_lsn={fmt_lsn(commit)}"))
    L.sort(key=lambda x: x[0])
    return [l for _, l in L]


def build_deploy_log():
    L = []
    L.append((835.0, "rollout orders-api build=2026.10.30-r2 commit=c41d2a7 change=ORD-2210 title=\"LSN-aware read routing (replaces 5s primary pin)\" requested_by=jpark strategy=rolling max_unavailable=1"))
    L.append((836.2, "pre-flight: config diff vs r1: none (max_replica_lag_ms=200 read_your_writes_window_s=5 replicas=replica-a,replica-b)"))
    L.append((837.5, "pre-flight: dependency check replica-b lag 1.9s (alert active); replicas are not a rollout gate, proceeding"))
    L.append((838.8, "pre-flight: change notes: ORD-2210 routes post-write reads to any replica that has applied the session's commit position; expected primary read share < 1%"))
    for k, s in enumerate(POD_SWITCH):
        L.append((s - 1.6, f"pod {k + 1}/6 oa-3b1c-{k + 1}: terminating"))
        L.append((s, f"pod {k + 1}/6 oa-9e4d-{k + 1}: created image=orders-api:2026.10.30-r2"))
        L.append((s + 3.1, f"pod {k + 1}/6 oa-9e4d-{k + 1}: ready (health=ok), traffic shifted"))
    L.append((DEPLOY_DONE + 4.0, "rollout complete 6/6 pods healthy on build 2026.10.30-r2"))
    L.append((DEPLOY_DONE + 5.0, "post-deploy check (5 min window): error_rate=0.000 p99_ms=14 primary_read_share=0.004 (target <0.01), marking rollout SUCCESS"))
    L.append((NOTFOUND_ALERT + 30.0, "alert order_not_found_after_create linked to rollout by time correlation; auto-rollback disabled for this service (policy: manual rollback only)"))
    out = []
    for t, msg in sorted(L, key=lambda x: x[0]):
        out.append(f"{ts(t)} [rollout-controller] {msg}")
    return out


def main():
    with open(os.path.join(HERE, "trace_lines.json")) as f:
        traces = json.load(f)
    global rng
    rng = random.Random(20261030)
    rows = build_metrics()
    rng = random.Random(9)
    db_log = build_db_log()
    deploy_log = build_deploy_log()
    app_logs = {}
    for lang in LANGS:
        rng = random.Random(1030)
        app_logs[lang] = build_app_log(traces[lang])
    for lang in LANGS:
        base = os.path.join(REPO, lang)
        os.makedirs(os.path.join(base, "logs"), exist_ok=True)
        os.makedirs(os.path.join(base, "metrics"), exist_ok=True)
        with open(os.path.join(base, "logs", "app.log"), "w") as f:
            f.write("\n".join(app_logs[lang]) + "\n")
        with open(os.path.join(base, "logs", "db.log"), "w") as f:
            f.write("\n".join(db_log) + "\n")
        with open(os.path.join(base, "logs", "deploy.log"), "w") as f:
            f.write("\n".join(deploy_log) + "\n")
        write_csvs(rows, os.path.join(base, "metrics"))
        write_dashboard(rows, os.path.join(base, "metrics"))
    print(f"app.log lines: {len(app_logs['PYTHON'])}, db.log: {len(db_log)}, deploy.log: {len(deploy_log)}, metric rows: {len(rows)}")


if __name__ == "__main__":
    main()
